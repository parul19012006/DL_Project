"""Measure the service at the scale it is meant to run at.

    python scripts/benchmark.py --documents 500

Generates a synthetic corpus, ingests it through the real batch worker,
runs a set of queries, and reports per-stage timings, retrieval latency
percentiles and memory behaviour.

Every document is invented — parties, amounts and clauses are generated
here. No real or confidential legal material is involved.

**Why a script rather than a test.** These numbers depend on the machine,
the embedding model and the vector backend, so asserting on them would
produce a test that fails for the wrong reasons on someone else's laptop.
The suite asserts *behaviour*; this measures *cost*, and the measurement
is meant to be re-run whenever either changes.
"""

from __future__ import annotations

import argparse
import gc
import json
import os
import resource
import statistics
import sys
import time
import tracemalloc
from pathlib import Path
from typing import Dict, List

# Import the service the way a deployment would.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def peak_rss_mb() -> float:
    """Peak resident set size. On Linux ru_maxrss is in kilobytes."""
    usage = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return usage / 1024.0


def current_rss_mb() -> float:
    """Resident set size right now, read from /proc where available."""
    try:
        with open("/proc/self/statm") as handle:
            pages = int(handle.read().split()[1])
        return pages * os.sysconf("SC_PAGE_SIZE") / (1024 * 1024)
    except Exception:  # pragma: no cover - not Linux
        return 0.0


class Timer:
    def __init__(self) -> None:
        self.marks: Dict[str, float] = {}

    def __call__(self, name: str):
        return _Mark(self, name)


class _Mark:
    def __init__(self, timer: Timer, name: str) -> None:
        self.timer, self.name = timer, name

    def __enter__(self):
        self.started = time.perf_counter()
        return self

    def __exit__(self, *exc):
        elapsed = (time.perf_counter() - self.started) * 1000
        self.timer.marks[self.name] = self.timer.marks.get(self.name, 0.0) + elapsed
        return False


# ---------------------------------------------------------------------
# Corpus
# ---------------------------------------------------------------------

SIZES = {
    # name: (clauses per document, share of the corpus)
    "small": (4, 0.55),
    "medium": (8, 0.35),
    "large": (24, 0.10),
}


def build_corpus(root: Path, count: int, fmt: str = "pdf") -> List[Dict]:
    """Write ``count`` synthetic agreements and return ingest items."""
    from tests import fixtures

    root.mkdir(parents=True, exist_ok=True)
    items: List[Dict] = []
    plan: List[str] = []
    for name, (_, share) in SIZES.items():
        plan.extend([name] * max(1, round(count * share)))
    plan = (plan * ((count // len(plan)) + 1))[:count]

    for index in range(count):
        size = plan[index]
        clauses, _ = SIZES[size]
        # Vary the text so every document is genuinely distinct: identical
        # documents would make embedding and dedup unrealistically cheap.
        sections = []
        for position in range(clauses):
            heading, body = fixtures.VENDOR_CONTRACT[
                position % len(fixtures.VENDOR_CONTRACT)
            ]
            sections.append(
                (
                    f"{position + 1}. {heading.split('. ', 1)[-1]}",
                    body.replace("Northwind Systems", f"Vendor {index:04d}")
                    .replace("Harbour Legal", f"Client {index:04d}")
                    .replace("4,50,000", f"{(index % 90) + 10},00,000"),
                )
            )

        tenant = f"tenant-{index % 5:02d}"
        if fmt == "docx":
            path = root / f"agreement_{index:04d}.docx"
            fixtures.make_docx(path, f"SERVICES AGREEMENT {index:04d}", sections,
                               with_table=False)
        else:
            path = root / f"agreement_{index:04d}.pdf"
            fixtures.make_pdf(
                path,
                f"SERVICES AGREEMENT {index:04d}",
                sections,
                footer=f"Vendor {index:04d} - Confidential",
                page_break_every=3,
            )

        items.append(
            {
                "document_id": f"doc-{index:04d}",
                "tenant_id": tenant,
                "file_path": str(path),
                "document_type": "contract",
                "_size": size,
            }
        )
    return items


QUERIES = [
    "How much notice is required to terminate for convenience?",
    "What is the limitation of liability?",
    "Which law governs this agreement?",
    "What are the confidentiality obligations?",
    "When are invoices due and what interest applies to late payment?",
    "What does clause 8 say?",
    "How is a dispute resolved?",
    "What happens to client data on termination?",
]


# ---------------------------------------------------------------------
# Runs
# ---------------------------------------------------------------------


def run_ingestion(items, settings, timer: Timer) -> Dict:
    """Ingest through the real batch worker, one document at a time."""
    from app.services.jobs import JobRegistry, run_batch

    registry = JobRegistry()
    job = registry.create(total=len(items), request_id="benchmark")

    payload = [{k: v for k, v in item.items() if not k.startswith("_")} for item in items]

    rss_before = current_rss_mb()
    tracemalloc.start()
    started = time.perf_counter()
    run_batch(job, payload, settings=settings)
    wall = time.perf_counter() - started
    traced_current, traced_peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    rss_after = current_rss_mb()

    per_document = [r.duration_ms for r in job.results if r.status == "success"]
    by_size: Dict[str, List[int]] = {}
    for item, record in zip(items, job.results):
        if record.status == "success":
            by_size.setdefault(item["_size"], []).append(record.duration_ms)

    return {
        "documents": job.total,
        "succeeded": job.succeeded,
        "failed": job.failed,
        "chunks": job.chunks_indexed,
        "wall_seconds": round(wall, 2),
        "docs_per_second": round(job.total / wall, 2) if wall else 0,
        "per_document_ms": {
            "mean": round(statistics.mean(per_document), 1) if per_document else 0,
            "median": round(statistics.median(per_document), 1) if per_document else 0,
            "p95": round(_percentile(per_document, 95), 1) if per_document else 0,
            "max": max(per_document) if per_document else 0,
        },
        "per_size_mean_ms": {
            size: round(statistics.mean(values), 1) for size, values in sorted(by_size.items())
        },
        "memory_mb": {
            "rss_before": round(rss_before, 1),
            "rss_after": round(rss_after, 1),
            "rss_growth": round(rss_after - rss_before, 1),
            "peak_rss": round(peak_rss_mb(), 1),
            "python_peak_traced": round(traced_peak / (1024 * 1024), 1),
            "python_retained": round(traced_current / (1024 * 1024), 1),
        },
    }


def run_stage_breakdown(items, settings, sample: int = 12) -> Dict:
    """Time extraction, chunking and embedding separately on a sample.

    The batch worker reports only a total per document; splitting it says
    which stage the time actually goes to, which is what a tuning
    decision needs.
    """
    from app.chunking.chunker import LegalChunker
    from app.embeddings.factory import embed_in_batches, get_embedding_model
    from app.ingestion.service import extract_document

    model = get_embedding_model(settings)
    totals = {"extract": 0.0, "chunk": 0.0, "embed": 0.0}
    chunks_total = 0

    for item in items[:sample]:
        mark = time.perf_counter()
        document = extract_document(
            document_id=item["document_id"],
            tenant_id=item["tenant_id"],
            file_path=item["file_path"],
            settings=settings,
            skip_path_check=True,
        )
        totals["extract"] += (time.perf_counter() - mark) * 1000

        mark = time.perf_counter()
        chunks = LegalChunker(settings).chunk_document(document)
        totals["chunk"] += (time.perf_counter() - mark) * 1000
        chunks_total += len(chunks)

        mark = time.perf_counter()
        embed_in_batches(
            model, [c.text for c in chunks], batch_size=settings.index_batch_size
        )
        totals["embed"] += (time.perf_counter() - mark) * 1000
        del document, chunks
        gc.collect()

    return {
        "sampled_documents": sample,
        "chunks": chunks_total,
        "mean_ms_per_document": {
            stage: round(value / sample, 1) for stage, value in totals.items()
        },
        "share_of_time": {
            stage: f"{value / sum(totals.values()) * 100:.0f}%"
            for stage, value in totals.items()
        },
        "mean_ms_per_chunk_embed": round(totals["embed"] / max(1, chunks_total), 2),
    }


def run_retrieval(settings, tenants: List[str], repeats: int = 3) -> Dict:
    """Retrieval and end-to-end answer latency over a warm index."""
    from app.generation.service import AnswerService
    from app.retrieval.pipeline import get_pipeline

    pipeline = get_pipeline(settings)
    service = AnswerService(settings)

    # Warm up and discard. The first query pays for opening the Chroma
    # collection and for the one attempt to load a cross-encoder that is
    # not reachable here; folding a 5-second one-off into a latency
    # distribution would make the number a lie.
    for tenant in tenants:
        pipeline.retrieve(QUERIES[0], tenant)
    service.answer(QUERIES[0], tenants[0])

    retrieval_ms: List[float] = []
    answer_ms: List[float] = []
    corpus_sizes: List[int] = []

    for _ in range(repeats):
        for query in QUERIES:
            for tenant in tenants:
                mark = time.perf_counter()
                outcome = pipeline.retrieve(query, tenant)
                retrieval_ms.append((time.perf_counter() - mark) * 1000)
                corpus_sizes.append(outcome.counts.corpus_size)

    for query in QUERIES:
        mark = time.perf_counter()
        service.answer(query, tenants[0])
        answer_ms.append((time.perf_counter() - mark) * 1000)

    return {
        "queries_run": len(retrieval_ms),
        "tenant_corpus_chunks": max(corpus_sizes) if corpus_sizes else 0,
        "retrieval_ms": _distribution(retrieval_ms),
        "answer_ms": _distribution(answer_ms),
    }


def run_reingest(items, settings) -> Dict:
    """Re-ingest the same corpus: the cost of running a batch twice."""
    from app.services.jobs import JobRegistry, run_batch

    payload = [{k: v for k, v in item.items() if not k.startswith("_")} for item in items]
    job = JobRegistry().create(total=len(payload), request_id="benchmark-reingest")

    started = time.perf_counter()
    run_batch(job, payload, settings=settings)
    wall = time.perf_counter() - started

    skipped = sum(
        1 for r in job.results if any("unchanged" in w.lower() for w in r.warnings)
    )
    return {
        "wall_seconds": round(wall, 2),
        "succeeded": job.succeeded,
        "skipped_unchanged": skipped,
        "chunks": job.chunks_indexed,
    }


def _percentile(values: List[float], percent: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    position = min(len(ordered) - 1, int(round(percent / 100 * (len(ordered) - 1))))
    return ordered[position]


def _distribution(values: List[float]) -> Dict[str, float]:
    if not values:
        return {}
    return {
        "mean": round(statistics.mean(values), 1),
        "median": round(statistics.median(values), 1),
        "p95": round(_percentile(values, 95), 1),
        "max": round(max(values), 1),
    }


# ---------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--documents", type=int, default=500)
    parser.add_argument("--format", choices=["pdf", "docx"], default="pdf")
    parser.add_argument("--workdir", default="/tmp/genai-benchmark")
    parser.add_argument("--skip-reingest", action="store_true")
    parser.add_argument("--json", help="Write the report to this path as JSON")
    args = parser.parse_args()

    workdir = Path(args.workdir)
    os.environ.setdefault("ENV_FILE", str(workdir / "nonexistent.env"))
    os.environ.setdefault("DOCUMENT_ROOT", str(workdir / "documents"))
    os.environ.setdefault("TEMP_DIR", str(workdir / "tmp"))
    os.environ.setdefault("VECTOR_PERSIST_DIR", str(workdir / "vectors"))
    os.environ.setdefault("VECTOR_COLLECTION", "benchmark")
    os.environ.setdefault("LOG_LEVEL", "WARNING")
    for directory in ("documents", "tmp", "vectors"):
        (workdir / directory).mkdir(parents=True, exist_ok=True)

    from app.config import get_settings

    settings = get_settings()

    print(f"Building {args.documents} synthetic {args.format.upper()} documents…")
    timer = Timer()
    with timer("corpus"):
        items = build_corpus(workdir / "documents", args.documents, args.format)
    corpus_bytes = sum(Path(i["file_path"]).stat().st_size for i in items)

    report: Dict = {
        "configuration": {
            "documents": args.documents,
            "format": args.format,
            "corpus_mb": round(corpus_bytes / (1024 * 1024), 1),
            "embedding_provider": settings.embedding_provider,
            "embedding_model": settings.embedding_model,
            "vector_backend": settings.vector_backend,
            "chunk_size": settings.chunk_size,
            "index_batch_size": settings.index_batch_size,
            "retrieval_candidates": settings.retrieval_candidates,
            "llm_provider": settings.llm_provider,
        },
        "corpus_build_seconds": round(timer.marks["corpus"] / 1000, 1),
    }

    # Warm up: load the embedding model and open the collection before
    # anything is timed, so the first document does not carry the cost of
    # starting the service.
    print("Warming up…")
    from app.embeddings.factory import get_embedding_model
    from app.vectorstore.factory import get_vector_store

    get_embedding_model(settings).embed_query("warm up")
    get_vector_store(settings).ensure_ready()

    print("Measuring per-stage cost on a sample…")
    report["stages"] = run_stage_breakdown(items, settings)

    print(f"Ingesting {args.documents} documents…")
    report["ingestion"] = run_ingestion(items, settings, timer)

    print("Measuring retrieval…")
    tenants = sorted({i["tenant_id"] for i in items})[:3]
    report["retrieval"] = run_retrieval(settings, tenants)

    if not args.skip_reingest:
        print("Re-ingesting the same corpus…")
        report["reingest"] = run_reingest(items, settings)

    from app.vectorstore.factory import get_vector_store

    stats = get_vector_store(settings).stats()
    report["index"] = {
        "backend": stats.backend,
        "total_chunks": stats.total_chunks,
        "dimension": stats.dimension,
    }

    print()
    print(json.dumps(report, indent=2))
    if args.json:
        Path(args.json).write_text(json.dumps(report, indent=2))
        print(f"\nWritten to {args.json}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
