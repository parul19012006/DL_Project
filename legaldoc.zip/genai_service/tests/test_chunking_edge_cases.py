"""Empty input, unusual formatting, and the tokenizer/splitter units.

These are the cases that decide whether the chunker survives the tenth
thousand real document rather than the first ten. The rule throughout:
never crash, never lose text, never emit an empty chunk.
"""

from __future__ import annotations

import pytest

from app.chunking.chunker import LegalChunker, chunk_document
from app.chunking.splitters import (
    has_whitespace,
    is_item_start,
    looks_enumerated,
    split_characters,
    split_enumerated_items,
    split_paragraphs,
    split_sentences,
    split_words,
)
from app.chunking.tokenizer import (
    HeuristicTokenCounter,
    build_token_counter,
    count_tokens,
    estimate_words_for_tokens,
    get_token_counter,
    set_token_counter,
    truncate_to_tokens,
)
from app.models.document import DocumentMetadata, ExtractedDocument, Page, TextBlock
from tests.test_chunking_core import build_document, sentences


# =====================================================================
# Empty and near-empty input
# =====================================================================


def test_document_with_no_pages(settings):
    document = ExtractedDocument(
        metadata=DocumentMetadata(document_id="d", tenant_id="t", filename="x.pdf")
    )
    assert chunk_document(document, settings) == []


def test_document_with_no_blocks(settings):
    document = ExtractedDocument(
        metadata=DocumentMetadata(document_id="d", tenant_id="t", filename="x.pdf"),
        pages=[Page(page_number=1)],
    )
    assert chunk_document(document, settings) == []


@pytest.mark.parametrize("text", ["", "   ", "\n", "\n\n\n", "\t\t", " \n \t "])
def test_whitespace_only_blocks_produce_no_chunks(text, settings):
    assert chunk_document(build_document([(text, 1, None)]), settings) == []


def test_a_mix_of_empty_and_real_blocks_keeps_only_the_real_text(settings):
    document = build_document(
        [
            ("   ", 1, "1. ONE"),
            ("The Vendor shall deliver the Services under Schedule A.", 1, "1. ONE"),
            ("\n\n", 1, "1. ONE"),
        ]
    )
    chunks = chunk_document(document, settings)

    assert len(chunks) == 1
    assert "Vendor shall deliver" in chunks[0].text


def test_no_chunk_is_ever_empty(make_settings):
    cfg = make_settings(chunk_size=40, chunk_overlap=10, min_chunk_tokens=5)
    document = build_document(
        [("", 1, None), (sentences(20), 1, None), ("   ", 2, None)]
    )
    for chunk in chunk_document(document, cfg):
        assert chunk.text.strip()
        assert chunk.token_count > 0


# =====================================================================
# Unusual formatting
# =====================================================================


def test_text_with_no_sentence_punctuation(make_settings):
    """Headings, tables and OCR output often have no full stops."""
    cfg = make_settings(chunk_size=40, chunk_overlap=5, min_chunk_tokens=5)
    text = " ".join(f"item{i}" for i in range(300))
    chunks = chunk_document(build_document([(text, 1, None)]), cfg)

    assert len(chunks) > 1
    assert all(c.text.strip() for c in chunks)
    assert "item0" in chunks[0].text
    assert "item299" in chunks[-1].text


def test_one_enormous_sentence(make_settings):
    """Legal drafting regularly produces 400-word single sentences."""
    cfg = make_settings(chunk_size=50, chunk_overlap=10, min_chunk_tokens=5)
    text = (
        "The Vendor shall, subject to the terms of this Agreement and without "
        "limiting any other provision hereof, "
        + ", ".join(f"perform obligation{i}" for i in range(200))
        + "."
    )
    chunks = chunk_document(build_document([(text, 1, None)]), cfg)

    assert len(chunks) > 1
    assert any(c.split_mid_sentence for c in chunks)
    combined = " ".join(c.text for c in chunks)
    assert "obligation0" in combined and "obligation199" in combined


def test_text_with_no_whitespace_at_all(make_settings):
    """A base64 blob or a script that does not space its words."""
    cfg = make_settings(chunk_size=40, chunk_overlap=5, min_chunk_tokens=5)
    text = "A" * 5000
    chunks = chunk_document(build_document([(text, 1, None)]), cfg)

    assert len(chunks) > 1
    assert all(c.text.strip() for c in chunks)
    assert sum(len(c.text) for c in chunks) >= 5000


def test_a_single_unbroken_token_longer_than_the_budget(make_settings):
    cfg = make_settings(chunk_size=32, chunk_overlap=0, min_chunk_tokens=5)
    chunks = chunk_document(build_document([("x" * 900, 1, None)]), cfg)
    assert chunks
    assert all(c.text.strip() for c in chunks)


def test_excessive_blank_lines_between_paragraphs(make_settings):
    cfg = make_settings(chunk_size=60, chunk_overlap=0, min_chunk_tokens=5)
    text = "\n\n\n\n\n".join(
        f"Clause {i} sets out an obligation of the Vendor hereunder." for i in range(5)
    )
    chunks = chunk_document(build_document([(text, 1, None)]), cfg)

    assert chunks
    for chunk in chunks:
        assert "\n\n\n" not in chunk.text


def test_unicode_and_currency_symbols_survive(settings):
    text = (
        "The fee is ₹5,00,000 per month, payable in € or £ at the "
        "Client's election, subject to clause 4.2 — see Schedule B."
    )
    chunk = chunk_document(build_document([(text, 1, None)]), settings)[0]

    for symbol in ("₹", "€", "£", "—"):
        assert symbol in chunk.text
    assert "5,00,000" in chunk.text


def test_tabular_text_is_not_mangled(settings):
    """Stage 2 flattens tables to pipe-separated rows."""
    text = (
        "Party | Notice Address\n"
        "Meridian Analytics Inc. | 44 Ridgeway Road, Wilmington, DE\n"
        "Cobalt Ventures LLC | 9 Beacon Street, Boston, MA"
    )
    chunk = chunk_document(build_document([(text, 1, "5. NOTICES")]), settings)[0]

    assert "Wilmington" in chunk.text and "Beacon Street" in chunk.text
    assert chunk.text.count("|") >= 3


def test_a_document_that_is_one_giant_block(make_settings):
    cfg = make_settings(chunk_size=100, chunk_overlap=20, min_chunk_tokens=20)
    chunks = chunk_document(build_document([(sentences(400), 1, None)]), cfg)

    assert len(chunks) > 10
    assert all(c.page_number == 1 for c in chunks)


def test_many_tiny_blocks(make_settings):
    """A bullet list extracted as 200 one-line blocks."""
    cfg = make_settings(chunk_size=100, chunk_overlap=0, min_chunk_tokens=20)
    document = build_document([(f"Item {i}.", 1, "9. SCHEDULE") for i in range(200)])
    chunks = chunk_document(document, cfg)

    assert chunks
    combined = " ".join(c.text for c in chunks)
    for i in (0, 99, 199):
        assert f"Item {i}." in combined


def test_repeated_identical_paragraphs_get_distinct_ids(make_settings):
    """Boilerplate repeated verbatim must not collide on chunk_id."""
    cfg = make_settings(chunk_size=40, chunk_overlap=0, min_chunk_tokens=5)
    paragraph = "This clause is intentionally repeated verbatim in the schedule."
    document = build_document([(paragraph, 1, None) for _ in range(5)])
    ids = [c.chunk_id for c in chunk_document(document, cfg)]

    assert len(ids) == len(set(ids))


def test_mixed_scripts_do_not_crash(make_settings):
    cfg = make_settings(chunk_size=40, chunk_overlap=5, min_chunk_tokens=5)
    text = "Agreement / समझौता / 契約書 " * 40
    chunks = chunk_document(build_document([(text, 1, None)]), cfg)

    assert chunks
    assert all(c.text.strip() for c in chunks)


def test_pathological_settings_still_terminate(make_settings):
    """Minimum size, maximum overlap, huge minimum — must not hang."""
    cfg = make_settings(
        chunk_size=32, chunk_overlap=4096, min_chunk_tokens=10000,
        chunk_size_tolerance=1.0,
    )
    chunks = chunk_document(build_document([(sentences(60), 1, None)]), cfg)
    assert chunks


# =====================================================================
# Tokenizer
# =====================================================================


def test_token_count_is_zero_for_empty_text():
    counter = HeuristicTokenCounter()
    assert counter.count("") == 0
    assert counter.count("   ") == 0


def test_token_count_grows_with_text():
    counter = HeuristicTokenCounter()
    short = counter.count("The Vendor shall pay.")
    long = counter.count("The Vendor shall pay. " * 20)
    assert long > short


def test_token_count_is_deterministic():
    counter = HeuristicTokenCounter()
    text = "Either party may terminate on 120 days notice."
    assert counter.count(text) == counter.count(text)


def test_long_words_cost_more_than_short_ones():
    counter = HeuristicTokenCounter()
    assert counter.count("indemnification") > counter.count("fee")


def test_text_without_whitespace_is_not_counted_as_zero():
    """Otherwise an unsplittable blob would slip past the size guard."""
    assert HeuristicTokenCounter().count("交易" * 500) > 0


def test_heuristic_is_in_the_right_ballpark():
    """Roughly one token per 4 characters of English prose."""
    text = (
        "Either party may terminate this Agreement for convenience on one "
        "hundred and twenty days written notice to the other party."
    )
    tokens = HeuristicTokenCounter().count(text)
    assert len(text) / 6 < tokens < len(text) / 2


def test_truncate_to_tokens_respects_the_budget():
    counter = HeuristicTokenCounter()
    text = " ".join(f"word{i}" for i in range(500))
    trimmed = truncate_to_tokens(text, 50, counter)

    assert counter.count(trimmed) <= 50
    assert trimmed
    assert text.startswith(trimmed.split()[0])


def test_truncate_returns_the_text_when_it_already_fits():
    assert truncate_to_tokens("short text", 100, HeuristicTokenCounter()) == "short text"


def test_truncate_to_zero_tokens():
    assert truncate_to_tokens("anything", 0, HeuristicTokenCounter()) == ""


def test_estimate_words_for_tokens_is_conservative():
    assert 0 < estimate_words_for_tokens(100) <= 100
    assert estimate_words_for_tokens(0) >= 1


def test_counter_can_be_swapped(settings):
    """Stage 4 will install the embedding model's own tokenizer."""

    class DoubleCounter:
        name = "double"

        def count(self, text: str) -> int:
            return len(text.split()) * 2

    try:
        set_token_counter(DoubleCounter())
        assert count_tokens("one two three") == 6
        assert get_token_counter().name == "double"
    finally:
        set_token_counter(None)

    assert get_token_counter().name == "heuristic"


def test_build_falls_back_when_tiktoken_is_missing(make_settings):
    counter = build_token_counter(make_settings(tokenizer="tiktoken"))
    assert counter.name in ("heuristic", "tiktoken:cl100k_base")


def test_the_chunker_uses_the_injected_counter(settings):
    class TinyCounter:
        name = "tiny"

        def count(self, text: str) -> int:
            return max(1, len(text) // 2)

    chunker = LegalChunker(settings, counter=TinyCounter())
    assert chunker.counter.name == "tiny"
    chunks = chunker.chunk_document(build_document([(sentences(40), 1, None)]))
    assert chunks


# =====================================================================
# Splitters
# =====================================================================


def test_split_paragraphs_on_blank_lines():
    assert split_paragraphs("One.\n\nTwo.\n\n\nThree.") == ["One.", "Two.", "Three."]


def test_split_paragraphs_on_empty_input():
    assert split_paragraphs("") == []
    assert split_paragraphs("   \n\n  ") == []


def test_split_paragraphs_returns_one_piece_when_there_is_no_break():
    assert split_paragraphs("A single paragraph.") == ["A single paragraph."]


def test_sentences_split_on_terminal_punctuation():
    parts = split_sentences("The fee is due. Late payment accrues interest.")
    assert len(parts) == 2


@pytest.mark.parametrize(
    "text",
    [
        "See Art. 9 of the Treaty for the position.",
        "Refer to Sec. 4 and Cl. 12 of the Agreement.",
        "Payable to Northwind Systems Pvt. Ltd. under the Agreement.",
        "The limit is approx. 5000 units per quarter.",
        "Delivered on 3 Jan. 2024 to the registered office.",
    ],
)
def test_abbreviations_do_not_end_a_sentence(text):
    assert len(split_sentences(text)) == 1, f"split on an abbreviation: {text!r}"


def test_sentences_returns_the_whole_string_when_there_is_no_boundary():
    text = "a clause with no terminal punctuation at all"
    assert split_sentences(text) == [text]


def test_sentences_on_empty_input():
    assert split_sentences("") == []


def test_enumerated_items_are_detected():
    text = "The Vendor shall: (a) deliver; (b) maintain; (c) comply."
    assert looks_enumerated(text)
    items = split_enumerated_items(text)
    assert len(items) >= 3


@pytest.mark.parametrize(
    "text",
    [
        "(a) deliver the Services",
        "(iv) maintain insurance",
        "(12) pay the fee",
        "1. DEFINITIONS",
        "4.2 Termination",
        "• a bullet point",
    ],
)
def test_item_starts_are_recognised(text):
    assert is_item_start(text)


def test_prose_is_not_an_item_start():
    assert not is_item_start("The Vendor shall deliver the Services.")


def test_enumerated_split_keeps_the_lead_in():
    items = split_enumerated_items(
        "The Vendor shall: (a) deliver the Services; (b) maintain insurance."
    )
    assert any("The Vendor shall" in item for item in items)


def test_split_words_produces_overlapping_windows():
    pieces = split_words(" ".join(f"w{i}" for i in range(100)), window=30, step=20)
    assert len(pieces) > 1
    assert set(pieces[0].split()) & set(pieces[1].split())


def test_split_words_covers_all_input():
    text = " ".join(f"w{i}" for i in range(100))
    combined = " ".join(split_words(text, window=30, step=20))
    assert "w0" in combined and "w99" in combined


def test_split_words_on_empty_input():
    assert split_words("", 10, 5) == []


def test_split_characters_covers_all_input():
    combined = "".join(split_characters("x" * 250, window=100, step=100))
    assert len(combined) == 250


def test_split_characters_on_empty_input():
    assert split_characters("   ", 10, 5) == []


def test_has_whitespace():
    assert has_whitespace("two words")
    assert not has_whitespace("oneword")
    assert not has_whitespace("")


def test_a_step_larger_than_the_window_is_clamped():
    """Otherwise the window would skip text between pieces."""
    text = " ".join(f"w{i}" for i in range(50))
    combined = " ".join(split_words(text, window=10, step=999))
    for i in range(50):
        assert f"w{i}" in combined


# =====================================================================
# Budget invariants (regressions)
# =====================================================================


@pytest.mark.parametrize("chunk_size", [32, 64, 150, 500])
@pytest.mark.parametrize("overlap", [0, 10, 50, 4096])
def test_overlap_is_carved_out_of_the_budget_not_added_to_it(
    chunk_size, overlap, make_settings
):
    """Regression: overlap was prefixed on top of a full-size body, so
    every chunk after the first ran up to 1.5x over budget — straight
    past the embedding model's window."""
    cfg = make_settings(
        chunk_size=chunk_size, chunk_overlap=overlap, min_chunk_tokens=1
    )
    document = build_document([(sentences(120), 1, "4. TERMINATION")])
    ceiling = chunk_size * cfg.chunk_size_tolerance

    for chunk in chunk_document(document, cfg):
        assert chunk.token_count <= ceiling + 1, (
            f"chunk {chunk.chunk_index} is {chunk.token_count} tokens at "
            f"size={chunk_size} overlap={overlap}; ceiling is {ceiling}"
        )


def test_overlap_does_not_compound_across_chunks(make_settings):
    """Regression: the tail was measured from the previous chunk
    *including its overlap*, and always took at least one sentence, so
    a long sentence made each chunk larger than the last."""
    cfg = make_settings(chunk_size=64, chunk_overlap=32, min_chunk_tokens=1)
    text = "The Vendor shall " + ", ".join(f"perform duty{i}" for i in range(300))
    chunks = chunk_document(build_document([(text, 1, None)]), cfg)

    assert len(chunks) > 3
    counts = [c.token_count for c in chunks]
    assert max(counts) <= 64 * cfg.chunk_size_tolerance + 1
    # The last chunk must not be dramatically bigger than the first.
    assert counts[-1] <= counts[0] * 2 + 10


def test_dense_tokens_per_word_still_respects_the_budget(make_settings):
    """Regression: the word window was sized by a fixed words-per-token
    ratio. Identifier-heavy text costs several tokens per 'word', so
    pieces came out far over budget."""
    cfg = make_settings(chunk_size=64, chunk_overlap=10, min_chunk_tokens=1)
    dense = " ".join(f"w{i}_{i}_{i}" for i in range(500))
    chunks = chunk_document(build_document([(dense, 1, None)]), cfg)

    ceiling = 64 * cfg.chunk_size_tolerance
    for chunk in chunks:
        assert chunk.token_count <= ceiling + 1


@pytest.mark.parametrize("chunk_size", [32, 500])
@pytest.mark.parametrize(
    "shape", ["one_block", "many_blocks", "one_long_sentence", "no_whitespace"]
)
def test_no_text_is_lost_across_shapes_and_sizes(chunk_size, shape, make_settings):
    cfg = make_settings(
        chunk_size=chunk_size, chunk_overlap=10, min_chunk_tokens=1
    )

    if shape == "one_block":
        blocks = [(" ".join(f"marker{i}" for i in range(300)), 1, None)]
        markers = range(300)
    elif shape == "many_blocks":
        blocks = [(f"Clause marker{i} applies here.", 1, None) for i in range(60)]
        markers = range(60)
    elif shape == "one_long_sentence":
        blocks = [(", ".join(f"marker{i}" for i in range(300)) + ".", 1, None)]
        markers = range(300)
    else:
        # One unbroken run: the marker sits at the start, and the
        # character windows must preserve the full length.
        blocks = [("marker0" + "x" * 2000, 1, None)]
        markers = [0]

    combined = " ".join(c.text for c in chunk_document(build_document(blocks), cfg))
    for i in markers:
        assert f"marker{i}" in combined, f"marker{i} was lost ({shape})"

    if shape == "no_whitespace":
        # Character windows overlap, so the total is at least the input.
        assert sum(len(c.text) for c in chunk_document(
            build_document(blocks), cfg)) >= 2007
