"""Text cleaning, unicode repair, section detection, temp-file safety."""

from __future__ import annotations

import os
import stat
from pathlib import Path

import pytest

from app.ingestion.cleaner import (
    clean_text,
    collapse_whitespace,
    count_removed_lines,
    detect_running_lines,
    is_noise_line,
    is_page_number_line,
    normalize_characters,
    remove_noise_lines,
    repair_line_breaks,
    strip_furniture,
)
from app.ingestion.sections import (
    assign_sections,
    detect_section,
    is_heading,
    normalize_section,
)
from app.ingestion.tempfiles import managed_upload, secure_temp_dir, secure_temp_file


# =====================================================================
# Unicode and malformed characters
# =====================================================================


def test_ligatures_are_expanded():
    out = normalize_characters("The ﬁrst conﬁdential oﬃcer")
    assert "first" in out and "confidential" in out and "officer" in out
    assert "ﬁ" not in out


def test_smart_quotes_become_ascii():
    out = normalize_characters("“Confidential Information” and ‘Party’")
    assert '"Confidential Information"' in out
    assert "'Party'" in out


def test_non_breaking_and_zero_width_spaces_are_normalised():
    out = normalize_characters("Clause 4.2​ applies here")
    assert " " not in out and "​" not in out and " " not in out
    assert "Clause 4.2 applies here" in out


def test_control_characters_are_removed():
    out = normalize_characters("Termination\x07 clause\x1f applies")
    assert "\x07" not in out and "\x1f" not in out
    assert "Termination clause applies" in out


def test_replacement_characters_are_removed():
    """U+FFFD marks a decoding failure — noise, not content."""
    assert "�" not in normalize_characters("Fee: 100�� per month")


def test_soft_hyphens_are_removed():
    assert normalize_characters("ter­mination") == "termination"


def test_nfkc_folds_compatibility_forms():
    assert "30" in normalize_characters("３０ days")


def test_line_endings_are_normalised():
    assert "\r" not in normalize_characters("line one\r\nline two\rline three")


def test_normalize_handles_empty_input():
    assert normalize_characters("") == ""
    assert normalize_characters(None) == ""


# =====================================================================
# Line-break repair
# =====================================================================


def test_hyphenated_word_across_lines_is_rejoined():
    assert "termination" in repair_line_breaks("termi-\nnation of the contract")


def test_a_real_hyphenated_term_keeps_its_hyphen():
    """'Anti-\\nCorruption' is a compound, not a wrapped word."""
    assert "Anti-" in repair_line_breaks("Anti-\nCorruption Policy")


def test_soft_wraps_are_joined():
    out = repair_line_breaks("Either party may terminate this\nagreement on notice.")
    assert "this agreement" in out


def test_sentence_boundaries_are_not_joined():
    out = repair_line_breaks("The fee is due.\nLate payment accrues interest.")
    assert "due.\nLate" in out or "due.\n\nLate" in out


def test_paragraph_breaks_survive():
    assert "\n\n" in repair_line_breaks("First clause.\n\nSecond clause.")


# =====================================================================
# Whitespace and noise
# =====================================================================


def test_repeated_whitespace_collapses():
    assert collapse_whitespace("Clause    4.2     applies") == "Clause 4.2 applies"


def test_excess_blank_lines_collapse_to_one():
    assert "\n\n\n" not in collapse_whitespace("A\n\n\n\n\nB")


def test_space_before_punctuation_is_removed():
    assert collapse_whitespace("the fee , as stated .") == "the fee, as stated."


@pytest.mark.parametrize(
    "line", ["12", "Page 4 of 20", "page 7", "3/17", "- 5 -", "[12]", "iv"]
)
def test_page_number_lines_are_detected(line):
    assert is_page_number_line(line)


@pytest.mark.parametrize(
    "line",
    [
        "12 months notice",
        "Clause 4 applies",
        "4. TERMINATION",
        "The fee is 450000 per month",
    ],
)
def test_real_content_is_not_mistaken_for_a_page_number(line):
    assert not is_page_number_line(line)


@pytest.mark.parametrize("line", ["~~~~~~~~~~~~", "...........", "|", "* * * * * *"])
def test_noise_lines_are_detected(line):
    assert is_noise_line(line)


@pytest.mark.parametrize(
    "line", ["Clause 4.1 applies.", "INR 4,50,000", "8. DISPUTE RESOLUTION"]
)
def test_real_lines_are_not_noise(line):
    assert not is_noise_line(line)


def test_remove_noise_lines_keeps_content():
    out = remove_noise_lines("Termination clause\n~~~~~~~~~~\nThe fee is due")
    assert "Termination clause" in out and "The fee is due" in out
    assert "~~~~~~~~~~" not in out


# =====================================================================
# Running headers and footers
# =====================================================================


_BODIES = [
    "termination requires written notice to the other party",
    "liability is capped at the fees paid in the prior year",
    "confidential information may not be disclosed to third parties",
    "the agreement is governed by the laws of India",
    "disputes are referred to arbitration seated in Bengaluru",
    "invoices are payable within thirty days of receipt",
]


def _pages(count: int, header: str) -> list:
    """Pages sharing a header, with genuinely different body text."""
    return [
        f"{header}\nClause body: {_BODIES[i % len(_BODIES)]}.\nPage {i + 1}"
        for i in range(count)
    ]


def test_running_header_is_detected_across_pages():
    running = detect_running_lines(_pages(5, "Northwind Systems - Confidential"))
    assert running


def test_running_header_is_stripped_but_body_survives():
    pages = _pages(5, "Northwind Systems - Confidential")
    running = detect_running_lines(pages)
    cleaned = clean_text(pages[0], running)
    assert "Northwind Systems" not in cleaned
    assert "termination requires written notice" in cleaned


def test_a_header_with_a_changing_page_number_still_matches():
    """'Page 3 of 20' and 'Page 4 of 20' share one fingerprint."""
    pages = [f"Agreement - Page {i} of 20\nBody text {i}" for i in range(1, 6)]
    running = detect_running_lines(pages)
    assert "agreement - page # of #" in running


def test_short_documents_are_left_alone():
    """Two pages is not evidence; removing there risks deleting a clause."""
    pages = ["Same line\nBody A", "Same line\nBody B"]
    assert detect_running_lines(pages, min_pages=3) == set()


def test_a_line_repeated_on_only_a_few_pages_is_kept():
    """Appearing on 2 of 6 pages is not evidence of a running header."""
    pages = [
        f"{'Shared caption line' if i < 2 else 'Another caption line'}\n"
        f"Clause body: {_BODIES[i]}."
        for i in range(6)
    ]
    running = detect_running_lines(pages, min_ratio=0.6)
    assert "shared caption line" not in running


def test_body_text_differing_only_by_a_number_is_not_furniture():
    """Masking digits everywhere would collapse these into one line and
    delete real content. Long lines must never be digit-masked."""
    pages = [
        f"Top of page\nThe Vendor shall deliver {i} units under Schedule A "
        f"before the end of the quarter.\nBottom"
        for i in range(1, 7)
    ]
    running = detect_running_lines(pages, min_ratio=0.6)
    cleaned = clean_text(pages[0], running)
    assert "shall deliver 1 units" in cleaned


def test_a_line_in_the_middle_of_a_page_is_never_furniture():
    """Only lines near the top/bottom edges are candidates."""
    pages = [
        "Top {i}\n" + "\n".join(f"filler {j}" for j in range(8))
        + "\nBURIED REPEATED LINE\n"
        + "\n".join(f"more {j}" for j in range(8))
        + f"\nBottom {i}"
        for i in range(6)
    ]
    assert "buried repeated line" not in detect_running_lines(pages)


def test_strip_furniture_can_keep_page_numbers():
    out = strip_furniture("Body text\n12", running=set(), drop_page_numbers=False)
    assert "12" in out


def test_count_removed_lines():
    assert count_removed_lines("a\nb\nc", "a\nc") == 1
    assert count_removed_lines("a\nb", "a\nb") == 0


# =====================================================================
# Clean text end to end
# =====================================================================


def test_clean_text_preserves_legal_substance():
    raw = (
        "Northwind Systems - Confidential\n"
        "4.  TERMINATION\n"
        "Either party may termi-\nnate on one hundred and twenty (120) days\n"
        "notice. The fee is INR 4,50,000 per month.\n"
        "Page 3 of 20"
    )
    cleaned = clean_text(raw, running={"northwind systems - confidential"})

    for needle in ["120", "INR 4,50,000", "TERMINATION"]:
        assert needle in cleaned
    assert "terminate" in cleaned
    assert "Northwind Systems - Confidential" not in cleaned
    assert "Page 3 of 20" not in cleaned


def test_clean_text_is_idempotent():
    raw = "Clause  4.2   applies\n\n\n\nto the Vendor."
    once = clean_text(raw)
    assert clean_text(once) == once


# =====================================================================
# Section detection
# =====================================================================


@pytest.mark.parametrize(
    "line",
    [
        "4. TERMINATION",
        "4.2 Termination for Convenience",
        "ARTICLE V - LIABILITY",
        "SECTION 7: GOVERNING LAW",
        "SCHEDULE B",
        "CONFIDENTIALITY",
        "Definitions",
        "12.3.4",
    ],
)
def test_headings_are_detected(line):
    assert is_heading(line), f"{line!r} should be a heading"


@pytest.mark.parametrize(
    "line",
    [
        "Either party may terminate this Agreement for convenience on one "
        "hundred and twenty (120) days written notice to the other party.",
        "The Client shall pay the Vendor a monthly fee of INR 4,50,000;",
        "Page 4 of 20",
        "",
        "   ",
    ],
)
def test_prose_is_not_a_heading(line):
    assert not is_heading(line), f"{line!r} should not be a heading"


def test_detect_section_normalises_the_label():
    assert detect_section("  4.  TERMINATION  ") == "4. TERMINATION"
    assert detect_section("Termination:") == "Termination"


def test_detect_section_returns_none_for_prose():
    assert detect_section("The parties agree as follows, subject to Clause 9.") is None


def test_normalize_section_truncates_long_labels():
    assert len(normalize_section("A" * 200)) <= 100


def test_assign_sections_carries_the_current_section_forward():
    labels = assign_sections(
        [
            "1. DEFINITIONS",
            "In this Agreement, Services means...",
            "The Vendor means Northwind.",
            "2. TERM",
            "This Agreement commences on...",
        ]
    )
    assert labels[0] == "1. DEFINITIONS"
    assert labels[1] == "1. DEFINITIONS"
    assert labels[2] == "1. DEFINITIONS"
    assert labels[3] == "2. TERM"
    assert labels[4] == "2. TERM"


def test_text_before_the_first_heading_has_no_section():
    labels = assign_sections(["Preamble text.", "1. DEFINITIONS", "Body."])
    assert labels[0] is None


# =====================================================================
# Safe temporary files
# =====================================================================


def test_secure_temp_file_is_private_and_removed(settings):
    with secure_temp_file(".pdf", settings) as path:
        assert path.exists()
        assert path.parent == settings.temp_dir_path
        mode = stat.S_IMODE(os.stat(path).st_mode)
        assert mode == 0o600, f"expected 0600, got {oct(mode)}"
        captured = path
    assert not captured.exists()


def test_secure_temp_file_is_removed_after_an_exception(settings):
    captured = {}
    with pytest.raises(RuntimeError):
        with secure_temp_file(".pdf", settings) as path:
            captured["path"] = path
            raise RuntimeError("boom")
    assert not captured["path"].exists()


def test_secure_temp_dir_is_private_and_removed(settings):
    with secure_temp_dir(settings) as path:
        assert path.is_dir()
        assert stat.S_IMODE(os.stat(path).st_mode) == 0o700
        (path / "scratch.txt").write_text("x")
        captured = path
    assert not captured.exists()


def test_temp_names_do_not_leak_the_original_filename(settings):
    with secure_temp_file(".pdf", settings) as path:
        assert "confidential" not in path.name.lower()
        assert path.name.endswith(".pdf")


def test_managed_upload_streams_and_cleans_up(settings):
    import io

    payload = b"%PDF-1.4\n" + b"x" * 5000
    captured = {}
    with managed_upload(io.BytesIO(payload), ".pdf", settings) as path:
        assert path.read_bytes() == payload
        assert stat.S_IMODE(os.stat(path).st_mode) == 0o600
        captured["path"] = path
    assert not captured["path"].exists()


def test_managed_upload_enforces_the_size_limit(make_settings):
    import io

    from app.ingestion.errors import FileTooLargeError

    cfg = make_settings(max_file_size_mb=1)
    oversized = io.BytesIO(b"x" * (2 * 1024 * 1024))
    with pytest.raises(FileTooLargeError):
        with managed_upload(oversized, ".pdf", cfg):
            pass


def test_an_abandoned_oversized_upload_leaves_nothing_behind(make_settings):
    import io

    from app.ingestion.errors import FileTooLargeError

    cfg = make_settings(max_file_size_mb=1)
    before = set(cfg.temp_dir_path.iterdir())
    with pytest.raises(FileTooLargeError):
        with managed_upload(io.BytesIO(b"x" * (2 * 1024 * 1024)), ".pdf", cfg):
            pass
    assert set(cfg.temp_dir_path.iterdir()) == before
