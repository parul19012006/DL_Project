"""Stage 7 — the provider abstraction and the providers themselves.

The hosted providers are exercised against ``httpx.MockTransport``, not
mocked away: the request body, the auth header, the response shape and
the error mapping are all real code running against a fake socket. A
mocked provider object would assert nothing about the part that actually
breaks when a vendor changes a field name.
"""

from __future__ import annotations

import json

import httpx
import pytest

from app.generation.anthropic_provider import API_VERSION, AnthropicProvider
from app.generation.base import (
    LLMConfigurationError,
    LLMRequest,
    LLMTimeoutError,
    LLMUnavailableError,
)
from app.generation.extractive import ExtractiveProvider, parse_user_message
from app.generation.factory import (
    EXTRACTIVE,
    available_providers,
    build_llm_provider,
    get_llm_provider,
    register_provider,
    set_llm_provider,
)
from app.generation.openai_provider import OpenAIProvider
from app.generation.prompts import build_user_message

QUESTION = "How much notice is required to terminate for convenience?"


def _request() -> LLMRequest:
    return LLMRequest(system="system rules", user="QUESTION:\nhi\n\nEVIDENCE:\nnone")


def _transport(handler) -> httpx.MockTransport:
    return httpx.MockTransport(handler)


# =====================================================================
# The interface
# =====================================================================


def test_a_provider_reports_what_it_is():
    provider = ExtractiveProvider()
    assert provider.name
    assert provider.is_language_model is False
    assert "not a language model" in provider.describe()


def test_the_request_carries_system_and_user_separately():
    """The grounding rules must survive to any vendor intact."""
    request = LLMRequest(system="rules", user="question")
    assert request.system == "rules"
    assert request.messages() == [{"role": "user", "content": "question"}]


def test_a_repair_instruction_is_an_extra_turn_not_a_rewrite():
    """The original question is never edited on a retry."""
    request = LLMRequest(system="rules", user="question", repair="reformat please")
    messages = request.messages()
    assert messages[0]["content"] == "question"
    assert messages[1]["content"] == "reformat please"


def test_a_truncated_reply_is_detectable():
    from app.generation.base import LLMResponse

    assert LLMResponse(finish_reason="length").truncated
    assert LLMResponse(finish_reason="max_tokens").truncated
    assert not LLMResponse(finish_reason="stop").truncated


# =====================================================================
# Secrets
# =====================================================================


def test_a_provider_without_a_key_refuses_to_build():
    with pytest.raises(LLMConfigurationError) as excinfo:
        OpenAIProvider(api_key="")
    assert "environment" in str(excinfo.value)


def test_a_key_is_never_in_the_provider_repr():
    provider = OpenAIProvider(api_key="sk-test-do-not-log-me")
    assert "sk-test-do-not-log-me" not in repr(provider)


def test_a_key_is_never_in_an_error_message():
    """An error carries the vendor's message, not the request."""

    def handler(request):
        return httpx.Response(500, json={"error": {"message": "upstream boom"}})

    provider = OpenAIProvider(
        api_key="sk-test-do-not-log-me", transport=_transport(handler)
    )
    with pytest.raises(LLMUnavailableError) as excinfo:
        provider.generate(_request())
    assert "sk-test-do-not-log-me" not in str(excinfo.value)
    assert "upstream boom" in str(excinfo.value)


def test_settings_never_print_a_key(make_settings):
    from pydantic import SecretStr

    settings = make_settings(openai_api_key=SecretStr("sk-secret-value"))
    assert "sk-secret-value" not in repr(settings)
    assert "sk-secret-value" not in str(settings)


# =====================================================================
# OpenAI-compatible provider
# =====================================================================


def test_openai_builds_the_expected_request():
    seen = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["url"] = str(request.url)
        seen["auth"] = request.headers.get("authorization")
        seen["body"] = json.loads(request.content)
        return httpx.Response(
            200,
            json={
                "id": "cmpl-1",
                "model": "gpt-4o-mini",
                "choices": [
                    {"message": {"content": '{"answer":"hi"}'}, "finish_reason": "stop"}
                ],
                "usage": {"prompt_tokens": 11, "completion_tokens": 3},
            },
        )

    provider = OpenAIProvider(api_key="sk-x", transport=_transport(handler))
    response = provider.generate(_request())

    assert seen["url"].endswith("/chat/completions")
    assert seen["auth"] == "Bearer sk-x"
    assert seen["body"]["messages"][0] == {"role": "system", "content": "system rules"}
    assert seen["body"]["temperature"] == 0.0
    assert seen["body"]["response_format"] == {"type": "json_object"}

    assert response.text == '{"answer":"hi"}'
    assert response.model == "gpt-4o-mini"
    assert response.prompt_tokens == 11
    assert response.total_tokens == 14
    assert response.provider == "openai"


def test_openai_base_url_can_point_at_a_self_hosted_server():
    """The same provider covers vLLM, Ollama, Groq, Azure and the rest."""
    seen = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["url"] = str(request.url)
        return httpx.Response(200, json={"choices": [{"message": {"content": "{}"}}]})

    provider = OpenAIProvider(
        api_key="sk-x", base_url="http://localhost:8000/v1", transport=_transport(handler)
    )
    provider.generate(_request())
    assert seen["url"] == "http://localhost:8000/v1/chat/completions"


def test_openai_handles_an_empty_choices_list():
    """A malformed-but-200 reply must not raise an AttributeError."""

    def handler(request):
        return httpx.Response(200, json={"choices": []})

    provider = OpenAIProvider(api_key="sk-x", transport=_transport(handler))
    assert provider.generate(_request()).text == ""


# =====================================================================
# Anthropic provider
# =====================================================================


def test_anthropic_builds_the_expected_request():
    seen = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["url"] = str(request.url)
        seen["headers"] = dict(request.headers)
        seen["body"] = json.loads(request.content)
        return httpx.Response(
            200,
            json={
                "id": "msg-1",
                "model": "claude-3-5-haiku-latest",
                "content": [{"type": "text", "text": '{"answer":"hi"}'}],
                "stop_reason": "end_turn",
                "usage": {"input_tokens": 20, "output_tokens": 5},
            },
        )

    provider = AnthropicProvider(api_key="key-x", transport=_transport(handler))
    response = provider.generate(_request())

    assert seen["url"].endswith("/v1/messages")
    assert seen["headers"]["x-api-key"] == "key-x"
    assert seen["headers"]["anthropic-version"] == API_VERSION
    # The system instruction is a top-level field here, not a message.
    assert seen["body"]["system"] == "system rules"
    assert all(m["role"] != "system" for m in seen["body"]["messages"])

    assert response.text == '{"answer":"hi"}'
    assert response.prompt_tokens == 20
    assert response.completion_tokens == 5


def test_anthropic_joins_multiple_text_blocks():
    """The reply is a list of blocks, not one string."""

    def handler(request):
        return httpx.Response(
            200,
            json={
                "content": [
                    {"type": "text", "text": '{"answer":'},
                    {"type": "thinking", "text": "ignored"},
                    {"type": "text", "text": '"hi"}'},
                ]
            },
        )

    provider = AnthropicProvider(api_key="key-x", transport=_transport(handler))
    assert provider.generate(_request()).text == '{"answer":"hi"}'


# =====================================================================
# Error mapping
# =====================================================================


@pytest.mark.parametrize("status", [401, 403])
def test_a_rejected_key_is_a_configuration_error_not_an_outage(status):
    """Retrying a bad credential burns quota against a broken request."""

    def handler(request):
        return httpx.Response(status, json={"error": {"message": "bad key"}})

    provider = OpenAIProvider(api_key="sk-x", transport=_transport(handler))
    with pytest.raises(LLMConfigurationError):
        provider.generate(_request())


@pytest.mark.parametrize("status", [429, 500, 503])
def test_a_transient_vendor_failure_is_unavailable(status):
    def handler(request):
        return httpx.Response(status, json={"error": {"message": "try later"}})

    provider = OpenAIProvider(api_key="sk-x", transport=_transport(handler))
    with pytest.raises(LLMUnavailableError):
        provider.generate(_request())


def test_a_non_retryable_error_says_so():
    def handler(request):
        return httpx.Response(400, json={"error": {"message": "bad request"}})

    provider = OpenAIProvider(api_key="sk-x", transport=_transport(handler))
    with pytest.raises(LLMUnavailableError) as excinfo:
        provider.generate(_request())
    assert "not retryable" in str(excinfo.value)


def test_a_timeout_is_its_own_error():
    def handler(request):
        raise httpx.ReadTimeout("too slow")

    provider = OpenAIProvider(api_key="sk-x", transport=_transport(handler))
    with pytest.raises(LLMTimeoutError):
        provider.generate(_request())


def test_a_connection_failure_is_unavailable():
    def handler(request):
        raise httpx.ConnectError("no route")

    provider = OpenAIProvider(api_key="sk-x", transport=_transport(handler))
    with pytest.raises(LLMUnavailableError):
        provider.generate(_request())


def test_a_non_json_body_is_unavailable_not_a_crash():
    def handler(request):
        return httpx.Response(200, text="<html>gateway</html>")

    provider = OpenAIProvider(api_key="sk-x", transport=_transport(handler))
    with pytest.raises(LLMUnavailableError):
        provider.generate(_request())


# =====================================================================
# The extractive provider
# =====================================================================


def test_the_extractive_provider_quotes_the_evidence_verbatim():
    context = (
        "Source 1:\nDocument: c.pdf (id: d1)\nPage: 2\nSection: 4. TERMINATION\n"
        "Chunk: 3 (id: abc)\nText:\n"
        "Either party may terminate for convenience on 120 days written notice. "
        "The Vendor shall return all data."
    )
    provider = ExtractiveProvider()
    reply = json.loads(
        provider.generate(
            LLMRequest(system="", user=build_user_message(QUESTION, context))
        ).text
    )

    assert "120 days written notice" in reply["answer"]
    assert reply["citations"] == [{"source": 1}]
    assert reply["insufficient_evidence"] is False


def test_the_extractive_provider_reports_insufficient_evidence():
    context = (
        "Source 1:\nDocument: c.pdf (id: d1)\nPage: 1\nSection: X\n"
        "Chunk: 0 (id: abc)\nText:\nSourdough requires a mature levain."
    )
    provider = ExtractiveProvider()
    reply = json.loads(
        provider.generate(
            LLMRequest(system="", user=build_user_message(QUESTION, context))
        ).text
    )
    assert reply["insufficient_evidence"] is True
    assert reply["citations"] == []


def test_the_extractive_provider_handles_an_empty_evidence_section():
    provider = ExtractiveProvider()
    reply = json.loads(
        provider.generate(
            LLMRequest(system="", user=build_user_message(QUESTION, ""))
        ).text
    )
    assert reply["insufficient_evidence"] is True


def test_the_extractive_provider_never_quotes_the_truncation_marker():
    """That marker is a note about the passage, not part of it."""
    context = (
        "Source 1:\nDocument: c.pdf (id: d1)\nPage: 1\nSection: 4. TERMINATION\n"
        "Chunk: 0 (id: abc)\nText:\n"
        "Either party may terminate on notice.\n"
        "[… passage shortened; 40 tokens omitted …]"
    )
    provider = ExtractiveProvider()
    answer = json.loads(
        provider.generate(
            LLMRequest(system="", user=build_user_message("terminate notice", context))
        ).text
    )["answer"]
    assert "shortened" not in answer


def test_the_evidence_block_can_be_read_back():
    """Stage 6's format is machine-readable, not just human-readable."""
    context = (
        "Source 1:\nDocument: a.pdf (id: d1)\nPage: 1\nSection: A\n"
        "Chunk: 0 (id: x)\nText:\nFirst passage."
        "\n\n---\n\n"
        "Source 2:\nDocument: b.pdf (id: d2)\nPage: 3\nSection: B\n"
        "Chunk: 5 (id: y)\nText:\nSecond passage."
    )
    question, blocks = parse_user_message(build_user_message(QUESTION, context))
    assert question == QUESTION
    assert blocks == {1: "First passage.", 2: "Second passage."}


def test_reading_back_a_malformed_prompt_does_not_raise():
    """A formatting change must not become an outage."""
    question, blocks = parse_user_message("nothing labelled here at all")
    assert question == ""
    assert blocks == {}


# =====================================================================
# The factory
# =====================================================================


def test_the_registry_lists_the_built_in_providers():
    assert set(available_providers()) >= {"extractive", "openai", "anthropic"}


def test_a_new_provider_needs_no_change_to_config(make_settings):
    """The whole point of a registry: registering is the only step."""

    class Custom(ExtractiveProvider):
        name = "custom-vendor"

    register_provider("custom-vendor", lambda settings: Custom())
    provider = build_llm_provider(make_settings(llm_provider="custom-vendor"))
    assert provider.name == "custom-vendor"


def test_an_unknown_provider_falls_back_by_default(make_settings):
    provider = build_llm_provider(
        make_settings(llm_provider="telepathy", llm_strict=False)
    )
    assert provider.name == EXTRACTIVE


def test_an_unknown_provider_is_fatal_in_strict_mode(make_settings):
    with pytest.raises(LLMConfigurationError) as excinfo:
        build_llm_provider(make_settings(llm_provider="telepathy", llm_strict=True))
    assert "openai" in str(excinfo.value)


def test_a_missing_key_falls_back_by_default(make_settings):
    from pydantic import SecretStr

    provider = build_llm_provider(
        make_settings(
            llm_provider="openai", openai_api_key=SecretStr(""), llm_strict=False
        )
    )
    assert provider.name == EXTRACTIVE
    assert provider.is_language_model is False


def test_a_missing_key_is_fatal_in_strict_mode(make_settings):
    """Production: serving sentence selection while believing you are
    serving a language model is worse than being down."""
    from pydantic import SecretStr

    with pytest.raises(LLMConfigurationError):
        build_llm_provider(
            make_settings(
                llm_provider="openai", openai_api_key=SecretStr(""), llm_strict=True
            )
        )


def test_a_configured_key_builds_the_real_provider(make_settings):
    from pydantic import SecretStr

    provider = build_llm_provider(
        make_settings(llm_provider="openai", openai_api_key=SecretStr("sk-x"))
    )
    assert provider.name == "openai"
    assert provider.is_language_model is True


def test_the_provider_singleton_is_reused(settings):
    set_llm_provider(None)
    first = get_llm_provider(settings)
    assert get_llm_provider(settings) is first
