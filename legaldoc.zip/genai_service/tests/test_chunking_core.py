"""Chunker behaviour: sizing, boundaries, overlap, determinism.

All content is synthetic legal text built in-line, so each test states
exactly the structure it depends on.
"""

from __future__ import annotations

import pytest

from app.chunking.chunker import LegalChunker, chunk_document, chunk_with_stats
from app.chunking.tokenizer import HeuristicTokenCounter, count_tokens
from app.models.document import (
    BlockKind,
    DocumentMetadata,
    DocumentType,
    ExtractedDocument,
    Page,
    TextBlock,
)


# =====================================================================
# Builders
# =====================================================================


def build_document(
    blocks,
    document_id="doc-1",
    tenant_id="tenant-a",
    filename="agreement.pdf",
    document_type=DocumentType.CONTRACT,
    extra=None,
) -> ExtractedDocument:
    """``blocks`` is a list of ``(text, page, section, kind)`` tuples."""
    pages = {}
    for index, item in enumerate(blocks):
        text, page_no, section = item[0], item[1], item[2]
        kind = item[3] if len(item) > 3 else BlockKind.PARAGRAPH
        pages.setdefault(page_no, []).append(
            TextBlock(
                text=text,
                page_number=page_no,
                block_index=index,
                section=section,
                kind=kind,
            )
        )
    return ExtractedDocument(
        metadata=DocumentMetadata(
            document_id=document_id,
            tenant_id=tenant_id,
            filename=filename,
            document_type=document_type,
            extra=extra or {},
        ),
        pages=[
            Page(
                page_number=number,
                blocks=items,
                text="\n\n".join(b.text for b in items),
            )
            for number, items in sorted(pages.items())
        ],
    )


def words(n: int, stem: str = "clause") -> str:
    """A deterministic run of ``n`` pseudo-words."""
    return " ".join(f"{stem}{i}" for i in range(n))


def sentences(n: int, per: int = 12, stem: str = "term") -> str:
    """``n`` real sentences of roughly ``per`` words each."""
    return " ".join(
        f"The {stem} {i} provides that the parties shall observe "
        f"{' '.join(f'{stem}{i}x{j}' for j in range(max(0, per - 9)))} hereunder."
        for i in range(n)
    )


# =====================================================================
# Short documents
# =====================================================================


def test_short_document_produces_one_chunk(settings):
    document = build_document(
        [("The Vendor shall deliver the Services with reasonable skill "
          "and care in accordance with Schedule A.", 1, "3. SERVICES")]
    )
    chunks = chunk_document(document, settings)

    assert len(chunks) == 1
    assert chunks[0].chunk_index == 0
    assert "reasonable skill" in chunks[0].text


def test_a_very_short_document_is_not_discarded(settings):
    """Below min_chunk_tokens but the only content — it must survive."""
    document = build_document([("Governed by the laws of India.", 1, None)])
    chunks = chunk_document(document, settings)

    assert len(chunks) == 1
    assert "laws of India" in chunks[0].text


def test_short_document_keeps_no_overlap(settings):
    chunks = chunk_document(
        build_document([("A single short clause.", 1, "1. SCOPE")]), settings
    )
    assert chunks[0].overlap_tokens == 0


def test_whole_short_document_fits_under_the_budget(settings):
    document = build_document([(sentences(6), 1, "2. TERM")])
    chunks = chunk_document(document, settings)
    assert len(chunks) == 1
    assert chunks[0].token_count <= settings.chunk_size


# =====================================================================
# Long documents
# =====================================================================


def test_long_document_is_split_into_several_chunks(make_settings):
    cfg = make_settings(chunk_size=120, chunk_overlap=20, min_chunk_tokens=20)
    document = build_document([(sentences(80), 1, "4. TERMINATION")])
    chunks = chunk_document(document, cfg)

    assert len(chunks) > 3
    assert all(c.text.strip() for c in chunks)


def test_chunks_respect_the_token_budget(make_settings):
    """Within tolerance — merging may push a chunk over the target."""
    cfg = make_settings(chunk_size=150, chunk_overlap=25, min_chunk_tokens=30)
    document = build_document([(sentences(120), 1, "5. LIABILITY")])
    chunks = chunk_document(document, cfg)

    ceiling = cfg.chunk_size * cfg.chunk_size_tolerance
    for chunk in chunks:
        assert chunk.token_count <= ceiling, (
            f"chunk {chunk.chunk_index} is {chunk.token_count} tokens, "
            f"ceiling is {ceiling}"
        )


def test_chunk_size_is_configurable(make_settings):
    document = build_document([(sentences(100), 1, "4. TERMINATION")])

    small = chunk_document(document, make_settings(chunk_size=100, chunk_overlap=10))
    large = chunk_document(document, make_settings(chunk_size=600, chunk_overlap=10))

    assert len(small) > len(large)


def test_larger_chunks_hold_more_tokens(make_settings):
    document = build_document([(sentences(100), 1, "4. TERMINATION")])

    small = chunk_document(document, make_settings(chunk_size=100, chunk_overlap=0))
    large = chunk_document(document, make_settings(chunk_size=400, chunk_overlap=0))

    assert max(c.token_count for c in large) > max(c.token_count for c in small)


def test_chunk_indices_are_contiguous_from_zero(make_settings):
    cfg = make_settings(chunk_size=100, chunk_overlap=15, min_chunk_tokens=20)
    document = build_document([(sentences(60), 1, "4. TERMINATION")])
    chunks = chunk_document(document, cfg)

    assert [c.chunk_index for c in chunks] == list(range(len(chunks)))


def test_no_text_is_lost(make_settings):
    """Every source paragraph must appear in at least one chunk."""
    cfg = make_settings(chunk_size=90, chunk_overlap=10, min_chunk_tokens=15)
    paragraphs = [
        f"Clause {i} states that the Vendor shall maintain records for "
        f"marker{i} years following termination."
        for i in range(12)
    ]
    document = build_document([(p, 1, "7. RECORDS") for p in paragraphs])
    combined = " ".join(c.text for c in chunk_document(document, cfg))

    for i in range(12):
        assert f"marker{i}" in combined, f"paragraph {i} was lost"


# =====================================================================
# Paragraph boundaries
# =====================================================================


def test_chunks_break_between_paragraphs_not_inside_them(make_settings):
    """Each paragraph fits; none should be cut."""
    cfg = make_settings(chunk_size=60, chunk_overlap=0, min_chunk_tokens=5)
    paragraphs = [
        "The Vendor shall provide the Services in accordance with Schedule A.",
        "The Client shall pay each invoice within thirty days of receipt.",
        "Neither party shall assign this Agreement without prior consent.",
    ]
    document = build_document([(p, 1, "2. OBLIGATIONS") for p in paragraphs])
    chunks = chunk_document(document, cfg)

    for paragraph in paragraphs:
        assert any(paragraph in c.text for c in chunks), (
            f"paragraph was split: {paragraph!r}"
        )


def test_paragraphs_are_packed_together_when_they_fit(make_settings):
    cfg = make_settings(chunk_size=500, chunk_overlap=0, min_chunk_tokens=10)
    document = build_document(
        [
            ("First short paragraph of the clause.", 1, "2. TERM"),
            ("Second short paragraph of the clause.", 1, "2. TERM"),
            ("Third short paragraph of the clause.", 1, "2. TERM"),
        ]
    )
    chunks = chunk_document(document, cfg)

    assert len(chunks) == 1
    assert all(f"{n} short paragraph" in chunks[0].text
               for n in ("First", "Second", "Third"))


def test_a_paragraph_is_split_at_sentence_boundaries(make_settings):
    """When a paragraph must be split, cuts land between sentences."""
    cfg = make_settings(chunk_size=60, chunk_overlap=0, min_chunk_tokens=5)
    text = (
        "The Vendor shall maintain insurance. "
        "The Client shall provide access to its premises. "
        "Each party shall appoint a relationship manager. "
        "The parties shall meet quarterly to review performance. "
        "Any variation must be agreed in writing."
    )
    chunks = chunk_document(build_document([(text, 1, "6. GENERAL")]), cfg)

    assert len(chunks) > 1
    for chunk in chunks:
        stripped = chunk.text.strip()
        assert stripped.endswith("."), f"chunk does not end a sentence: {stripped!r}"
    assert not any(c.split_mid_sentence for c in chunks)


def test_enumerated_items_are_preferred_over_sentence_cuts(make_settings):
    """(a)/(b)/(c) items are the smaller self-contained unit."""
    cfg = make_settings(chunk_size=45, chunk_overlap=0, min_chunk_tokens=5)
    text = (
        "The Vendor shall: "
        "(a) deliver the Services in accordance with Schedule A hereto; "
        "(b) maintain professional indemnity insurance at all times; "
        "(c) comply with all applicable laws and regulations."
    )
    chunks = chunk_document(build_document([(text, 1, "3. OBLIGATIONS")]), cfg)

    assert len(chunks) > 1
    combined = " ".join(c.text for c in chunks)
    for marker in ("(a)", "(b)", "(c)"):
        assert marker in combined
    # No item should be cut in half.
    assert "indemnity insurance at all times" in combined


# =====================================================================
# Section boundaries
# =====================================================================


def test_a_chunk_never_spans_two_sections(settings):
    document = build_document(
        [
            ("Either party may terminate on one hundred and twenty days notice.",
             1, "4. TERMINATION"),
            ("Liability is capped at the fees paid in the preceding year.",
             1, "5. LIABILITY"),
        ]
    )
    chunks = chunk_document(document, settings)

    assert len(chunks) == 2
    termination = next(c for c in chunks if c.section == "4. TERMINATION")
    assert "Liability is capped" not in termination.text


def test_section_labels_are_preserved_on_every_chunk(make_settings):
    cfg = make_settings(chunk_size=60, chunk_overlap=10, min_chunk_tokens=5)
    document = build_document([(sentences(20), 1, "4. TERMINATION")])
    chunks = chunk_document(document, cfg)

    assert len(chunks) > 1
    assert all(c.section == "4. TERMINATION" for c in chunks)


def test_sections_can_be_ignored_by_configuration(make_settings):
    """respect_sections=False lets a chunk pack across sections."""
    cfg = make_settings(
        chunk_size=500, chunk_overlap=0, respect_sections=False, min_chunk_tokens=5
    )
    document = build_document(
        [
            ("Short clause one text here.", 1, "1. ONE"),
            ("Short clause two text here.", 1, "2. TWO"),
        ]
    )
    chunks = chunk_document(document, cfg)

    assert len(chunks) == 1
    assert "clause one" in chunks[0].text and "clause two" in chunks[0].text


def test_a_document_with_no_sections_still_chunks(make_settings):
    """Many legal documents have no detectable headings at all."""
    cfg = make_settings(chunk_size=70, chunk_overlap=10, min_chunk_tokens=5)
    document = build_document([(sentences(30), 1, None)])
    chunks = chunk_document(document, cfg)

    assert len(chunks) > 1
    assert all(c.section is None for c in chunks)


def test_a_heading_is_attached_to_the_text_it_introduces(settings):
    document = build_document(
        [
            ("4. TERMINATION", 1, "4. TERMINATION", BlockKind.HEADING),
            ("Either party may terminate on notice.", 1, "4. TERMINATION"),
        ]
    )
    chunks = chunk_document(document, settings)

    assert len(chunks) == 1
    assert chunks[0].text.startswith("4. TERMINATION")
    assert "Either party may terminate" in chunks[0].text


def test_an_orphan_heading_is_not_emitted_as_its_own_chunk(settings):
    """A document title in its own section must not survive alone."""
    document = build_document(
        [
            ("MASTER SERVICES AGREEMENT", 1, "MASTER SERVICES AGREEMENT",
             BlockKind.HEADING),
            ("1. DEFINITIONS", 1, "1. DEFINITIONS", BlockKind.HEADING),
            ("In this Agreement, Services means the managed hosting services "
             "described in Schedule A to this Agreement.", 1, "1. DEFINITIONS"),
        ]
    )
    chunks = chunk_document(document, settings)

    assert len(chunks) == 1
    assert "MASTER SERVICES AGREEMENT" in chunks[0].text
    assert "Schedule A" in chunks[0].text
    assert not any(c.heading_only for c in chunks)


# =====================================================================
# Overlap
# =====================================================================


def test_consecutive_chunks_overlap(make_settings):
    cfg = make_settings(chunk_size=80, chunk_overlap=25, min_chunk_tokens=10)
    document = build_document([(sentences(40), 1, "4. TERMINATION")])
    chunks = chunk_document(document, cfg)

    assert len(chunks) > 1
    for nxt in chunks[1:]:
        assert nxt.overlap_tokens > 0, "a following chunk carries no overlap"


def test_overlap_text_actually_appears_in_both_chunks(make_settings):
    cfg = make_settings(chunk_size=80, chunk_overlap=25, min_chunk_tokens=10)
    document = build_document([(sentences(40), 1, "4. TERMINATION")])
    chunks = chunk_document(document, cfg)

    overlaps = 0
    for previous, nxt in zip(chunks, chunks[1:]):
        tail_words = set(previous.text.split()[-40:])
        head_words = set(nxt.text.split()[:40])
        if tail_words & head_words:
            overlaps += 1
    assert overlaps >= 1


def test_zero_overlap_is_supported(make_settings):
    cfg = make_settings(chunk_size=80, chunk_overlap=0, min_chunk_tokens=10)
    document = build_document([(sentences(40), 1, "4. TERMINATION")])
    chunks = chunk_document(document, cfg)

    assert len(chunks) > 1
    assert all(c.overlap_tokens == 0 for c in chunks)


def test_overlap_is_configurable(make_settings):
    document = build_document([(sentences(50), 1, "4. TERMINATION")])

    none = chunk_document(
        document, make_settings(chunk_size=100, chunk_overlap=0, min_chunk_tokens=10)
    )
    lots = chunk_document(
        document, make_settings(chunk_size=100, chunk_overlap=40, min_chunk_tokens=10)
    )

    assert sum(c.overlap_tokens for c in lots) > sum(c.overlap_tokens for c in none)


def test_excessive_overlap_is_clamped_and_still_terminates(make_settings):
    """overlap >= chunk_size would otherwise never advance."""
    cfg = make_settings(chunk_size=60, chunk_overlap=500, min_chunk_tokens=5)
    chunker = LegalChunker(cfg)
    assert chunker.overlap <= cfg.chunk_size // 2

    chunks = chunker.chunk_document(
        build_document([(sentences(40), 1, "4. TERMINATION")])
    )
    assert len(chunks) > 1


def test_overlap_does_not_cross_a_section_boundary(settings):
    """Context from a different clause would be misleading evidence."""
    document = build_document(
        [
            ("Termination requires one hundred and twenty days notice in "
             "writing delivered to the registered office of the other party.",
             1, "4. TERMINATION"),
            ("Liability is capped at the total fees paid during the twelve "
             "months preceding the claim giving rise to the liability.",
             1, "5. LIABILITY"),
        ]
    )
    chunks = chunk_document(document, settings)

    liability = next(c for c in chunks if c.section == "5. LIABILITY")
    assert liability.overlap_tokens == 0
    assert "Termination requires" not in liability.text


# =====================================================================
# Metadata preservation
# =====================================================================


def test_every_required_field_is_present(settings):
    document = build_document(
        [("The Vendor shall deliver the Services.", 7, "3. SERVICES")],
        document_id="doc-77",
        tenant_id="tenant-alpha",
        filename="vendor_contract_2024.pdf",
        document_type=DocumentType.CONTRACT,
    )
    chunk = chunk_document(document, settings)[0]

    assert chunk.chunk_id
    assert chunk.document_id == "doc-77"
    assert chunk.tenant_id == "tenant-alpha"
    assert chunk.filename == "vendor_contract_2024.pdf"
    assert chunk.page_number == 7
    assert chunk.section == "3. SERVICES"
    assert chunk.chunk_index == 0
    assert chunk.text
    assert chunk.document_type is DocumentType.CONTRACT


def test_metadata_survives_splitting(make_settings):
    cfg = make_settings(chunk_size=60, chunk_overlap=10, min_chunk_tokens=5)
    document = build_document(
        [(sentences(30), 4, "4. TERMINATION")],
        document_id="doc-9",
        tenant_id="tenant-beta",
        filename="msa.pdf",
    )
    chunks = chunk_document(document, cfg)

    assert len(chunks) > 1
    for chunk in chunks:
        assert chunk.document_id == "doc-9"
        assert chunk.tenant_id == "tenant-beta"
        assert chunk.filename == "msa.pdf"
        assert chunk.page_number == 4
        assert chunk.section == "4. TERMINATION"


def test_page_numbers_come_from_the_source_blocks(settings):
    document = build_document(
        [
            ("Clause on the seventeenth page of the agreement.", 17, "4. TERMINATION"),
            ("Clause on the twenty-first page of the agreement.", 21, "5. LIABILITY"),
        ]
    )
    pages = {c.page_number for c in chunk_document(document, settings)}
    assert pages == {17, 21}


def test_a_chunk_spanning_a_page_break_records_both_pages(make_settings):
    cfg = make_settings(chunk_size=500, chunk_overlap=0, min_chunk_tokens=5)
    document = build_document(
        [
            ("The first half of a clause that continues overleaf.", 4,
             "4. TERMINATION"),
            ("The second half of the clause, continued from the prior page.", 5,
             "4. TERMINATION"),
        ]
    )
    chunk = chunk_document(document, cfg)[0]

    assert chunk.page_number == 4
    assert chunk.page_end == 5
    assert chunk.spans_pages
    assert chunk.page_range == "4-5"


def test_extra_scalar_metadata_is_carried_through(settings):
    document = build_document(
        [("A clause.", 1, "1. ONE")], extra={"matter_id": "M-77", "billable": True}
    )
    chunk = chunk_document(document, settings)[0]

    assert chunk.extra["matter_id"] == "M-77"
    assert chunk.metadata()["matter_id"] == "M-77"
    assert chunk.metadata()["billable"] is True


def test_metadata_dict_is_flat_and_scalar(settings):
    """Vector stores only accept scalar metadata values."""
    document = build_document([("A clause.", 3, "1. ONE")])
    metadata = chunk_document(document, settings)[0].metadata()

    for key, value in metadata.items():
        assert isinstance(value, (str, int, float, bool)), (
            f"{key} is {type(value).__name__}, not a scalar"
        )
    for required in (
        "chunk_id", "chunk_index", "document_id", "tenant_id", "filename",
        "page_number", "section", "document_type",
    ):
        assert required in metadata


def test_citation_has_what_a_user_needs(settings):
    document = build_document([("A clause.", 12, "4. TERMINATION")])
    citation = chunk_document(document, settings)[0].citation()

    assert citation["page"] == "12"
    assert citation["section"] == "4. TERMINATION"
    assert citation["filename"] == "agreement.pdf"
    assert citation["chunk_id"]


def test_block_ids_trace_back_to_source_blocks(settings):
    document = build_document(
        [
            ("First paragraph of the clause.", 1, "2. TERM"),
            ("Second paragraph of the clause.", 1, "2. TERM"),
        ]
    )
    chunk = chunk_document(document, settings)[0]

    assert len(chunk.block_ids) == 2
    assert all(":p1:b" in block_id for block_id in chunk.block_ids)


def test_ocr_flag_propagates_from_blocks(settings):
    document = build_document([("Text recovered by OCR.", 1, None)])
    document.pages[0].blocks[0].ocr = True

    assert chunk_document(document, settings)[0].ocr is True


# =====================================================================
# Determinism
# =====================================================================


def test_chunking_is_deterministic(make_settings):
    cfg = make_settings(chunk_size=90, chunk_overlap=20, min_chunk_tokens=15)
    document = build_document([(sentences(50), 1, "4. TERMINATION")])

    first = chunk_document(document, cfg)
    second = chunk_document(build_document([(sentences(50), 1, "4. TERMINATION")]), cfg)

    assert [c.text for c in first] == [c.text for c in second]
    assert [c.chunk_id for c in first] == [c.chunk_id for c in second]


def test_chunk_ids_are_unique(make_settings):
    cfg = make_settings(chunk_size=80, chunk_overlap=15, min_chunk_tokens=10)
    document = build_document([(sentences(60), 1, "4. TERMINATION")])
    ids = [c.chunk_id for c in chunk_document(document, cfg)]

    assert len(ids) == len(set(ids))


def test_a_different_document_id_gives_different_chunk_ids(settings):
    a = chunk_document(build_document([("Same text.", 1, None)], document_id="a"), settings)
    b = chunk_document(build_document([("Same text.", 1, None)], document_id="b"), settings)
    assert a[0].chunk_id != b[0].chunk_id


def test_changed_text_changes_the_chunk_id(settings):
    """A stale vector must not masquerade as the current passage."""
    a = chunk_document(build_document([("Original clause text.", 1, None)]), settings)
    b = chunk_document(build_document([("Amended clause text.", 1, None)]), settings)
    assert a[0].chunk_id != b[0].chunk_id


def test_ids_survive_reordering_of_equal_input(settings):
    """Same input, same ids — no dependence on object identity or time."""
    document = build_document([("A clause.", 1, "1. ONE")])
    assert (
        chunk_document(document, settings)[0].chunk_id
        == chunk_document(document, settings)[0].chunk_id
    )


# =====================================================================
# Small-chunk prevention
# =====================================================================


def test_small_chunks_are_merged_within_a_section(make_settings):
    cfg = make_settings(chunk_size=200, chunk_overlap=0, min_chunk_tokens=40)
    document = build_document(
        [(f"Short line {i}.", 1, "6. NOTICES") for i in range(6)]
    )
    chunks = chunk_document(document, cfg)

    assert len(chunks) == 1
    assert chunks[0].token_count >= 1


def test_merging_never_joins_two_sections(make_settings):
    cfg = make_settings(chunk_size=500, chunk_overlap=0, min_chunk_tokens=200)
    document = build_document(
        [
            ("Termination requires notice.", 1, "4. TERMINATION"),
            ("Liability is capped.", 1, "5. LIABILITY"),
        ]
    )
    chunks = chunk_document(document, cfg)

    assert len(chunks) == 2
    assert {c.section for c in chunks} == {"4. TERMINATION", "5. LIABILITY"}


def test_merging_respects_the_size_ceiling(make_settings):
    cfg = make_settings(
        chunk_size=100, chunk_overlap=0, min_chunk_tokens=95, chunk_size_tolerance=1.1
    )
    document = build_document([(sentences(40), 1, "4. TERMINATION")])
    chunks = chunk_document(document, cfg)

    for chunk in chunks:
        assert chunk.token_count <= 100 * 1.1 + 1


def test_merging_can_be_disabled(make_settings):
    cfg = make_settings(
        chunk_size=200, chunk_overlap=0, min_chunk_tokens=40, merge_small_chunks=False
    )
    document = build_document(
        [(f"Short line {i}.", 1, "6. NOTICES") for i in range(6)]
    )
    assert len(chunk_document(document, cfg)) >= 1


def test_stats_report_the_merge_count(make_settings):
    """A budget small enough that packing produces several tiny chunks,
    which the merge pass then folds back together."""
    cfg = make_settings(
        chunk_size=32,            # the configured minimum
        chunk_overlap=0,
        min_chunk_tokens=200,     # far above anything packing can produce
        chunk_size_tolerance=3.0,
    )
    document = build_document(
        [(f"Short line {i}.", 1, "6. NOTICES") for i in range(16)]
    )
    chunks, stats = chunk_with_stats(document, cfg)

    assert stats.merged_small_count >= 1
    combined = " ".join(c.text for c in chunks)
    for i in range(16):
        assert f"Short line {i}." in combined


# =====================================================================
# Stats
# =====================================================================


def test_stats_describe_the_result(make_settings):
    cfg = make_settings(chunk_size=90, chunk_overlap=20, min_chunk_tokens=15)
    document = build_document(
        [
            (sentences(25), 1, "4. TERMINATION"),
            (sentences(25), 2, "5. LIABILITY"),
        ]
    )
    chunks, stats = chunk_with_stats(document, cfg)

    assert stats.chunk_count == len(chunks)
    assert stats.total_tokens == sum(c.token_count for c in chunks)
    assert stats.min_tokens <= stats.mean_tokens <= stats.max_tokens
    assert stats.sections_covered == 2
    assert stats.pages_covered == 2
    assert stats.chunk_size == 90
    assert stats.chunk_overlap == 20
    assert stats.tokenizer == "heuristic"


def test_stats_on_an_empty_document(settings):
    document = build_document([])
    chunks, stats = chunk_with_stats(document, settings)
    assert chunks == []
    assert stats.chunk_count == 0
    assert stats.total_tokens == 0


# =====================================================================
# chunk_text convenience API
# =====================================================================


def test_chunk_text_splits_on_paragraphs(make_settings):
    cfg = make_settings(chunk_size=50, chunk_overlap=0, min_chunk_tokens=5)
    text = "\n\n".join(
        f"Paragraph {i} of the agreement sets out an obligation of the Vendor."
        for i in range(6)
    )
    chunks = LegalChunker(cfg).chunk_text(text, "doc-t", "tenant-t")

    assert len(chunks) > 1
    assert all(c.document_id == "doc-t" and c.tenant_id == "tenant-t" for c in chunks)


def test_chunk_text_on_empty_input(settings):
    assert LegalChunker(settings).chunk_text("", "d", "t") == []
    assert LegalChunker(settings).chunk_text("   \n\n  ", "d", "t") == []
