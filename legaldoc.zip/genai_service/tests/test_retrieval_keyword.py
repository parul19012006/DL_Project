"""Stage 5 — keyword retrieval (Okapi BM25).

Keyword retrieval exists to find what embeddings miss: exact clause
numbers, defined terms, amounts, place names. These tests assert that
behaviour directly rather than just that the arithmetic runs.
"""

from __future__ import annotations

import pytest

from app.retrieval.keyword import BM25Index, KeywordRetriever
from app.retrieval.query import preprocess_query, tokenize
from app.vectorstore.base import SearchFilter
from tests import fixtures


@pytest.fixture
def contract_chunks():
    return fixtures.make_chunks(fixtures.VENDOR_CONTRACT, tenant_id="tenant-a")


@pytest.fixture
def index(contract_chunks):
    return BM25Index(chunks=contract_chunks)


def _top_section(index: BM25Index, query: str) -> str:
    results = index.search(preprocess_query(query).terms, top_k=3)
    assert results, f"no BM25 results for {query!r}"
    return index.chunks[results[0][0]].section


# ---------------------------------------------------------------------
# The index itself
# ---------------------------------------------------------------------


def test_index_reports_its_size_and_average_length(index, contract_chunks):
    assert index.size == len(contract_chunks)
    assert index.average_length > 0


def test_idf_is_never_negative(index):
    """A term in most of the corpus must not subtract from a score.

    The textbook IDF goes negative above 50% document frequency, which
    on a small tenant corpus would penalise a chunk for containing
    "agreement".
    """
    for term in ("agree", "party", "terminate", "zzzz-not-present"):
        assert index.idf(term) >= 0.0


def test_an_empty_index_scores_nothing():
    assert BM25Index(chunks=[]).search(["terminate"], top_k=5) == []


def test_no_query_terms_returns_nothing(index):
    assert index.search([], top_k=5) == []


def test_zero_scoring_documents_are_dropped(index):
    """A query matching nothing returns an empty list, not the corpus."""
    assert index.search(tokenize("photosynthesis chlorophyll"), top_k=5) == []


def test_results_are_ordered_best_first(index):
    results = index.search(preprocess_query("termination notice").terms, top_k=8)
    scores = [score for _, score in results]
    assert scores == sorted(scores, reverse=True)


def test_search_is_deterministic(index):
    terms = preprocess_query("notice of termination").terms
    assert index.search(terms, top_k=5) == index.search(terms, top_k=5)


# ---------------------------------------------------------------------
# What it is actually for
# ---------------------------------------------------------------------


@pytest.mark.parametrize(
    "query,expected_section",
    [
        ("termination notice", "4. TERMINATION"),
        ("governing law jurisdiction", "7. GOVERNING LAW"),
        ("monthly fee invoice", "3. FEES AND PAYMENT"),
        ("arbitration Bengaluru", "8. DISPUTE RESOLUTION"),
        ("confidential information third party", "6. CONFIDENTIALITY"),
    ],
)
def test_keyword_retrieval_finds_the_right_clause(index, query, expected_section):
    assert _top_section(index, query) == expected_section


def test_an_exact_amount_is_found(index):
    """The case embeddings are worst at: a literal number."""
    results = index.search(tokenize("INR 4,50,000"), top_k=3)
    assert results
    assert index.chunks[results[0][0]].section == "3. FEES AND PAYMENT"


def test_a_defined_party_name_is_found(index):
    results = index.search(tokenize("Northwind Systems"), top_k=3)
    assert results
    assert "Northwind" in index.chunks[results[0][0]].text


def test_the_section_heading_contributes_to_matching(contract_chunks):
    """A chunk headed TERMINATION is about termination even where the
    body words differ, so the heading is indexed with the body."""
    index = BM25Index(chunks=contract_chunks)
    heading_terms = tokenize("LIMITATION OF LIABILITY")
    results = index.search(heading_terms, top_k=1)
    assert index.chunks[results[0][0]].section == "5. LIMITATION OF LIABILITY"


def test_term_saturation_beats_raw_repetition(contract_chunks):
    """BM25's k1 saturation: the tenth "Vendor" adds almost nothing.

    Without it, a chunk that merely repeats a term would outrank one
    that actually answers the question.
    """
    from app.models.chunk import Chunk, make_chunk_id
    from app.models.document import DocumentType

    spam_text = "vendor " * 200
    answer_text = (
        "4. TERMINATION\n\nEither party may terminate this Agreement for "
        "convenience on one hundred and twenty (120) days written notice."
    )
    spam = Chunk(
        chunk_id=make_chunk_id("d", 99, spam_text),
        chunk_index=99,
        text=spam_text,
        document_id="d",
        tenant_id="tenant-a",
        filename="f.pdf",
        page_number=1,
        document_type=DocumentType.CONTRACT,
    )
    index = BM25Index(chunks=list(contract_chunks) + [spam])
    results = index.search(tokenize("vendor termination notice"), top_k=3)
    top_text = index.chunks[results[0][0]].text
    assert "TERMINATION" in top_text
    assert answer_text  # documents what "the right answer" looks like


# ---------------------------------------------------------------------
# The retriever (corpus, filters, isolation)
# ---------------------------------------------------------------------


def test_retriever_scopes_the_corpus_to_the_tenant(
    settings, indexed_store, corpus_chunks
):
    retriever = KeywordRetriever(indexed_store, settings)
    tenant_b_ids = {c.chunk_id for c in corpus_chunks["other_tenant"]}

    candidates = retriever.retrieve(
        preprocess_query("termination notice"),
        SearchFilter(tenant_id="tenant-a"),
        limit=20,
    )

    assert candidates
    assert all(c.chunk.tenant_id == "tenant-a" for c in candidates)
    assert not ({c.chunk_id for c in candidates} & tenant_b_ids)


def test_retriever_honours_a_document_type_filter(settings, indexed_store):
    retriever = KeywordRetriever(indexed_store, settings)
    candidates = retriever.retrieve(
        preprocess_query("termination"),
        SearchFilter(tenant_id="tenant-a", document_type="nda"),
        limit=20,
    )
    assert candidates
    assert all(c.chunk.document_id == "doc-nda" for c in candidates)


def test_retriever_respects_the_limit(settings, indexed_store):
    retriever = KeywordRetriever(indexed_store, settings)
    candidates = retriever.retrieve(
        preprocess_query("agreement party notice termination"),
        SearchFilter(tenant_id="tenant-a"),
        limit=2,
    )
    assert len(candidates) <= 2


def test_retriever_assigns_ranks_and_normalised_scores(settings, indexed_store):
    retriever = KeywordRetriever(indexed_store, settings)
    candidates = retriever.retrieve(
        preprocess_query("termination notice"),
        SearchFilter(tenant_id="tenant-a"),
        limit=10,
    )
    assert [c.keyword_rank for c in candidates] == list(
        range(1, len(candidates) + 1)
    )
    assert all(0.0 <= c.keyword_score <= 1.0 for c in candidates)
    # The raw BM25 number is kept: the normalised one is only meaningful
    # relative to this query's other candidates.
    assert all(c.keyword_score_raw > 0 for c in candidates)


def test_retriever_returns_nothing_for_an_unrelated_query(
    settings, indexed_store
):
    retriever = KeywordRetriever(indexed_store, settings)
    candidates = retriever.retrieve(
        preprocess_query("chocolate sourdough starter hydration"),
        SearchFilter(tenant_id="tenant-a"),
        limit=10,
    )
    assert candidates == []


def test_retriever_returns_nothing_for_an_empty_tenant(settings, indexed_store):
    retriever = KeywordRetriever(indexed_store, settings)
    candidates = retriever.retrieve(
        preprocess_query("termination"),
        SearchFilter(tenant_id="tenant-with-no-documents"),
        limit=10,
    )
    assert candidates == []


def test_corpus_truncation_is_reported(make_settings, indexed_store):
    """Hitting KEYWORD_CORPUS_LIMIT must be visible, not silent."""
    settings = make_settings(keyword_corpus_limit=3)
    retriever = KeywordRetriever(indexed_store, settings)
    retriever.retrieve(
        preprocess_query("termination"), SearchFilter(tenant_id="tenant-a"), limit=5
    )
    assert retriever.last_corpus_truncated
    assert retriever.last_corpus_size == 3


def test_corpus_exactly_at_the_limit_is_not_reported_as_truncated(
    make_settings, indexed_store, corpus_chunks
):
    total = len(corpus_chunks["contract"]) + len(corpus_chunks["nda"])
    settings = make_settings(keyword_corpus_limit=total)
    retriever = KeywordRetriever(indexed_store, settings)
    retriever.retrieve(
        preprocess_query("termination"), SearchFilter(tenant_id="tenant-a"), limit=5
    )
    assert not retriever.last_corpus_truncated
