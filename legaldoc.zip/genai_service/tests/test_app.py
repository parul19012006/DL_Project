"""Application wiring: root endpoint, docs, error handling, auth, logging."""

from __future__ import annotations

import logging

import pytest
from fastapi import APIRouter
from fastapi.testclient import TestClient
from pydantic import BaseModel

from app.exceptions import (
    AuthenticationError,
    GenAIServiceError,
    NotFoundError,
    ValidationError,
)
from app.logging_config import JsonFormatter, setup_logging
from app.main import STAGE, create_app


# ---------------------------------------------------------------------
# Root / docs
# ---------------------------------------------------------------------


def test_root_describes_the_service(client, settings):
    body = client.get("/").json()
    assert body["service"] == settings.app_name
    assert body["version"] == settings.app_version
    assert body["stage"] == STAGE
    assert "MERN" in body["scope"]


def test_openapi_is_served(client):
    spec = client.get("/openapi.json").json()
    assert "/health" in spec["paths"]
    assert "/health/live" in spec["paths"]
    assert "/health/ready" in spec["paths"]


def test_docs_can_be_disabled(client_factory, make_settings):
    with client_factory(make_settings(enable_docs=False)) as c:
        assert c.get("/openapi.json").status_code == 404
        assert c.get("/docs").status_code == 404


def test_docs_are_served_when_enabled(client):
    assert client.get("/docs").status_code == 200


# ---------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------


def test_unknown_route_uses_the_standard_error_shape(client):
    response = client.get("/does-not-exist")
    assert response.status_code == 404
    body = response.json()
    assert body["error"]["type"] == "not_found"
    assert body["error"]["message"]
    assert body["request_id"]


def test_wrong_method_is_handled(client):
    response = client.post("/health")
    assert response.status_code == 405
    assert response.json()["error"]["type"] == "method_not_allowed"


@pytest.fixture
def error_client(make_settings):
    """An app with routes that raise, to exercise the handlers."""
    app = create_app(make_settings())
    router = APIRouter()

    @router.get("/_boom/service")
    async def boom_service():
        raise ValidationError("tenant_id is required", {"field": "tenant_id"})

    @router.get("/_boom/notfound")
    async def boom_notfound():
        raise NotFoundError("no such document")

    @router.get("/_boom/auth")
    async def boom_auth():
        raise AuthenticationError()

    @router.get("/_boom/unhandled")
    async def boom_unhandled():
        raise RuntimeError("a secret internal detail /srv/genai/app/x.py")

    app.include_router(router)
    with TestClient(app, raise_server_exceptions=False) as c:
        yield c


def test_service_error_maps_to_its_status_and_type(error_client):
    response = error_client.get("/_boom/service")
    assert response.status_code == 400
    body = response.json()
    assert body["error"]["type"] == "validation_error"
    assert body["error"]["message"] == "tenant_id is required"
    assert body["error"]["details"] == {"field": "tenant_id"}


def test_not_found_error(error_client):
    response = error_client.get("/_boom/notfound")
    assert response.status_code == 404
    assert response.json()["error"]["type"] == "not_found"


def test_authentication_error(error_client):
    response = error_client.get("/_boom/auth")
    assert response.status_code == 401
    assert response.json()["error"]["type"] == "authentication_error"


def test_unhandled_error_returns_500_and_leaks_nothing(error_client):
    response = error_client.get("/_boom/unhandled")
    assert response.status_code == 500
    body = response.json()
    assert body["error"]["type"] == "internal_error"
    assert "secret internal detail" not in body["error"]["message"]
    assert "/srv/genai" not in body["error"]["message"]
    assert "Traceback" not in body["error"]["message"]
    assert body["request_id"]


class _Payload(BaseModel):
    """Module-level on purpose: FastAPI resolves body models by name from
    the defining module, so a model declared inside a test function is
    mistaken for a query parameter."""

    tenant_id: str
    count: int


def test_validation_error_lists_the_failing_fields(make_settings):
    """FastAPI's own 422 is reshaped into our envelope."""
    app = create_app(make_settings())
    router = APIRouter()

    @router.post("/_echo")
    async def echo(payload: _Payload):
        return {"ok": True}

    app.include_router(router)
    with TestClient(app) as c:
        response = c.post("/_echo", json={"count": "not-an-int"})

    assert response.status_code == 422
    body = response.json()
    assert body["error"]["type"] == "validation_error"
    fields = {f["field"] for f in body["error"]["details"]["fields"]}
    assert "tenant_id" in fields and "count" in fields


def test_error_hierarchy_is_catchable():
    for exc in (ValidationError(), NotFoundError(), AuthenticationError()):
        assert isinstance(exc, GenAIServiceError)


# ---------------------------------------------------------------------
# Service token dependency
# ---------------------------------------------------------------------


@pytest.fixture
def guarded_client(make_settings):
    from fastapi import Depends

    from app.api.deps import verify_service_token

    app = create_app(make_settings(service_token="s3cret"))
    router = APIRouter(dependencies=[Depends(verify_service_token)])

    @router.get("/_guarded")
    async def guarded():
        return {"ok": True}

    app.include_router(router)
    with TestClient(app) as c:
        yield c


def test_guarded_route_rejects_a_missing_token(guarded_client):
    response = guarded_client.get("/_guarded")
    assert response.status_code == 401
    assert response.json()["error"]["type"] == "authentication_error"


def test_guarded_route_rejects_a_wrong_token(guarded_client):
    response = guarded_client.get("/_guarded", headers={"X-Service-Token": "nope"})
    assert response.status_code == 401


def test_guarded_route_accepts_the_right_token(guarded_client):
    response = guarded_client.get("/_guarded", headers={"X-Service-Token": "s3cret"})
    assert response.status_code == 200
    assert response.json() == {"ok": True}


def test_token_check_is_skipped_when_unconfigured(make_settings):
    from fastapi import Depends

    from app.api.deps import verify_service_token

    app = create_app(make_settings(service_token=""))
    router = APIRouter(dependencies=[Depends(verify_service_token)])

    @router.get("/_open")
    async def open_route():
        return {"ok": True}

    app.include_router(router)
    with TestClient(app) as c:
        assert c.get("/_open").status_code == 200


# ---------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------


def test_setup_logging_applies_the_level():
    setup_logging(level="DEBUG", force=True)
    assert logging.getLogger().level == logging.DEBUG
    setup_logging(level="WARNING", force=True)
    assert logging.getLogger().level == logging.WARNING


def test_json_formatter_emits_parsable_json():
    import json

    record = logging.LogRecord(
        name="test", level=logging.INFO, pathname=__file__, lineno=1,
        msg="hello %s", args=("world",), exc_info=None,
    )
    record.request_id = "req-9"
    payload = json.loads(JsonFormatter().format(record))
    assert payload["message"] == "hello world"
    assert payload["level"] == "INFO"
    assert payload["request_id"] == "req-9"


def test_request_id_reaches_the_logs(client, caplog):
    with caplog.at_level(logging.DEBUG, logger="app.main"):
        client.get("/health", headers={"X-Request-ID": "trace-me"})
    assert any(
        getattr(r, "request_id", None) == "trace-me" for r in caplog.records
    )


def test_each_request_gets_a_distinct_id(client):
    first = client.get("/health").headers["X-Request-ID"]
    second = client.get("/health").headers["X-Request-ID"]
    assert first != second


def test_app_factory_accepts_custom_settings(make_settings):
    app = create_app(make_settings(app_name="Custom Name"))
    assert app.title == "Custom Name"
