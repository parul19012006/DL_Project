"""Stage 8 — the batch worker and its job store.

The API suite proves a 500-document batch is accepted and completes.
This one proves the property that makes that safe: **the worker holds
one document at a time, whatever the batch size.** That is asserted by
instrumenting the indexing call rather than described in a comment.
"""

from __future__ import annotations

import pytest

from app.ingestion.errors import FileNotFoundError_ as DocumentNotFoundError
from app.services.indexing import IndexResult
from app.services.jobs import (
    MAX_WARNINGS_PER_ITEM,
    IngestJob,
    JobRegistry,
    JobStatus,
    run_batch,
)

TENANT = "tenant-a"


def _items(count: int, tenant_id: str = TENANT):
    return [
        {
            "document_id": f"doc-{i}",
            "tenant_id": tenant_id,
            "file_path": f"file-{i}.pdf",
        }
        for i in range(count)
    ]


def _job(total: int) -> IngestJob:
    return JobRegistry().create(total=total, request_id="req-1")


def _ok(**item) -> IndexResult:
    return IndexResult(
        document_id=item["document_id"],
        tenant_id=item["tenant_id"],
        filename=item.get("filename") or "f.pdf",
        chunks_indexed=3,
        pages=2,
        duration_ms=1,
    )


# =====================================================================
# The memory property
# =====================================================================


def test_the_worker_holds_one_document_at_a_time(settings):
    """The whole reason a 500-document batch is safe.

    A spy tracks how many documents are "open" — between the start and
    end of an indexing call — and asserts the peak never exceeds one.
    """
    open_now = 0
    peak = 0

    def spy(settings=None, **item):
        nonlocal open_now, peak
        open_now += 1
        peak = max(peak, open_now)
        try:
            # Stand in for the extracted pages, blocks, chunks and
            # vectors a real document holds while it is being indexed.
            _payload = ["x" * 1024] * 64
            return _ok(**item)
        finally:
            open_now -= 1

    job = _job(500)
    run_batch(job, _items(500), settings=settings, index_one=spy)

    assert peak == 1
    assert open_now == 0
    assert job.processed == 500
    assert job.succeeded == 500


def test_documents_are_processed_in_order(settings):
    seen = []

    def spy(settings=None, **item):
        seen.append(item["document_id"])
        return _ok(**item)

    job = _job(10)
    run_batch(job, _items(10), settings=settings, index_one=spy)
    assert seen == [f"doc-{i}" for i in range(10)]


def test_only_a_small_record_is_retained_per_document(settings):
    """Extracted text and chunks are never kept for reporting."""

    def spy(settings=None, **item):
        result = _ok(**item)
        result.warnings = [f"warning {n}" for n in range(20)]
        return result

    job = _job(50)
    run_batch(job, _items(50), settings=settings, index_one=spy)

    assert len(job.results) == 50
    for record in job.results:
        assert len(record.warnings) <= MAX_WARNINGS_PER_ITEM
        assert not hasattr(record, "text")
        assert not hasattr(record, "chunks")


def test_the_job_counters_add_up(settings):
    job = _job(500)
    run_batch(job, _items(500), settings=settings, index_one=lambda settings=None, **i: _ok(**i))

    assert job.succeeded + job.failed == job.processed == job.total
    assert job.chunks_indexed == 500 * 3
    assert job.progress == 1.0


# =====================================================================
# Failure isolation
# =====================================================================


def test_one_failing_document_does_not_stop_the_batch(settings):
    def spy(settings=None, **item):
        if item["document_id"] == "doc-2":
            raise DocumentNotFoundError("no such file")
        return _ok(**item)

    job = _job(5)
    run_batch(job, _items(5), settings=settings, index_one=spy)

    assert job.status == JobStatus.COMPLETED
    assert job.processed == 5
    assert job.succeeded == 4
    assert job.failed == 1


def test_a_failure_is_recorded_against_its_own_document(settings):
    def spy(settings=None, **item):
        if item["document_id"] == "doc-1":
            raise DocumentNotFoundError("no such file")
        return _ok(**item)

    job = _job(3)
    run_batch(job, _items(3), settings=settings, index_one=spy)

    failed = [r for r in job.results if r.status == "failed"]
    assert len(failed) == 1
    assert failed[0].document_id == "doc-1"
    assert failed[0].error_type == "document_not_found"


def test_an_unexpected_error_is_contained_too(settings):
    """A surprise on one document must not kill the batch."""

    def spy(settings=None, **item):
        if item["document_id"] == "doc-0":
            raise RuntimeError("something nobody predicted")
        return _ok(**item)

    job = _job(3)
    run_batch(job, _items(3), settings=settings, index_one=spy)

    assert job.status == JobStatus.COMPLETED
    assert job.succeeded == 2
    assert job.results[0].error_type == "internal_error"


def test_an_internal_error_does_not_leak_its_message(settings):
    """A traceback or a path must not travel to the caller."""

    def spy(settings=None, **item):
        raise RuntimeError("/srv/secret/path/blew/up")

    job = _job(1)
    run_batch(job, _items(1), settings=settings, index_one=spy)
    assert "/srv/secret" not in job.results[0].error


def test_an_empty_document_counts_as_failed_not_succeeded(settings):
    def spy(settings=None, **item):
        result = _ok(**item)
        result.status = "empty"
        result.chunks_indexed = 0
        return result

    job = _job(2)
    run_batch(job, _items(2), settings=settings, index_one=spy)

    assert job.succeeded == 0
    assert job.failed == 2


# =====================================================================
# Job lifecycle
# =====================================================================


def test_a_job_moves_through_its_states(settings):
    job = _job(1)
    assert job.status == JobStatus.QUEUED
    assert job.started_at is None

    run_batch(job, _items(1), settings=settings, index_one=lambda settings=None, **i: _ok(**i))

    assert job.status == JobStatus.COMPLETED
    assert job.finished
    assert job.started_at is not None
    assert job.finished_at is not None
    assert job.duration_ms >= 0


def test_an_empty_batch_completes_immediately(settings):
    job = _job(0)
    run_batch(job, [], settings=settings, index_one=lambda **_: None)
    assert job.status == JobStatus.COMPLETED
    assert job.progress == 1.0


def test_the_submitting_request_id_travels_with_the_job(settings):
    """A background job has to be traceable to the call that started it."""
    job = _job(1)
    assert job.request_id == "req-1"
    assert job.to_dict()["request_id"] == "req-1"


def test_the_job_serialises_for_the_api(settings):
    job = _job(2)
    run_batch(job, _items(2), settings=settings, index_one=lambda settings=None, **i: _ok(**i))

    data = job.to_dict()
    assert set(data) >= {
        "job_id", "status", "total", "processed", "succeeded", "failed",
        "chunks_indexed", "progress", "results", "created_at", "duration_ms",
    }
    assert len(data["results"]) == 2

    assert job.to_dict(include_results=False).get("results") is None


# =====================================================================
# The registry
# =====================================================================


def test_jobs_are_retrievable_by_id():
    registry = JobRegistry()
    job = registry.create(total=3)
    assert registry.get(job.job_id) is job
    assert registry.get("nope") is None


def test_job_ids_are_unique():
    registry = JobRegistry()
    ids = {registry.create(total=1).job_id for _ in range(50)}
    assert len(ids) == 50


def test_the_registry_is_bounded():
    """A long-running service must not accumulate job records forever."""
    registry = JobRegistry(history_limit=5)
    for _ in range(20):
        job = registry.create(total=1)
        job.status = JobStatus.COMPLETED
    assert len(registry.list(limit=100)) == 5


def test_running_jobs_are_never_evicted():
    """Losing the record of work still in progress would leave a caller
    polling an id that has ceased to exist."""
    registry = JobRegistry(history_limit=2)
    running = registry.create(total=1)
    running.status = JobStatus.RUNNING

    for _ in range(10):
        finished = registry.create(total=1)
        finished.status = JobStatus.COMPLETED

    assert registry.get(running.job_id) is running


def test_active_jobs_are_counted():
    registry = JobRegistry()
    assert registry.active_count() == 0

    first = registry.create(total=1)
    registry.create(total=1)
    assert registry.active_count() == 2

    first.status = JobStatus.COMPLETED
    assert registry.active_count() == 1


def test_the_most_recent_jobs_are_listed_first():
    registry = JobRegistry()
    jobs = [registry.create(total=1) for _ in range(3)]
    assert [j.job_id for j in registry.list()] == [j.job_id for j in reversed(jobs)]


@pytest.mark.parametrize("total,processed,expected", [(0, 0, 1.0), (4, 1, 0.25), (4, 4, 1.0)])
def test_progress_is_reported_as_a_fraction(total, processed, expected):
    job = JobRegistry().create(total=total)
    job.processed = processed
    assert job.progress == expected
