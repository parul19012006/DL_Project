"""Indexing and search end to end, plus the HTTP contract.

Real PDFs and DOCX files go through extract → chunk → embed → store →
search, which is the whole of Stage 4 working together.
"""

from __future__ import annotations

import pytest

from app.embeddings.deterministic import DeterministicEmbedding
from app.ingestion.errors import IngestionError
from app.services import indexing
from app.vectorstore.memory import InMemoryVectorStore


@pytest.fixture
def pipeline(embedder, memory_store, settings):
    """An isolated model + store pair for direct service calls."""
    return {"model": embedder, "store": memory_store, "settings": settings}


def index(path, pipeline, **kwargs):
    defaults = dict(
        document_id="doc-1", tenant_id="tenant-a", file_path=path.name
    )
    defaults.update(kwargs)
    return indexing.index_document(**defaults, **pipeline)


# =====================================================================
# End to end
# =====================================================================


def test_a_contract_is_indexed(multipage_pdf, pipeline):
    result = index(multipage_pdf, pipeline, document_type="contract")

    assert result.status == "success"
    assert result.chunks_indexed > 0
    assert result.pages >= 1
    assert result.embedding_dimension == pipeline["model"].dimension
    assert pipeline["store"].count() == result.chunks_indexed


def test_indexed_chunks_are_searchable(multipage_pdf, pipeline):
    index(multipage_pdf, pipeline, document_type="contract")

    outcome = indexing.search(
        "termination for convenience notice period",
        tenant_id="tenant-a",
        top_k=3,
        **pipeline,
    )
    assert outcome.hits
    assert all(h.chunk.tenant_id == "tenant-a" for h in outcome.hits)
    assert outcome.embedding_dimension == pipeline["model"].dimension


def test_hits_carry_everything_a_citation_needs(multipage_pdf, pipeline):
    index(multipage_pdf, pipeline, document_id="doc-77", document_type="contract")

    hit = indexing.search("termination", tenant_id="tenant-a", **pipeline).hits[0]
    citation = hit.chunk.citation()

    assert citation["document_id"] == "doc-77"
    assert citation["filename"] == multipage_pdf.name
    assert citation["page"]
    assert citation["chunk_id"]


def test_a_docx_indexes_and_searches(nda_docx, pipeline):
    index(nda_docx, pipeline, document_id="doc-nda", document_type="nda")

    outcome = indexing.search(
        "governing law Delaware", tenant_id="tenant-a", **pipeline
    )
    assert outcome.hits
    assert any("Delaware" in h.chunk.text for h in outcome.hits)


def test_timings_are_reported(multipage_pdf, pipeline):
    result = index(multipage_pdf, pipeline)
    timings = result.to_dict()["timings_ms"]

    for phase in ("extract", "chunk", "embed", "store"):
        assert phase in timings
        assert timings[phase] >= 0


def test_chunking_stats_are_reported(multipage_pdf, pipeline):
    result = index(multipage_pdf, pipeline)
    assert result.chunking is not None
    assert result.chunking.chunk_count == result.chunks_indexed


# =====================================================================
# Re-indexing
# =====================================================================


def test_reindexing_an_unchanged_document_is_idempotent(multipage_pdf, pipeline):
    """The property that matters: no duplicates, same index, either way."""
    first = index(multipage_pdf, pipeline)
    second = index(multipage_pdf, pipeline)

    assert second.chunks_indexed == first.chunks_indexed
    assert pipeline["store"].count() == first.chunks_indexed


def test_an_unchanged_document_is_not_re_processed(multipage_pdf, pipeline):
    """Re-extracting and re-embedding to produce byte-identical vectors
    under identical ids is work for nothing. On 500 documents it measured
    33 seconds of it."""
    first = index(multipage_pdf, pipeline)
    second = index(multipage_pdf, pipeline)

    assert first.status == "success"
    assert second.status == "unchanged"
    assert second.extract_ms == 0
    assert second.embed_ms == 0
    assert second.chunks_indexed == first.chunks_indexed
    assert any("unchanged" in w.lower() for w in second.warnings)


def test_the_unchanged_check_can_be_switched_off(multipage_pdf, pipeline, make_settings):
    """Needed after a CHUNK_SIZE change, when the same bytes must produce
    different chunks."""
    settings = make_settings(skip_unchanged_documents=False)
    first = index(multipage_pdf, {**pipeline, "settings": settings})
    second = index(multipage_pdf, {**pipeline, "settings": settings})

    assert second.status == "success"
    assert second.replaced is True
    assert second.chunks_deleted == first.chunks_indexed


def test_reindexing_removes_chunks_that_no_longer_exist(pipeline, doc_root):
    """An edited, shorter document must not leave orphans behind.

    Without delete-before-insert the deleted clause would stay indexed
    and keep being retrieved — the failure mode is a confident citation
    of text that is no longer in the contract.
    """
    from tests import fixtures

    path = doc_root / "evolving_agreement.pdf"
    fixtures.make_pdf(path, "AGREEMENT", fixtures.VENDOR_CONTRACT)
    long_result = index(path, pipeline, document_id="doc-evolving")

    fixtures.make_pdf(path, "AGREEMENT", fixtures.VENDOR_CONTRACT[:2])
    short_result = index(path, pipeline, document_id="doc-evolving")

    assert short_result.chunks_indexed < long_result.chunks_indexed
    assert pipeline["store"].count() == short_result.chunks_indexed

    text = " ".join(
        c.text
        for c in pipeline["store"].fetch(
            __import__(
                "app.vectorstore.base", fromlist=["SearchFilter"]
            ).SearchFilter(tenant_id="tenant-a")
        )
    )
    assert "arbitration" not in text.lower()


def test_replacement_can_be_disabled(multipage_pdf, pipeline, make_settings):
    cfg = make_settings(replace_on_reindex=False)
    local = {**pipeline, "settings": cfg}

    first = index(multipage_pdf, local)
    second = index(multipage_pdf, local)

    assert second.chunks_deleted == 0
    assert second.replaced is False
    # Stable ids still prevent duplication.
    assert pipeline["store"].count() == first.chunks_indexed


# =====================================================================
# Tenant isolation
# =====================================================================


def test_two_tenants_do_not_see_each_other(multipage_pdf, nda_docx, pipeline):
    index(multipage_pdf, pipeline, document_id="doc-a", tenant_id="tenant-alpha")
    index(nda_docx, pipeline, document_id="doc-b", tenant_id="tenant-beta")

    alpha = indexing.search(
        "Delaware governing law confidential", tenant_id="tenant-alpha", **pipeline
    )
    beta = indexing.search(
        "Delaware governing law confidential", tenant_id="tenant-beta", **pipeline
    )

    assert {h.chunk.document_id for h in alpha.hits} == {"doc-a"}
    assert {h.chunk.document_id for h in beta.hits} == {"doc-b"}


def test_search_requires_a_tenant(pipeline):
    from app.vectorstore.base import TenantScopeError

    with pytest.raises(TenantScopeError):
        indexing.search("anything", tenant_id="", **pipeline)


def test_deleting_a_document_is_tenant_scoped(multipage_pdf, pipeline):
    index(multipage_pdf, pipeline, document_id="doc-x", tenant_id="tenant-alpha")

    assert indexing.delete_document(
        "doc-x", "tenant-other", settings=pipeline["settings"],
        store=pipeline["store"],
    ) == 0
    assert pipeline["store"].count("tenant-alpha") > 0

    removed = indexing.delete_document(
        "doc-x", "tenant-alpha", settings=pipeline["settings"],
        store=pipeline["store"],
    )
    assert removed > 0
    assert pipeline["store"].count("tenant-alpha") == 0


def test_deleting_a_tenant_removes_everything(multipage_pdf, nda_docx, pipeline):
    index(multipage_pdf, pipeline, document_id="doc-a", tenant_id="tenant-alpha")
    index(nda_docx, pipeline, document_id="doc-b", tenant_id="tenant-beta")

    indexing.delete_tenant(
        "tenant-alpha", settings=pipeline["settings"], store=pipeline["store"]
    )
    assert pipeline["store"].count("tenant-alpha") == 0
    assert pipeline["store"].count("tenant-beta") > 0


# =====================================================================
# Failure handling
# =====================================================================


def test_a_corrupt_document_raises(corrupt_pdf, pipeline):
    with pytest.raises(IngestionError):
        index(corrupt_pdf, pipeline)


def test_nothing_is_indexed_when_extraction_fails(corrupt_pdf, pipeline):
    with pytest.raises(IngestionError):
        index(corrupt_pdf, pipeline)
    assert pipeline["store"].count() == 0


def test_a_batch_isolates_failures(multipage_pdf, corrupt_pdf, nda_docx, pipeline):
    results = indexing.index_many(
        [
            {"document_id": "ok-1", "tenant_id": "tenant-a",
             "file_path": multipage_pdf.name},
            {"document_id": "bad-1", "tenant_id": "tenant-a",
             "file_path": corrupt_pdf.name},
            {"document_id": "ok-2", "tenant_id": "tenant-a",
             "file_path": nda_docx.name},
        ],
        **pipeline,
    )

    assert [r.status for r in results] == ["success", "failed", "success"]
    assert results[1].chunks_indexed == 0
    assert any("corrupt_document" in w for w in results[1].warnings)
    assert pipeline["store"].count() > 0


def test_a_chunk_over_the_model_window_is_flagged(multipage_pdf, pipeline):
    """Silent truncation loses the tail of a clause; warn instead."""

    class Narrow(DeterministicEmbedding):
        @property
        def max_sequence_length(self) -> int:
            return 10

    local = {**pipeline, "model": Narrow(dimension=pipeline["model"].dimension)}
    result = index(multipage_pdf, local)

    assert result.truncation_warning
    assert any("truncated" in w for w in result.warnings)


# =====================================================================
# Search behaviour
# =====================================================================


def test_top_k_is_respected(multipage_pdf, pipeline):
    index(multipage_pdf, pipeline)
    for k in (1, 2, 5):
        assert len(
            indexing.search("clause", tenant_id="tenant-a", top_k=k, **pipeline).hits
        ) <= k


def test_a_score_floor_drops_weak_hits(multipage_pdf, pipeline):
    index(multipage_pdf, pipeline)

    unfiltered = indexing.search(
        "termination", tenant_id="tenant-a", top_k=10, min_score=0.0, **pipeline
    )
    filtered = indexing.search(
        "termination", tenant_id="tenant-a", top_k=10, min_score=0.99, **pipeline
    )

    assert len(filtered.hits) <= len(unfiltered.hits)
    assert all(h.score >= 0.99 for h in filtered.hits)
    assert [h.rank for h in filtered.hits] == list(range(1, len(filtered.hits) + 1))


def test_document_filter_restricts_search(multipage_pdf, nda_docx, pipeline):
    index(multipage_pdf, pipeline, document_id="doc-a")
    index(nda_docx, pipeline, document_id="doc-b")

    outcome = indexing.search(
        "agreement", tenant_id="tenant-a", document_ids=["doc-b"], **pipeline
    )
    assert outcome.hits
    assert {h.chunk.document_id for h in outcome.hits} == {"doc-b"}


def test_search_on_an_empty_index(pipeline):
    outcome = indexing.search("anything", tenant_id="tenant-a", **pipeline)
    assert outcome.hits == []


def test_search_reports_its_filters(multipage_pdf, pipeline):
    index(multipage_pdf, pipeline)
    outcome = indexing.search(
        "termination", tenant_id="tenant-a", document_type="contract", **pipeline
    )
    assert outcome.filters["tenant_id"] == "tenant-a"
    assert outcome.filters["document_type"] == "contract"


# =====================================================================
# HTTP contract
# =====================================================================


def _payload(path, **kwargs) -> dict:
    body = {
        "document_id": "doc-http-1",
        "tenant_id": "tenant-alpha",
        "file_path": path.name,
    }
    body.update(kwargs)
    return body


@pytest.fixture
def clean_index(client):
    """Empty the app's own store before and after each HTTP test."""
    from app.vectorstore.factory import get_vector_store

    get_vector_store().reset()
    yield
    get_vector_store().reset()


def test_index_endpoint(client, clean_index, multipage_pdf):
    response = client.post(
        "/index", json=_payload(multipage_pdf, document_type="contract")
    )
    assert response.status_code == 200

    body = response.json()
    assert body["status"] == "success"
    assert body["chunks_indexed"] > 0
    assert body["embedding_dimension"] > 0
    assert body["document_id"] == "doc-http-1"


def test_search_endpoint(client, clean_index, multipage_pdf):
    client.post("/index", json=_payload(multipage_pdf, document_type="contract"))

    response = client.post(
        "/search",
        json={
            "query": "how much notice to terminate for convenience",
            "tenant_id": "tenant-alpha",
            "top_k": 3,
        },
    )
    assert response.status_code == 200

    body = response.json()
    assert body["hits"]
    assert len(body["hits"]) <= 3
    first = body["hits"][0]
    for field in (
        "rank", "score", "chunk_id", "document_id", "filename",
        "page_number", "section", "text",
    ):
        assert field in first
    assert body["embedding_dimension"] > 0


def test_search_is_tenant_scoped_over_http(client, clean_index, multipage_pdf):
    client.post(
        "/index", json=_payload(multipage_pdf, document_id="d1",
                                tenant_id="tenant-one")
    )
    client.post(
        "/index", json=_payload(multipage_pdf, document_id="d2",
                                tenant_id="tenant-two")
    )

    one = client.post(
        "/search", json={"query": "termination", "tenant_id": "tenant-one"}
    ).json()
    assert {h["document_id"] for h in one["hits"]} == {"d1"}


def test_search_requires_a_tenant_over_http(client):
    assert client.post("/search", json={"query": "x"}).status_code == 422


def test_search_rejects_an_empty_query(client):
    response = client.post("/search", json={"query": "", "tenant_id": "t"})
    assert response.status_code == 422


def test_search_can_omit_text(client, clean_index, multipage_pdf):
    client.post("/index", json=_payload(multipage_pdf))
    body = client.post(
        "/search",
        json={
            "query": "termination",
            "tenant_id": "tenant-alpha",
            "include_text": False,
        },
    ).json()
    assert body["hits"]
    assert all(h["text"] == "" for h in body["hits"])


def test_search_applies_metadata_filters_over_http(
    client, clean_index, multipage_pdf, nda_docx
):
    client.post(
        "/index",
        json=_payload(multipage_pdf, document_id="d1", document_type="contract"),
    )
    client.post(
        "/index", json=_payload(nda_docx, document_id="d2", document_type="nda")
    )

    body = client.post(
        "/search",
        json={
            "query": "agreement",
            "tenant_id": "tenant-alpha",
            "document_type": "nda",
        },
    ).json()
    assert body["hits"]
    assert {h["document_id"] for h in body["hits"]} == {"d2"}


def test_batch_index_endpoint(client, clean_index, multipage_pdf, corrupt_pdf):
    response = client.post(
        "/index/batch",
        json={
            "documents": [
                _payload(multipage_pdf, document_id="b1"),
                _payload(corrupt_pdf, document_id="b2"),
            ]
        },
    )
    assert response.status_code == 200

    body = response.json()
    assert body["total"] == 2
    assert body["succeeded"] == 1
    assert body["failed"] == 1
    assert body["chunks_indexed"] > 0


def test_upload_index_endpoint(client, clean_index, multipage_pdf):
    with multipage_pdf.open("rb") as handle:
        response = client.post(
            "/index/upload",
            files={"file": (multipage_pdf.name, handle, "application/pdf")},
            data={"document_id": "up-1", "tenant_id": "tenant-up"},
        )
    assert response.status_code == 200
    assert response.json()["chunks_indexed"] > 0


def test_delete_document_endpoint(client, clean_index, multipage_pdf):
    client.post("/index", json=_payload(multipage_pdf, document_id="del-1"))

    wrong = client.delete(
        "/documents/del-1/index", params={"tenant_id": "tenant-other"}
    ).json()
    assert wrong["chunks_deleted"] == 0

    right = client.delete(
        "/documents/del-1/index", params={"tenant_id": "tenant-alpha"}
    ).json()
    assert right["deleted"] is True
    assert right["chunks_deleted"] > 0

    after = client.post(
        "/search", json={"query": "termination", "tenant_id": "tenant-alpha"}
    ).json()
    assert after["hits"] == []


def test_delete_tenant_endpoint(client, clean_index, multipage_pdf):
    client.post(
        "/index", json=_payload(multipage_pdf, tenant_id="tenant-purge")
    )
    body = client.delete("/tenants/tenant-purge/index").json()

    assert body["deleted"] is True
    assert body["chunks_deleted"] > 0


def test_index_stats_endpoint(client, clean_index, multipage_pdf):
    client.post("/index", json=_payload(multipage_pdf))
    body = client.get("/index/stats", params={"tenant_id": "tenant-alpha"}).json()

    assert body["backend"] in {"chroma", "memory"}
    assert body["dimension"] > 0
    assert body["embedding_dimension"] == body["dimension"]
    assert body["total_chunks"] > 0
    assert body["tenant_chunks"] > 0


def test_index_endpoint_propagates_extraction_errors(client, corrupt_pdf):
    response = client.post("/index", json=_payload(corrupt_pdf))
    assert response.status_code == 422
    assert response.json()["error"]["type"] == "corrupt_document"


def test_index_endpoint_rejects_path_traversal(client):
    response = client.post(
        "/index",
        json={"document_id": "d", "tenant_id": "t", "file_path": "../../etc/passwd"},
    )
    assert response.status_code == 400


def test_index_endpoints_require_the_service_token(
    client_factory, make_settings, multipage_pdf
):
    with client_factory(make_settings(service_token="s3cret")) as c:
        assert c.post("/index", json=_payload(multipage_pdf)).status_code == 401
        assert c.post(
            "/search", json={"query": "x", "tenant_id": "t"}
        ).status_code == 401


def test_health_reports_the_stage_4_components(client):
    components = {c["name"]: c for c in client.get("/health").json()["components"]}

    assert "embedding_model" in components
    assert "vector_store" in components
    assert "dimension=" in components["embedding_model"]["detail"]
    assert "dimension=" in components["vector_store"]["detail"]


def test_health_flags_a_fallback_embedding_model(client_factory, make_settings):
    """Running on the hashing encoder must never be invisible."""
    cfg = make_settings(
        embedding_provider="sentence_transformers", embedding_strict=False
    )
    import sys
    import types

    module = types.ModuleType("sentence_transformers")
    module.SentenceTransformer = lambda *a, **k: (_ for _ in ()).throw(
        OSError("blocked")
    )
    original = sys.modules.get("sentence_transformers")
    sys.modules["sentence_transformers"] = module
    try:
        with client_factory(cfg) as c:
            body = c.get("/health").json()
    finally:
        if original is not None:
            sys.modules["sentence_transformers"] = original
        else:
            sys.modules.pop("sentence_transformers", None)

    components = {comp["name"]: comp for comp in body["components"]}
    assert components["embedding_model"]["status"] == "degraded"
    assert "deterministic" in components["embedding_model"]["detail"]
    assert body["status"] == "degraded"


def test_openapi_documents_the_stage_4_endpoints(client):
    paths = client.get("/openapi.json").json()["paths"]
    for path in ("/index", "/index/batch", "/index/upload", "/search",
                 "/index/stats"):
        assert path in paths
    assert "/documents/{document_id}/index" in paths
