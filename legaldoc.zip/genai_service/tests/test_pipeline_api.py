"""Stage 8 — the integration API the MERN backend consumes.

    POST   /ingest
    POST   /ingest/batch          + GET /ingest/batch/{job_id}
    POST   /query
    DELETE /documents/{document_id}
    GET    /health

These run over the real application. What Express depends on is the
JSON, the status codes and the error envelope, so that is what is
asserted — not the internals, which have their own suites.
"""

from __future__ import annotations

import pytest

from app.generation.base import LLMUnavailableError
from app.generation.factory import set_llm_provider
from tests import fixtures
from tests.fixtures import StubProvider, answer_json

TENANT_A = "tenant-a"
TENANT_B = "tenant-b"
QUESTION = "How much notice is required to terminate for convenience?"

CONTRACT_TEXT = """4. TERMINATION

Either party may terminate this Agreement for convenience on one hundred and
twenty (120) days written notice to the other party.

5. LIMITATION OF LIABILITY

The aggregate liability of either party shall not exceed the total fees paid
in the twelve (12) months preceding the claim."""


@pytest.fixture
def api(client):
    """The application with a scripted model behind it."""
    set_llm_provider(StubProvider(answer_json("Notice is 120 days.", [1])))
    return client


def _ingest_text(client, document_id="doc-text", tenant_id=TENANT_A, **extra):
    payload = {
        "document_id": document_id,
        "tenant_id": tenant_id,
        "text": CONTRACT_TEXT,
    }
    payload.update(extra)
    return client.post("/ingest", json=payload)


# =====================================================================
# POST /ingest
# =====================================================================


def test_ingesting_a_file_returns_processing_status(api, contract_pdf):
    response = api.post(
        "/ingest",
        json={
            "document_id": "doc-pdf-1",
            "tenant_id": TENANT_A,
            "file_path": contract_pdf.name,
            "document_type": "contract",
        },
    )
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "success"
    assert body["chunks_indexed"] > 0
    assert body["pages"] >= 1
    assert body["document_id"] == "doc-pdf-1"
    assert body["embedding_dimension"] > 0
    assert body["request_id"]


def test_ingesting_supplied_text_works_without_a_shared_volume(api):
    """The Node backend often already has the text; a round trip through
    a shared disk buys nothing."""
    response = _ingest_text(api)
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "success"
    assert body["chunks_indexed"] > 0
    assert body["filename"] == "doc-text.txt"


def test_text_ingestion_reports_that_it_has_no_pages(api):
    body = _ingest_text(api).json()
    assert any("no pagination" in w for w in body["warnings"])


def test_the_inferred_document_type_is_reported(api):
    """The caller cannot filter by a value it was never told about."""
    body = _ingest_text(api).json()
    assert body["document_type"] == "contract"


def test_a_declared_document_type_is_kept(api):
    body = _ingest_text(api, document_type="nda").json()
    assert body["document_type"] == "nda"


def test_re_ingesting_replaces_rather_than_duplicating(api):
    """The intent, not the mechanism.

    This used to assert ``chunks_replaced == chunks_indexed``, which was
    the *implementation* of non-duplication rather than the guarantee.
    Stage 9 added an unchanged-content short-circuit, so identical input
    is now skipped rather than replaced — behaviour that is strictly
    better and broke the assertion anyway. What actually matters is that
    the document ends up indexed exactly once.
    """
    first = _ingest_text(api).json()
    second = _ingest_text(api).json()

    assert second["chunks_indexed"] == first["chunks_indexed"]
    assert second["status"] in ("success", "unchanged")


def test_re_ingesting_identical_text_is_skipped(api):
    """The inline-text path gets the Stage 9 skip too, not just files."""
    _ingest_text(api)
    second = _ingest_text(api).json()

    assert second["status"] == "unchanged"
    assert any("unchanged" in w.lower() for w in second["warnings"])


def test_changed_text_under_the_same_id_is_re_indexed(api):
    """The skip must never swallow a real edit."""
    first = _ingest_text(api).json()
    second = _ingest_text(api, text=CONTRACT_TEXT + "\n\n9. NOTICES\nAll "
                          "notices shall be sent to the registered office.\n").json()

    assert second["status"] == "success"
    assert second["chunks_replaced"] == first["chunks_indexed"]


def test_custom_metadata_is_filterable_at_query_time(api):
    _ingest_text(api, metadata={"matter": "acme-2024"})
    body = api.post(
        "/query",
        json={
            "query": QUESTION,
            "tenant_id": TENANT_A,
            "metadata": {"matter": "acme-2024"},
            "include_sources": True,
        },
    ).json()
    assert body["sources"]


# -- ingest validation and errors -------------------------------------


def test_supplying_neither_a_path_nor_text_is_rejected(api):
    response = api.post(
        "/ingest", json={"document_id": "d", "tenant_id": TENANT_A}
    )
    assert response.status_code == 422
    assert "exactly one" in str(response.json()["error"]["details"]).lower()


def test_supplying_both_a_path_and_text_is_rejected(api, contract_pdf):
    response = api.post(
        "/ingest",
        json={
            "document_id": "d",
            "tenant_id": TENANT_A,
            "file_path": contract_pdf.name,
            "text": CONTRACT_TEXT,
        },
    )
    assert response.status_code == 422


def test_a_missing_tenant_is_rejected(api):
    response = api.post("/ingest", json={"document_id": "d", "text": "hello"})
    assert response.status_code == 422
    assert response.json()["error"]["type"] == "validation_error"


def test_oversized_inline_text_is_rejected_with_413(api, make_settings, client_factory):
    settings = make_settings(ingest_max_text_chars=100)
    with client_factory(settings) as scoped:
        response = scoped.post(
            "/ingest",
            json={
                "document_id": "big",
                "tenant_id": TENANT_A,
                "text": "x " * 200,
            },
        )
    assert response.status_code == 400  # ValidationError -> 400
    assert "shared volume" in response.json()["error"]["message"]


@pytest.mark.parametrize(
    "fixture_name,expected_status,expected_type",
    [
        ("unsupported_file", 415, "unsupported_file_type"),
        ("corrupt_pdf", 422, "corrupt_document"),
        ("blank_pdf", 422, "empty_document"),
    ],
)
def test_extraction_failures_map_to_http_status_codes(
    api, request, fixture_name, expected_status, expected_type
):
    path = request.getfixturevalue(fixture_name)
    response = api.post(
        "/ingest",
        json={"document_id": "d", "tenant_id": TENANT_A, "file_path": path.name},
    )
    assert response.status_code == expected_status
    assert response.json()["error"]["type"] == expected_type


def test_a_path_outside_the_document_root_is_rejected(api):
    response = api.post(
        "/ingest",
        json={
            "document_id": "d",
            "tenant_id": TENANT_A,
            "file_path": "../../etc/passwd",
        },
    )
    assert response.status_code == 400
    assert response.json()["error"]["type"] == "unsafe_path"


def test_a_missing_file_is_a_404(api):
    response = api.post(
        "/ingest",
        json={"document_id": "d", "tenant_id": TENANT_A, "file_path": "nope.pdf"},
    )
    assert response.status_code == 404
    assert response.json()["error"]["type"] == "document_not_found"


# =====================================================================
# POST /ingest/batch
# =====================================================================


def _batch(count: int, tenant_id: str = TENANT_A, path: str = "missing.pdf"):
    return {
        "documents": [
            {
                "document_id": f"doc-{i}",
                "tenant_id": tenant_id,
                "file_path": path,
            }
            for i in range(count)
        ]
    }


def test_a_batch_is_accepted_with_202_and_a_job_id(api, contract_pdf):
    response = api.post(
        "/ingest/batch",
        json={
            "documents": [
                {
                    "document_id": "batch-1",
                    "tenant_id": TENANT_A,
                    "file_path": contract_pdf.name,
                },
                {
                    "document_id": "batch-2",
                    "tenant_id": TENANT_A,
                    "file_path": contract_pdf.name,
                },
            ]
        },
    )
    assert response.status_code == 202
    body = response.json()
    assert body["job_id"]
    assert body["total"] == 2
    assert body["poll_url"] == f"/ingest/batch/{body['job_id']}"
    assert body["request_id"]


def test_the_job_reports_per_document_results(api, contract_pdf):
    accepted = api.post(
        "/ingest/batch",
        json={
            "documents": [
                {
                    "document_id": "batch-ok",
                    "tenant_id": TENANT_A,
                    "file_path": contract_pdf.name,
                },
                {
                    "document_id": "batch-missing",
                    "tenant_id": TENANT_A,
                    "file_path": "nope.pdf",
                },
            ]
        },
    ).json()

    body = api.get(accepted["poll_url"]).json()
    assert body["status"] == "completed"
    assert body["total"] == 2
    assert body["processed"] == 2
    assert body["succeeded"] == 1
    assert body["failed"] == 1
    assert body["progress"] == 1.0

    by_id = {r["document_id"]: r for r in body["results"]}
    assert by_id["batch-ok"]["chunks_indexed"] > 0
    assert by_id["batch-missing"]["status"] == "failed"
    assert by_id["batch-missing"]["error_type"] == "document_not_found"


def test_one_bad_document_never_stops_the_batch(api, contract_pdf):
    """A damaged file at position 2 must not cost the documents behind it."""
    accepted = api.post(
        "/ingest/batch",
        json={
            "documents": [
                {"document_id": "a", "tenant_id": TENANT_A, "file_path": contract_pdf.name},
                {"document_id": "b", "tenant_id": TENANT_A, "file_path": "nope.pdf"},
                {"document_id": "c", "tenant_id": TENANT_A, "file_path": contract_pdf.name},
            ]
        },
    ).json()

    body = api.get(accepted["poll_url"]).json()
    assert body["processed"] == 3
    assert body["succeeded"] == 2


def test_counters_can_be_polled_without_the_results(api, contract_pdf):
    """Lighter for a UI polling every second."""
    accepted = api.post(
        "/ingest/batch",
        json={
            "documents": [
                {"document_id": "x", "tenant_id": TENANT_A, "file_path": contract_pdf.name}
            ]
        },
    ).json()

    body = api.get(accepted["poll_url"], params={"include_results": False}).json()
    assert body["results"] == []
    assert body["processed"] == 1


def test_a_batch_of_five_hundred_documents_is_accepted(api):
    """The required scale, end to end over HTTP."""
    response = api.post("/ingest/batch", json=_batch(500))
    assert response.status_code == 202

    body = api.get(response.json()["poll_url"]).json()
    assert body["total"] == 500
    assert body["processed"] == 500
    assert body["status"] == "completed"


def test_a_batch_carries_references_never_contents(api):
    """The memory guarantee is structural: there is no field in which
    500 documents could arrive."""
    from app.models.schemas import BatchIngestItem

    assert "text" not in BatchIngestItem.model_fields
    assert "content" not in BatchIngestItem.model_fields
    assert "file_path" in BatchIngestItem.model_fields


def test_a_batch_over_the_limit_is_rejected_with_413(api, make_settings, client_factory):
    settings = make_settings(ingest_batch_max_documents=10)
    with client_factory(settings) as scoped:
        response = scoped.post("/ingest/batch", json=_batch(11))
    assert response.status_code == 413
    assert response.json()["error"]["type"] == "payload_too_large"
    assert response.json()["error"]["details"]["limit"] == 10


def test_an_empty_batch_is_rejected(api):
    response = api.post("/ingest/batch", json={"documents": []})
    assert response.status_code == 422


def test_a_batch_repeating_a_document_is_rejected(api):
    """The copies would race each other to replace the same document."""
    response = api.post(
        "/ingest/batch",
        json={
            "documents": [
                {"document_id": "same", "tenant_id": TENANT_A, "file_path": "a.pdf"},
                {"document_id": "same", "tenant_id": TENANT_A, "file_path": "b.pdf"},
            ]
        },
    )
    assert response.status_code == 400
    assert "same" in str(response.json()["error"]["details"])


def test_the_same_id_under_two_tenants_is_not_a_duplicate(api):
    response = api.post(
        "/ingest/batch",
        json={
            "documents": [
                {"document_id": "same", "tenant_id": TENANT_A, "file_path": "a.pdf"},
                {"document_id": "same", "tenant_id": TENANT_B, "file_path": "b.pdf"},
            ]
        },
    )
    assert response.status_code == 202


def test_an_unknown_job_id_is_a_404(api):
    response = api.get("/ingest/batch/" + "0" * 32)
    assert response.status_code == 404
    assert response.json()["error"]["type"] == "not_found"


# =====================================================================
# POST /query
# =====================================================================


@pytest.fixture
def loaded(api):
    """A tenant with documents, and a second tenant holding the same text."""
    from app.services.indexing import index_chunks

    for tenant, document_id, filename in (
        (TENANT_A, "doc-contract", "vendor_contract_2024.pdf"),
        (TENANT_B, "doc-rival", "rival_contract.pdf"),
    ):
        index_chunks(
            fixtures.make_chunks(
                fixtures.VENDOR_CONTRACT,
                document_id=document_id,
                tenant_id=tenant,
                filename=filename,
            )
        )
    index_chunks(
        fixtures.make_chunks(
            fixtures.MUTUAL_NDA,
            document_id="doc-nda",
            tenant_id=TENANT_A,
            filename="mutual_nda.docx",
            document_type="nda",
        )
    )
    return api


def _query(client, **body):
    payload = {"query": QUESTION, "tenant_id": TENANT_A}
    payload.update(body)
    return client.post("/query", json=payload)


def test_a_query_returns_an_answer_and_citations(loaded):
    response = _query(loaded)
    assert response.status_code == 200
    body = response.json()

    assert body["status"] == "ok"
    assert body["answer"]
    assert body["citations"]
    for citation in body["citations"]:
        assert set(citation) >= {"document", "page", "section", "chunk_id"}
    assert body["request_id"]


def test_sources_are_omitted_by_default(loaded):
    assert _query(loaded).json()["sources"] == []


def test_sources_can_be_returned_for_debugging(loaded):
    body = _query(loaded, include_sources=True).json()
    assert body["sources"]
    for source in body["sources"]:
        assert source["chunk_id"]
        assert source["document_id"]
        assert source["text"]
        assert "score" in source


def test_citations_resolve_to_the_returned_sources(loaded):
    body = _query(loaded, include_sources=True).json()
    numbers = {s["source"] for s in body["sources"]}
    assert {c["source"] for c in body["citations"]} <= numbers


def test_top_k_limits_the_evidence(loaded):
    body = _query(loaded, top_k=2, include_sources=True).json()
    assert len(body["sources"]) <= 2


def test_a_document_id_filter_narrows_the_search(loaded):
    body = _query(loaded, document_ids=["doc-nda"], include_sources=True).json()
    assert body["sources"]
    assert all(s["document_id"] == "doc-nda" for s in body["sources"])


def test_a_document_type_filter_narrows_the_search(loaded):
    body = _query(loaded, document_type="nda", include_sources=True).json()
    assert all(s["document_id"] == "doc-nda" for s in body["sources"])


def test_a_filter_matching_nothing_reports_insufficient_evidence(loaded):
    body = _query(loaded, document_ids=["does-not-exist"]).json()
    assert body["status"] == "insufficient_evidence"
    assert body["citations"] == []


def test_tenant_isolation_holds(loaded):
    body = _query(loaded, tenant_id=TENANT_B, include_sources=True).json()
    assert body["sources"]
    assert all(s["document_id"] == "doc-rival" for s in body["sources"])


def test_a_tenant_with_no_documents_gets_a_plain_refusal(loaded):
    body = _query(loaded, tenant_id="tenant-nobody").json()
    assert body["status"] == "insufficient_evidence"
    assert body["answer"]
    assert body["citations"] == []


def test_an_invented_citation_is_dropped(loaded):
    set_llm_provider(StubProvider(answer_json("An answer.", [1, 99])))
    body = _query(loaded).json()

    assert 99 not in [c["source"] for c in body["citations"]]
    assert body["validation"]["rejected"]


def test_a_model_failure_returns_200_with_the_evidence(loaded):
    set_llm_provider(StubProvider(raises=LLMUnavailableError("down")))
    response = _query(loaded, include_sources=True)

    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "llm_unavailable"
    assert body["answer"] is None
    assert body["sources"]


def test_the_prompt_block_can_be_returned_for_debugging(loaded):
    body = _query(loaded, include_context=True).json()
    assert body["context"].startswith("Source 1:")


# -- query validation -------------------------------------------------


def test_a_query_without_a_tenant_is_rejected(api):
    response = api.post("/query", json={"query": QUESTION})
    assert response.status_code == 422


def test_an_empty_query_is_rejected(api):
    response = api.post("/query", json={"query": "", "tenant_id": TENANT_A})
    assert response.status_code == 422


def test_an_out_of_range_top_k_is_rejected(api):
    response = api.post(
        "/query", json={"query": QUESTION, "tenant_id": TENANT_A, "top_k": 0}
    )
    assert response.status_code == 422


def test_a_malformed_page_range_is_rejected(api):
    response = api.post(
        "/query",
        json={"query": QUESTION, "tenant_id": TENANT_A, "page_range": [1]},
    )
    assert response.status_code == 422


# =====================================================================
# DELETE /documents/{document_id}
# =====================================================================


def test_deleting_a_document_removes_its_vector_data(loaded):
    response = loaded.delete(
        "/documents/doc-nda", params={"tenant_id": TENANT_A}
    )
    assert response.status_code == 200
    body = response.json()
    assert body["deleted"] is True
    assert body["chunks_deleted"] > 0
    assert body["request_id"]


def test_a_deleted_document_is_no_longer_retrievable(loaded):
    loaded.delete("/documents/doc-nda", params={"tenant_id": TENANT_A})
    body = _query(loaded, document_ids=["doc-nda"]).json()
    assert body["status"] == "insufficient_evidence"


def test_deleting_one_document_leaves_the_others(loaded):
    loaded.delete("/documents/doc-nda", params={"tenant_id": TENANT_A})
    body = _query(loaded, include_sources=True).json()
    assert body["sources"]
    assert all(s["document_id"] == "doc-contract" for s in body["sources"])


def test_deleting_an_unknown_document_is_not_an_error(loaded):
    """Delete is idempotent, and a document that produced no chunks is a
    legitimate case — turning either into a 404 would make Express treat
    a correct outcome as a failure."""
    response = loaded.delete(
        "/documents/never-existed", params={"tenant_id": TENANT_A}
    )
    assert response.status_code == 200
    assert response.json()["deleted"] is False
    assert response.json()["chunks_deleted"] == 0


def test_deleting_another_tenants_document_removes_nothing(loaded):
    """The isolation test that matters most for a delete."""
    response = loaded.delete(
        "/documents/doc-rival", params={"tenant_id": TENANT_A}
    )
    assert response.json()["chunks_deleted"] == 0

    still_there = _query(loaded, tenant_id=TENANT_B, include_sources=True).json()
    assert still_there["sources"]


def test_deleting_without_a_tenant_is_rejected(loaded):
    response = loaded.delete("/documents/doc-nda")
    assert response.status_code == 422


def test_the_deleted_count_is_also_a_response_header(loaded):
    response = loaded.delete("/documents/doc-nda", params={"tenant_id": TENANT_A})
    assert int(response.headers["X-Chunks-Deleted"]) > 0


# =====================================================================
# GET /health
# =====================================================================


def test_health_reports_every_component(api):
    response = api.get("/health")
    assert response.status_code in (200, 503)
    body = response.json()

    names = {c["name"] for c in body["components"]}
    assert names >= {
        "configuration",
        "ingestion",
        "chunking",
        "embedding_model",
        "vector_store",
        "retrieval",
        "reranker",
        "context",
        "llm",
    }
    assert body["status"] in {"ok", "degraded", "unavailable"}


def test_the_liveness_and_readiness_probes_answer(api):
    assert api.get("/health/live").json()["status"] == "alive"
    assert "ready" in api.get("/health/ready").json()


# =====================================================================
# Cross-cutting: request ids, errors, secrets
# =====================================================================


def test_a_request_id_is_returned_in_the_header_and_the_body(api):
    response = _ingest_text(api)
    assert response.headers["X-Request-ID"]
    assert response.json()["request_id"] == response.headers["X-Request-ID"]


def test_a_caller_supplied_request_id_is_honoured(api):
    """One id ties an Express log line to this service's log lines."""
    response = _ingest_text(api, **{})
    assert response.status_code == 200

    tagged = api.post(
        "/ingest",
        json={"document_id": "traced", "tenant_id": TENANT_A, "text": CONTRACT_TEXT},
        headers={"X-Request-ID": "express-abc-123"},
    )
    assert tagged.headers["X-Request-ID"] == "express-abc-123"
    assert tagged.json()["request_id"] == "express-abc-123"


def test_errors_carry_a_request_id_too(api):
    response = api.post("/ingest", json={"document_id": "d", "tenant_id": TENANT_A})
    assert response.status_code == 422
    assert response.json()["request_id"]


def test_every_error_uses_the_same_envelope(api):
    """Express parses one shape and branches on error.type."""
    for call in (
        lambda: api.post("/ingest", json={"document_id": "d", "tenant_id": TENANT_A}),
        lambda: api.post("/query", json={"query": QUESTION}),
        lambda: api.get("/ingest/batch/" + "0" * 32),
        lambda: api.post(
            "/ingest",
            json={"document_id": "d", "tenant_id": TENANT_A, "file_path": "nope.pdf"},
        ),
    ):
        body = call().json()
        assert set(body) == {"error", "request_id"}
        assert set(body["error"]) == {"type", "message", "details"}
        assert isinstance(body["error"]["type"], str)


def test_no_response_leaks_a_credential(loaded, make_settings, client_factory):
    """A key must never reach the backend, let alone a browser."""
    from pydantic import SecretStr

    settings = make_settings(
        openai_api_key=SecretStr("sk-must-never-appear"),
        anthropic_api_key=SecretStr("sk-ant-must-never-appear"),
    )
    with client_factory(settings) as scoped:
        from app.services.indexing import index_chunks

        index_chunks(
            fixtures.make_chunks(fixtures.VENDOR_CONTRACT, tenant_id=TENANT_A)
        )
        set_llm_provider(StubProvider(answer_json("An answer.", [1])))

        bodies = [
            scoped.post(
                "/ingest",
                json={"document_id": "k", "tenant_id": TENANT_A, "text": CONTRACT_TEXT},
            ).text,
            scoped.post(
                "/query",
                json={"query": QUESTION, "tenant_id": TENANT_A, "include_sources": True},
            ).text,
            scoped.get("/health").text,
            scoped.get("/answer/config").text,
            scoped.get("/openapi.json").text,
        ]

    for body in bodies:
        assert "sk-must-never-appear" not in body
        assert "sk-ant-must-never-appear" not in body


def test_the_five_required_endpoints_are_documented(api):
    paths = api.get("/openapi.json").json()["paths"]
    assert "post" in paths["/ingest"]
    assert "post" in paths["/ingest/batch"]
    assert "post" in paths["/query"]
    assert "delete" in paths["/documents/{document_id}"]
    assert "get" in paths["/health"]


def test_the_service_root_reports_the_integrated_stage(api):
    """Stage 8's durable claim is the five endpoints, not the number.

    Three earlier tests asserted the stage *number* and broke the moment
    the next stage landed, each time reporting a failure where nothing was
    wrong. The number belongs to whichever stage is current — asserted in
    that stage's own file — so this asserts what Stage 8 actually
    established and will still be true at Stage 20.
    """
    stage = api.get("/").json()["stage"]
    for endpoint in ("/ingest", "/ingest/batch", "/query", "/health"):
        assert endpoint in stage
