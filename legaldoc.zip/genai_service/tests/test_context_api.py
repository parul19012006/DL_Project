"""Stage 6 — the HTTP contract for context construction.

`POST /context` is what a grounded-answer feature calls. These tests run
over the real application, because the thing the MERN backend depends on
is the JSON, not the builder object.
"""

from __future__ import annotations

import pytest

from tests import fixtures

TENANT_A = "tenant-a"
TENANT_B = "tenant-b"
QUERY = "How much notice is required to terminate for convenience?"


@pytest.fixture
def indexed(client, corpus_chunks):
    from app.services.indexing import index_chunks

    for chunks in corpus_chunks.values():
        index_chunks(chunks)
    return client


def _context(client, **body):
    payload = {"query": QUERY, "tenant_id": TENANT_A}
    payload.update(body)
    return client.post("/context", json=payload)


# ---------------------------------------------------------------------
# The happy path
# ---------------------------------------------------------------------


def test_context_is_built_from_a_query(indexed):
    response = _context(indexed)
    assert response.status_code == 200
    body = response.json()
    assert body["context"].startswith("Source 1:")
    assert body["sources"]
    assert body["sufficient"] is True


def test_the_block_carries_every_required_label(indexed):
    block = _context(indexed).json()["context"]
    for label in ("Source 1:", "Document:", "Page:", "Section:", "Chunk:", "Text:"):
        assert label in block


def test_citations_are_returned_ready_to_render(indexed):
    """The backend never has to parse the prompt block to list sources."""
    body = _context(indexed).json()
    assert len(body["citations"]) == len(body["sources"])
    for citation in body["citations"]:
        assert citation["document_id"]
        assert citation["chunk_id"]
        assert citation["source"] >= 1


def test_source_numbers_match_the_block(indexed):
    body = _context(indexed).json()
    for source in body["sources"]:
        assert f"Source {source['source']}:" in body["context"]


def test_no_answer_is_generated(indexed):
    """Stage 6 returns evidence. Generation is the next stage."""
    body = _context(indexed).json()
    assert "answer" not in body
    assert QUERY.lower() not in body["context"].lower()


def test_stats_explain_where_the_budget_went(indexed):
    stats = _context(indexed).json()["stats"]
    assert stats["sources_out"] >= 1
    assert stats["tokens_used"] <= stats["tokens_budget"]
    assert stats["overhead_tokens"] >= 0
    assert stats["tokens_remaining"] == stats["tokens_budget"] - stats["tokens_used"]


def test_retrieval_counts_are_reported_alongside(indexed):
    retrieval = _context(indexed).json()["retrieval"]
    assert retrieval["semantic"] > 0
    assert retrieval["returned"] >= 1


def test_timings_cover_both_stages(indexed):
    body = _context(indexed).json()
    assert "retrieval" in body["timings_ms"]
    assert "context" in body["timings_ms"]
    assert body["duration_ms"] >= 0


# ---------------------------------------------------------------------
# Options
# ---------------------------------------------------------------------


def test_the_token_budget_is_honoured(indexed):
    body = _context(indexed, context_max_tokens=300).json()
    assert body["stats"]["tokens_budget"] == 300
    assert body["stats"]["tokens_used"] <= 300


def test_the_source_cap_is_honoured(indexed):
    body = _context(indexed, context_max_sources=2).json()
    assert len(body["sources"]) <= 2


def test_relevance_order_is_selectable(indexed):
    body = _context(indexed, context_order="relevance").json()
    assert body["order"] == "relevance"
    scores = [s["score"] for s in body["sources"]]
    assert scores == sorted(scores, reverse=True)


def test_document_order_is_the_default(indexed):
    assert _context(indexed).json()["order"] == "document"


def test_the_block_can_be_excluded_from_the_response(indexed):
    body = _context(indexed, include_context_text=False).json()
    assert body["context"] == ""
    assert body["sources"]
    assert body["citations"]


def test_source_text_can_be_excluded(indexed):
    body = _context(indexed, include_text=False).json()
    assert all(s["text"] == "" for s in body["sources"])
    assert body["context"]


def test_retrieval_filters_still_apply(indexed):
    body = _context(indexed, document_type="nda").json()
    assert body["sources"]
    assert all(s["document_id"] == "doc-nda" for s in body["sources"])


def test_an_unknown_order_is_a_client_error(indexed):
    response = _context(indexed, context_order="alphabetical")
    assert response.status_code == 422
    fields = response.json()["error"]["details"]["fields"]
    assert any(f["field"] == "context_order" for f in fields)


# ---------------------------------------------------------------------
# Omission reporting
# ---------------------------------------------------------------------


def test_omitted_passages_are_listed_with_reasons(indexed):
    body = _context(indexed, context_max_sources=1).json()
    assert body["omitted"]
    assert all(o["reason"] for o in body["omitted"])
    assert all(o["citation"] for o in body["omitted"])


def test_a_tight_budget_reports_what_was_left_out(indexed):
    body = _context(indexed, context_max_tokens=250).json()
    assert body["stats"]["tokens_used"] <= 250
    assert body["omitted"] or body["stats"]["truncated_sources"]


def test_thin_evidence_is_flagged_not_refused(indexed):
    body = _context(indexed, context_min_sources=50).json()
    assert body["sufficient"] is False
    assert body["context"]
    assert any("thin evidence" in w for w in body["warnings"])


# ---------------------------------------------------------------------
# Isolation and validation
# ---------------------------------------------------------------------


def test_tenant_isolation_holds_through_the_context(indexed, corpus_chunks):
    foreign = {c.chunk_id for c in corpus_chunks["other_tenant"]}
    body = _context(indexed).json()
    assert not ({s["chunk_id"] for s in body["sources"]} & foreign)

    other = _context(indexed, tenant_id=TENANT_B).json()
    assert other["sources"]
    assert all(s["document_id"] == "doc-rival" for s in other["sources"])


def test_an_unknown_tenant_gets_an_insufficient_context(indexed):
    body = _context(indexed, tenant_id="tenant-nobody").json()
    assert body["context"] == ""
    assert body["sources"] == []
    assert body["sufficient"] is False


def test_a_missing_tenant_is_a_validation_error(client):
    response = client.post("/context", json={"query": QUERY})
    assert response.status_code == 422
    assert response.json()["error"]["type"] == "validation_error"


def test_a_whitespace_query_is_handled(indexed):
    response = _context(indexed, query="   ")
    assert response.status_code == 200
    body = response.json()
    assert body["sources"] == []
    assert body["warnings"]


# ---------------------------------------------------------------------
# Config, health and wiring
# ---------------------------------------------------------------------


def test_the_config_endpoint_reports_the_live_builder(client):
    body = client.get("/context/config").json()
    assert body["max_tokens"] >= 64
    assert body["order"] in {"document", "relevance"}
    assert body["tokenizer"]


def test_health_reports_the_context_component(client):
    components = {c["name"]: c for c in client.get("/health").json()["components"]}
    assert "context" in components
    assert "budget=" in components["context"]["detail"]


def test_the_openapi_document_includes_the_context_endpoints(client):
    paths = client.get("/openapi.json").json()["paths"]
    assert "/context" in paths
    assert "/context/config" in paths


def test_the_service_root_advertises_context_construction(client):
    """Stage 6's durable claim on the root document.

    The stage *number* belongs to whichever stage is current and is
    asserted there; what must stay true here is that context
    construction is named as something this service does.
    """
    body = client.get("/").json()
    assert "context" in body["stage"].lower()
    assert "context construction" in body["scope"].lower()


def test_retrieve_still_works_unchanged(indexed):
    """Stage 6 sits on top of Stage 5; it does not replace it."""
    response = indexed.post(
        "/retrieve", json={"query": QUERY, "tenant_id": TENANT_A, "top_k": 4}
    )
    assert response.status_code == 200
    assert response.json()["results"]


def test_a_newly_indexed_document_reaches_the_context(client):
    from app.services.indexing import index_chunks

    index_chunks(
        fixtures.make_chunks(
            fixtures.VENDOR_CONTRACT,
            document_id="doc-fresh",
            tenant_id="tenant-fresh",
            filename="fresh.pdf",
        )
    )
    body = client.post(
        "/context", json={"query": QUERY, "tenant_id": "tenant-fresh"}
    ).json()
    assert body["sources"]
    assert all(s["document_id"] == "doc-fresh" for s in body["sources"])
