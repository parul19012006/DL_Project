"""Pydantic schema tests — the shape of the HTTP contract."""

from __future__ import annotations

import pytest
from pydantic import ValidationError as PydanticValidationError

from app.models.schemas import (
    ComponentStatus,
    ErrorDetail,
    ErrorResponse,
    HealthResponse,
    HealthStatus,
    LivenessResponse,
    ReadinessResponse,
    ServiceInfoResponse,
)


def test_health_response_round_trips():
    model = HealthResponse(
        status=HealthStatus.OK,
        service="svc",
        version="0.1.0",
        environment="development",
        uptime_seconds=1.5,
        components=[ComponentStatus(name="configuration", status=HealthStatus.OK)],
    )
    dumped = model.model_dump()
    assert dumped["status"] == "ok"
    assert dumped["components"][0]["name"] == "configuration"
    assert HealthResponse(**model.model_dump()).version == "0.1.0"


def test_health_response_requires_its_fields():
    with pytest.raises(PydanticValidationError):
        HealthResponse(status=HealthStatus.OK)


def test_uptime_cannot_be_negative():
    with pytest.raises(PydanticValidationError):
        HealthResponse(
            status=HealthStatus.OK,
            service="svc",
            version="0.1.0",
            environment="development",
            uptime_seconds=-1,
        )


def test_timestamp_is_auto_populated():
    model = HealthResponse(
        status=HealthStatus.OK,
        service="svc",
        version="0.1.0",
        environment="development",
        uptime_seconds=0,
    )
    assert model.timestamp is not None
    assert model.timestamp.tzinfo is not None


def test_health_status_values():
    assert {s.value for s in HealthStatus} == {"ok", "degraded", "unavailable"}


def test_component_status_detail_is_optional():
    assert ComponentStatus(name="x", status=HealthStatus.OK).detail is None


def test_invalid_status_is_rejected():
    with pytest.raises(PydanticValidationError):
        ComponentStatus(name="x", status="fine")


def test_error_response_shape():
    model = ErrorResponse(
        error=ErrorDetail(type="validation_error", message="bad", details={"a": 1}),
        request_id="req-1",
    )
    dumped = model.model_dump()
    assert dumped["error"]["type"] == "validation_error"
    assert dumped["error"]["details"] == {"a": 1}
    assert dumped["request_id"] == "req-1"


def test_error_details_default_to_empty():
    assert ErrorDetail(type="t", message="m").details == {}


def test_error_response_request_id_defaults():
    assert ErrorResponse(error=ErrorDetail(type="t", message="m")).request_id == "-"


def test_liveness_and_readiness_defaults():
    assert LivenessResponse().status == "alive"
    assert ReadinessResponse(ready=True).detail is None


def test_service_info_response():
    model = ServiceInfoResponse(
        service="svc",
        version="0.1.0",
        environment="development",
        scope="GenAI only",
        docs_url="/docs",
        stage="1",
    )
    assert model.model_dump()["docs_url"] == "/docs"


def test_schemas_appear_in_the_openapi_document(client):
    schemas = client.get("/openapi.json").json()["components"]["schemas"]
    for name in ("HealthResponse", "ErrorResponse", "ComponentStatus"):
        assert name in schemas
