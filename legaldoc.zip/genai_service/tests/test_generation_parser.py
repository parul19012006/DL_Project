"""Stage 7 — reading the model's reply.

The parser is lenient about *packaging* and strict about *shape*. These
tests pin both halves: the deviations that must be recovered from, and
the ones that must be reported as a malformed response rather than
guessed at.
"""

from __future__ import annotations

import pytest

from app.generation.base import MalformedResponseError
from app.generation.parser import parse_answer

GOOD = '{"answer": "Either party may terminate on 120 days notice.", ' \
       '"citations": [{"source": 1}, {"source": 3}], ' \
       '"insufficient_evidence": false, "interpretation": ""}'


# =====================================================================
# The clean path
# =====================================================================


def test_a_well_formed_reply_parses():
    parsed = parse_answer(GOOD)
    assert parsed.answer.startswith("Either party")
    assert parsed.cited_sources == [1, 3]
    assert parsed.insufficient_evidence is False
    assert not parsed.recovered


def test_interpretation_is_kept_separate():
    parsed = parse_answer(
        '{"answer": "The notice period is 120 days.", "citations": [{"source": 1}], '
        '"interpretation": "In practice this means serving notice by March."}'
    )
    assert "120 days" in parsed.answer
    assert "March" in parsed.interpretation
    assert "March" not in parsed.answer


def test_insufficient_evidence_is_read():
    parsed = parse_answer(
        '{"answer": "The passages do not address this.", "citations": [], '
        '"insufficient_evidence": true}'
    )
    assert parsed.insufficient_evidence
    assert not parsed.has_citations


# =====================================================================
# Packaging that must be recovered from
# =====================================================================


def test_a_markdown_fence_is_stripped():
    parsed = parse_answer(f"```json\n{GOOD}\n```")
    assert parsed.cited_sources == [1, 3]
    assert parsed.recovered


def test_an_unlabelled_fence_is_stripped():
    parsed = parse_answer(f"```\n{GOOD}\n```")
    assert parsed.answer


def test_preamble_and_trailing_prose_are_discarded():
    parsed = parse_answer(f"Sure! Here is the JSON:\n\n{GOOD}\n\nLet me know.")
    assert parsed.cited_sources == [1, 3]
    assert parsed.recovered


def test_smart_quotes_are_normalised():
    reply = '{“answer”: “A clause.”, “citations”: []}'
    assert parse_answer(reply).answer == "A clause."


def test_a_brace_inside_a_quoted_clause_does_not_break_extraction():
    """Brace counting, not a regex — legal text contains braces."""
    reply = (
        'Here you go: {"answer": "The clause reads {see Schedule A} in full.", '
        '"citations": [{"source": 2}]} done'
    )
    parsed = parse_answer(reply)
    assert "{see Schedule A}" in parsed.answer
    assert parsed.cited_sources == [2]


def test_an_escaped_quote_inside_the_answer_survives():
    reply = '{"answer": "The term \\"Services\\" is defined in Clause 1.", ' \
            '"citations": [{"source": 1}]}'
    assert '"Services"' in parse_answer(reply).answer


# =====================================================================
# Citation shapes
# =====================================================================


@pytest.mark.parametrize(
    "citations,expected",
    [
        ('[{"source": 1}, {"source": 2}]', [1, 2]),
        ('[{"source": "1"}, {"source": "2"}]', [1, 2]),
        ('[{"source": "Source 3"}]', [3]),
        ('[1, 2, 3]', [1, 2, 3]),
        ('[{"source": 1.0}]', [1]),
        ('[{"source_number": 4}]', [4]),
    ],
)
def test_citation_numbers_are_coerced_from_common_shapes(citations, expected):
    parsed = parse_answer(f'{{"answer": "An answer.", "citations": {citations}}}')
    assert parsed.cited_sources == expected


def test_an_uninterpretable_citation_is_discarded_not_guessed():
    """Guessing which block "the termination clause" meant is exactly the
    invention this stage exists to prevent."""
    parsed = parse_answer(
        '{"answer": "An answer.", "citations": [{"source": "the termination clause"}]}'
    )
    assert parsed.cited_sources == []


def test_duplicate_citations_are_collapsed():
    parsed = parse_answer(
        '{"answer": "An answer.", "citations": [{"source": 2}, {"source": 2}]}'
    )
    assert parsed.cited_sources == [2]


def test_a_zero_or_negative_source_is_discarded():
    parsed = parse_answer(
        '{"answer": "An answer.", "citations": [{"source": 0}, {"source": -1}]}'
    )
    assert parsed.cited_sources == []


def test_missing_citations_field_is_not_an_error():
    """An uncited answer is a grounding problem, not a parse problem —
    and it is caught by citation validation, which reports it properly."""
    parsed = parse_answer('{"answer": "An answer."}')
    assert parsed.answer == "An answer."
    assert parsed.cited_sources == []


# =====================================================================
# Shapes that must be reported, not guessed
# =====================================================================


def test_an_empty_reply_is_malformed():
    with pytest.raises(MalformedResponseError):
        parse_answer("")


def test_prose_with_no_json_is_malformed():
    with pytest.raises(MalformedResponseError) as excinfo:
        parse_answer("The notice period is 120 days, per clause 4.")
    assert "JSON object" in str(excinfo.value)


def test_truncated_json_is_malformed():
    """The commonest real failure: the model hit its output limit."""
    with pytest.raises(MalformedResponseError):
        parse_answer('{"answer": "Either party may terminate on 120 days not')


def test_json_without_an_answer_field_is_malformed():
    with pytest.raises(MalformedResponseError) as excinfo:
        parse_answer('{"citations": [{"source": 1}], "confidence": 0.9}')
    assert "no 'answer' field" in str(excinfo.value)


def test_an_empty_answer_is_malformed_unless_evidence_was_insufficient():
    with pytest.raises(MalformedResponseError):
        parse_answer('{"answer": "", "citations": []}')

    parsed = parse_answer('{"answer": "", "insufficient_evidence": true}')
    assert parsed.insufficient_evidence


def test_the_raw_reply_is_kept_on_the_error_for_diagnosis():
    with pytest.raises(MalformedResponseError) as excinfo:
        parse_answer("not json at all")
    assert excinfo.value.raw == "not json at all"


def test_a_list_answer_is_joined_rather_than_rejected():
    """A model returning bullets is being helpful in the wrong shape."""
    parsed = parse_answer(
        '{"answer": ["The notice period is 120 days.", "Notice must be written."], '
        '"citations": [{"source": 1}]}'
    )
    assert "120 days" in parsed.answer
    assert "written" in parsed.answer
    assert parsed.recovered


@pytest.mark.parametrize("value,expected", [("true", True), ("yes", True), ("false", False)])
def test_a_stringified_boolean_is_read(value, expected):
    parsed = parse_answer(
        f'{{"answer": "An answer.", "insufficient_evidence": "{value}"}}'
    )
    assert parsed.insufficient_evidence is expected
