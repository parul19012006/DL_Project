"""Configuration and environment-variable support."""

from __future__ import annotations

import pytest
from pydantic import ValidationError as PydanticValidationError

from app.config import Settings, get_settings, reset_settings_cache


def test_declared_defaults_are_sane():
    """Check the declared defaults, not whatever the env happens to say.

    The test environment pins LOG_LEVEL, so reading ``Settings().log_level``
    here would assert the environment rather than the default.
    """
    defaults = {name: f.default for name, f in Settings.model_fields.items()}
    assert defaults["environment"] == "development"
    assert defaults["port"] == 8000
    assert defaults["log_level"] == "INFO"
    assert defaults["log_format"] == "text"
    assert defaults["service_token"] == ""
    assert defaults["cors_origins"] == ""
    assert defaults["enable_docs"] is True


def test_service_is_unauthenticated_by_default():
    """A missing SERVICE_TOKEN must never silently become a real token."""
    assert Settings(service_token="").auth_enabled is False


def test_environment_variables_override_defaults(monkeypatch):
    monkeypatch.setenv("APP_VERSION", "9.9.9")
    monkeypatch.setenv("PORT", "9123")
    monkeypatch.setenv("ENVIRONMENT", "staging")
    reset_settings_cache()

    cfg = get_settings()
    assert cfg.app_version == "9.9.9"
    assert cfg.port == 9123
    assert cfg.environment == "staging"


def test_env_vars_are_case_insensitive(monkeypatch):
    monkeypatch.setenv("log_level", "debug")
    reset_settings_cache()
    assert get_settings().log_level == "DEBUG"


def test_log_level_is_normalised():
    assert Settings(log_level="debug").log_level == "DEBUG"


def test_invalid_log_level_is_rejected():
    with pytest.raises(PydanticValidationError):
        Settings(log_level="chatty")


def test_invalid_environment_is_rejected():
    with pytest.raises(PydanticValidationError):
        Settings(environment="prod")


def test_invalid_port_is_rejected():
    with pytest.raises(PydanticValidationError):
        Settings(port=70000)


def test_unknown_env_vars_are_ignored(monkeypatch):
    monkeypatch.setenv("SOME_UNRELATED_VAR", "value")
    reset_settings_cache()
    assert get_settings().app_version


def test_cors_origins_parse_to_a_list():
    cfg = Settings(cors_origins="http://a.test, http://b.test ,")
    assert cfg.cors_origin_list == ["http://a.test", "http://b.test"]


def test_empty_cors_origins_means_no_browser_origins():
    assert Settings(cors_origins="").cors_origin_list == []


def test_auth_enabled_follows_the_token():
    assert Settings(service_token="").auth_enabled is False
    assert Settings(service_token="  s3cret  ").auth_enabled is True
    assert Settings(service_token="  s3cret  ").service_token == "s3cret"


def test_is_production_flag():
    assert Settings(environment="production").is_production is True
    assert Settings(environment="development").is_production is False


def test_docs_urls_follow_the_toggle():
    on = Settings(enable_docs=True)
    off = Settings(enable_docs=False)
    assert on.docs_url == "/docs" and on.openapi_url == "/openapi.json"
    assert off.docs_url is None and off.openapi_url is None


def test_get_settings_is_cached():
    reset_settings_cache()
    assert get_settings() is get_settings()


def test_reset_cache_rebuilds_settings():
    first = get_settings()
    reset_settings_cache()
    assert get_settings() is not first
