"""Stage 5 — the HTTP contract the MERN backend integrates against.

These run over the real application (routing, dependency injection,
validation, serialisation, error envelope), not over the pipeline
object, because the thing another developer depends on is the JSON.
"""

from __future__ import annotations

import pytest

from tests import fixtures

TENANT_A = "tenant-a"
TENANT_B = "tenant-b"
QUERY = "How much notice is required to terminate for convenience?"


@pytest.fixture
def indexed(client, corpus_chunks):
    """Index the synthetic corpus through the service's own singletons."""
    from app.services.indexing import index_chunks

    for chunks in corpus_chunks.values():
        index_chunks(chunks)
    return client


def _retrieve(client, **body):
    payload = {"query": QUERY, "tenant_id": TENANT_A}
    payload.update(body)
    return client.post("/retrieve", json=payload)


# ---------------------------------------------------------------------
# The happy path
# ---------------------------------------------------------------------


def test_retrieve_returns_passages(indexed):
    response = _retrieve(indexed)
    assert response.status_code == 200
    body = response.json()
    assert body["results"]
    assert body["tenant_id"] == TENANT_A
    assert body["mode"] == "hybrid"


def test_every_result_has_everything_a_citation_needs(indexed):
    body = _retrieve(indexed).json()
    for result in body["results"]:
        assert result["chunk_id"]
        assert result["document_id"]
        assert result["filename"]
        assert result["page_number"] >= 1
        assert result["page_range"]
        assert result["text"]
        assert result["rank"] >= 1


def test_results_are_ranked(indexed):
    results = _retrieve(indexed).json()["results"]
    assert [r["rank"] for r in results] == list(range(1, len(results) + 1))
    scores = [r["score"] for r in results]
    assert scores == sorted(scores, reverse=True)


def test_stage_counts_are_returned(indexed):
    counts = _retrieve(indexed).json()["counts"]
    assert counts["semantic"] > 0
    assert counts["keyword"] > 0
    assert counts["returned"] == len(_retrieve(indexed).json()["results"])


def test_timings_are_returned_per_stage(indexed):
    body = _retrieve(indexed).json()
    assert set(body["timings_ms"]) >= {"preprocess", "fusion", "rerank"}
    assert body["duration_ms"] >= 0


def test_the_response_says_which_reranker_ran(indexed):
    body = _retrieve(indexed).json()
    assert body["reranked"] is True
    # The suite runs the fallback, and the contract exposes that fact.
    assert body["rerank_is_cross_encoder"] is False


# ---------------------------------------------------------------------
# Options
# ---------------------------------------------------------------------


def test_top_k_is_honoured(indexed):
    body = _retrieve(indexed, top_k=3).json()
    assert len(body["results"]) <= 3
    assert body["top_k"] == 3


def test_candidate_pool_is_honoured(indexed):
    body = _retrieve(indexed, top_k=2, candidate_pool=12).json()
    assert body["candidate_pool"] == 12
    assert body["counts"]["fused"] > len(body["results"])


@pytest.mark.parametrize("mode", ["hybrid", "semantic", "keyword"])
def test_each_mode_is_selectable(indexed, mode):
    body = _retrieve(indexed, mode=mode).json()
    assert body["mode"] == mode
    assert body["results"]


def test_include_text_false_returns_metadata_only(indexed):
    body = _retrieve(indexed, include_text=False).json()
    assert body["results"]
    assert all(r["text"] == "" for r in body["results"])
    assert all(r["chunk_id"] for r in body["results"])


def test_explain_exposes_every_stage_score(indexed):
    body = _retrieve(indexed, explain=True).json()
    scores = body["results"][0]["scores"]
    assert set(scores) >= {"semantic", "keyword", "fused", "ranked", "final"}
    assert isinstance(scores["sources"], list)


def test_explain_is_off_by_default(indexed):
    assert _retrieve(indexed).json()["results"][0]["scores"] is None


def test_detected_clause_references_are_echoed(indexed):
    body = _retrieve(indexed, query="what does clause 4.2 say").json()
    assert "clause 4.2" in body["references"]


def test_reranking_can_be_disabled(indexed):
    body = _retrieve(indexed, rerank=False).json()
    assert body["reranked"] is False
    assert body["results"]


# ---------------------------------------------------------------------
# Filtering and isolation
# ---------------------------------------------------------------------


def test_document_type_filter(indexed):
    body = _retrieve(indexed, document_type="nda").json()
    assert body["results"]
    assert all(r["document_id"] == "doc-nda" for r in body["results"])


def test_document_ids_filter(indexed):
    body = _retrieve(indexed, document_ids=["doc-contract"]).json()
    assert body["results"]
    assert all(r["document_id"] == "doc-contract" for r in body["results"])


def test_page_range_filter(indexed):
    body = _retrieve(indexed, page_range=[1, 1]).json()
    assert all(r["page_number"] == 1 for r in body["results"])


def test_tenant_isolation_over_http(indexed, corpus_chunks):
    """Both tenants hold the same contract text; neither sees the other."""
    foreign = {c.chunk_id for c in corpus_chunks["other_tenant"]}
    body = _retrieve(indexed).json()
    assert body["results"]
    assert not ({r["chunk_id"] for r in body["results"]} & foreign)

    other = _retrieve(indexed, tenant_id=TENANT_B).json()
    assert other["results"]
    assert all(r["document_id"] == "doc-rival" for r in other["results"])


def test_an_unknown_tenant_gets_an_empty_result_set(indexed):
    body = _retrieve(indexed, tenant_id="tenant-nobody").json()
    assert body["results"] == []
    assert body["counts"]["returned"] == 0


# ---------------------------------------------------------------------
# Validation and errors
# ---------------------------------------------------------------------


def test_a_missing_tenant_is_a_validation_error(client):
    response = client.post("/retrieve", json={"query": QUERY})
    assert response.status_code == 422
    body = response.json()
    assert body["error"]["type"] == "validation_error"
    assert "request_id" in body


def test_an_empty_query_is_rejected_by_validation(client):
    response = client.post("/retrieve", json={"query": "", "tenant_id": TENANT_A})
    assert response.status_code == 422


def test_a_whitespace_query_is_handled_not_crashed(indexed):
    """Passes min_length but means nothing — answered, with a warning."""
    response = _retrieve(indexed, query="   ")
    assert response.status_code == 200
    body = response.json()
    assert body["results"] == []
    assert body["warnings"]


def test_an_out_of_range_top_k_is_rejected(client):
    response = client.post(
        "/retrieve", json={"query": QUERY, "tenant_id": TENANT_A, "top_k": 0}
    )
    assert response.status_code == 422


def test_an_unknown_mode_is_a_client_error_not_a_server_error(indexed):
    """A typo in the backend's payload must not read as a service fault."""
    response = _retrieve(indexed, mode="telepathy")
    assert response.status_code == 422
    fields = response.json()["error"]["details"]["fields"]
    assert any(f["field"] == "mode" for f in fields)


# ---------------------------------------------------------------------
# Configuration endpoint and health
# ---------------------------------------------------------------------


def test_the_config_endpoint_reports_the_live_pipeline(client):
    body = client.get("/retrieve/config").json()
    assert body["mode"] in {"hybrid", "semantic", "keyword"}
    assert body["top_k"] >= 1
    assert body["candidate_pool"] >= 1
    assert body["fusion_method"] in {"rrf", "weighted"}
    assert body["reranker_active"]


def test_the_config_endpoint_exposes_a_fallback_reranker(client):
    """An operator can tell from here that the real model is not loaded."""
    body = client.get("/retrieve/config").json()
    assert body["rerank_is_cross_encoder"] is False


def test_health_reports_the_retrieval_components(client):
    components = {c["name"]: c for c in client.get("/health").json()["components"]}
    assert "retrieval" in components
    assert "reranker" in components
    assert "top_k" in components["retrieval"]["detail"]


def test_the_openapi_document_includes_the_retrieval_endpoint(client):
    paths = client.get("/openapi.json").json()["paths"]
    assert "/retrieve" in paths
    assert "/retrieve/config" in paths


def test_the_service_root_advertises_retrieval(client):
    """Stage 5's durable claim on the root document.

    The stage *number* belongs to whichever stage is current and is
    asserted there; what must stay true here is that retrieval is named,
    and that the scope keeps saying what this service does not do.
    """
    body = client.get("/").json()
    assert "retrieval" in body["stage"].lower()
    assert "generation" in body["scope"].lower()


# ---------------------------------------------------------------------
# Interaction with Stage 4
# ---------------------------------------------------------------------


def test_search_still_works_unchanged(indexed):
    """Stage 5 wraps Stage 4's primitive; it does not replace it."""
    response = indexed.post(
        "/search", json={"query": QUERY, "tenant_id": TENANT_A, "top_k": 5}
    )
    assert response.status_code == 200
    assert response.json()["hits"]


def test_retrieval_sees_a_newly_indexed_document(client):
    """No stale BM25 index: a document indexed now is retrievable now."""
    from app.services.indexing import index_chunks

    index_chunks(
        fixtures.make_chunks(
            fixtures.VENDOR_CONTRACT,
            document_id="doc-fresh",
            tenant_id="tenant-fresh",
            filename="fresh.pdf",
        )
    )
    body = client.post(
        "/retrieve",
        json={"query": QUERY, "tenant_id": "tenant-fresh", "mode": "keyword"},
    ).json()
    assert body["results"]
    assert all(r["document_id"] == "doc-fresh" for r in body["results"])
