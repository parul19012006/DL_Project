"""Extraction: normal PDF, multi-page PDF, DOCX, scanned PDF.

All documents are synthetic — invented parties, invented clauses.
"""

from __future__ import annotations

import pytest

from app.ingestion.service import DOCUMENT_SHA256, extract_document
from app.models.document import (
    BlockKind,
    DocumentType,
    ExtractedDocument,
    ExtractionMethod,
)


def _extract(path, settings, **kwargs) -> ExtractedDocument:
    defaults = dict(
        document_id="doc-1", tenant_id="tenant-a", file_path=path.name
    )
    defaults.update(kwargs)
    return extract_document(settings=settings, **defaults)


# =====================================================================
# Normal PDF
# =====================================================================


def test_normal_pdf_extracts_text(contract_pdf, settings):
    document = _extract(contract_pdf, settings)

    assert document.page_count >= 1
    assert not document.is_empty
    assert document.stats.parser == "pymupdf"
    assert document.stats.char_count > 200

    body = document.full_text()
    assert "Northwind Systems" in body
    assert "Harbour Legal LLP" in body


def test_normal_pdf_preserves_legal_substance(contract_pdf, settings):
    """Cleaning must not touch numbers, dates, parties or defined terms."""
    body = _extract(contract_pdf, settings).full_text()
    for needle in [
        "INR 4,50,000",     # amount with separators
        "1 March 2024",     # date
        "thirty-six (36)",  # hyphenated numeral
        "ninety (90)",
        "1.5%",             # percentage
        "Schedule A",       # cross-reference
    ]:
        assert needle in body, f"cleaning removed or altered '{needle}'"


def test_normal_pdf_detects_sections(contract_pdf, settings):
    sections = _extract(contract_pdf, settings).sections
    assert sections
    joined = " ".join(sections).upper()
    assert "DEFINITIONS" in joined or "TERM" in joined


def test_normal_pdf_produces_blocks_with_kinds(contract_pdf, settings):
    blocks = list(_extract(contract_pdf, settings).iter_blocks())
    assert blocks
    assert any(b.kind is BlockKind.HEADING for b in blocks)
    assert any(b.kind is BlockKind.PARAGRAPH for b in blocks)
    assert all(b.text.strip() for b in blocks)


def test_normal_pdf_does_not_invoke_ocr(contract_pdf, settings):
    document = _extract(contract_pdf, settings)
    assert document.stats.ocr_page_count == 0
    assert document.stats.method is ExtractionMethod.NATIVE
    assert all(not p.ocr_used for p in document.pages)


def test_document_type_is_inferred(contract_pdf, settings):
    document = _extract(contract_pdf, settings)
    assert document.metadata.document_type is DocumentType.CONTRACT


def test_declared_document_type_wins(contract_pdf, settings):
    document = _extract(contract_pdf, settings, document_type="policy")
    assert document.metadata.document_type is DocumentType.POLICY


def test_unknown_declared_type_falls_back_to_inference(contract_pdf, settings):
    document = _extract(contract_pdf, settings, document_type="not-a-type")
    assert document.metadata.document_type is DocumentType.CONTRACT


# =====================================================================
# Multi-page PDF
# =====================================================================


def test_multipage_pdf_has_several_pages(multipage_pdf, settings):
    document = _extract(multipage_pdf, settings)
    assert document.page_count >= 3


def test_page_numbers_are_contiguous_and_one_based(multipage_pdf, settings):
    document = _extract(multipage_pdf, settings)
    numbers = [p.page_number for p in document.pages]
    assert numbers == list(range(1, document.page_count + 1))


def test_every_block_carries_its_page_number(multipage_pdf, settings):
    document = _extract(multipage_pdf, settings)
    for page in document.pages:
        for block in page.blocks:
            assert block.page_number == page.page_number


def test_content_is_distributed_across_pages(multipage_pdf, settings):
    """Page-level preservation: text must not collapse onto page 1."""
    document = _extract(multipage_pdf, settings)
    pages_with_text = [p for p in document.pages if not p.is_empty]
    assert len(pages_with_text) >= 3

    termination = [
        p.page_number for p in document.pages if "120" in p.text or "convenience" in p.text
    ]
    assert termination and termination[0] > 1, (
        "the termination clause should not be on page 1"
    )


def test_get_page_returns_the_right_page(multipage_pdf, settings):
    document = _extract(multipage_pdf, settings)
    page = document.get_page(2)
    assert page is not None and page.page_number == 2
    assert document.get_page(9999) is None


def test_running_footer_is_removed(multipage_pdf, settings):
    """The repeated footer appears on every page and must be stripped."""
    document = _extract(multipage_pdf, settings)
    body = document.full_text()
    assert "Northwind Systems - Confidential - Managed Services Agreement" not in body
    assert document.stats.running_headers_removed > 0
    # ...but the clause text on those pages survives.
    assert "arbitration" in body.lower() or "Bengaluru" in body


def test_page_numbers_are_stripped_from_text(multipage_pdf, settings):
    document = _extract(multipage_pdf, settings)
    for page in document.pages:
        for line in page.text.split("\n"):
            assert line.strip() != f"Page {page.page_number}"


def test_a_short_document_keeps_its_edge_lines(contract_pdf, settings):
    """Header stripping needs >= HEADER_FOOTER_MIN_PAGES; a short doc is safe."""
    document = _extract(contract_pdf, settings)
    if document.page_count < settings.header_footer_min_pages:
        assert document.stats.running_headers_removed == 0


# =====================================================================
# DOCX
# =====================================================================


def test_docx_extracts_text(nda_docx, settings):
    document = _extract(nda_docx, settings, document_id="doc-nda")
    assert not document.is_empty
    assert document.stats.parser == "python-docx"
    assert "Delaware" in document.full_text()
    assert "Meridian Analytics" in document.full_text()


def test_docx_uses_word_heading_styles(nda_docx, settings):
    sections = _extract(nda_docx, settings).sections
    joined = " ".join(sections).upper()
    assert "TERMINATION" in joined
    assert "GOVERNING LAW" in joined


def test_docx_extracts_table_content(nda_docx, settings):
    document = _extract(nda_docx, settings)
    blocks = list(document.iter_blocks())
    tables = [b for b in blocks if b.kind is BlockKind.TABLE]
    assert tables
    assert "Notice Address" in " ".join(b.text for b in tables)
    assert "Wilmington" in document.full_text()


def test_docx_pages_are_marked_synthetic(nda_docx, settings):
    document = _extract(nda_docx, settings)
    assert all(p.synthetic for p in document.pages)


def test_docx_page_breaks_start_new_pages(paged_docx, settings):
    document = _extract(paged_docx, settings, document_id="doc-paged")
    assert document.page_count >= 4
    assert [p.page_number for p in document.pages] == list(
        range(1, document.page_count + 1)
    )


def test_docx_type_is_inferred_as_nda(nda_docx, settings):
    assert _extract(nda_docx, settings).metadata.document_type is DocumentType.NDA


def test_docx_ignores_force_ocr_with_a_warning(nda_docx, settings):
    document = _extract(nda_docx, settings, force_ocr=True)
    assert any("force_ocr" in w for w in document.warnings)
    assert document.stats.ocr_page_count == 0


# =====================================================================
# Scanned / low-text PDF
# =====================================================================


def test_scanned_pdf_is_detected_as_needing_ocr(scanned_pdf, settings):
    """Independent of whether Tesseract is installed."""
    from app.ingestion.ocr import page_needs_ocr
    from app.ingestion.pdf_parser import _import_pymupdf, _page_blocks

    fitz = _import_pymupdf()
    document = fitz.open(str(scanned_pdf))
    try:
        native = "\n".join(t for t, _ in _page_blocks(document.load_page(0)))
    finally:
        document.close()

    assert page_needs_ocr(native, settings), (
        "an image-only page should be routed to OCR"
    )


@pytest.mark.skipif(
    not __import__("app.ingestion.ocr", fromlist=["ocr_available"]).ocr_available(),
    reason="tesseract is not installed",
)
def test_scanned_pdf_is_read_via_ocr(scanned_pdf, settings):
    document = _extract(scanned_pdf, settings, document_id="doc-scan")

    assert document.stats.ocr_page_count >= 1
    assert document.stats.parser == "pymupdf+ocr"
    assert document.stats.method in (ExtractionMethod.OCR, ExtractionMethod.MIXED)

    text = document.full_text().upper()
    assert "AWARD" in text or "TRIBUNAL" in text

    ocr_blocks = [b for b in document.iter_blocks() if b.ocr]
    assert ocr_blocks, "blocks from an OCR'd page must be flagged ocr=True"


def test_scanned_pdf_without_ocr_fails_with_a_useful_message(
    scanned_pdf, make_settings
):
    """OCR disabled: the failure must explain *why*, not just 'empty'."""
    from app.ingestion.errors import EmptyDocumentError

    cfg = make_settings(ocr_enabled=False)
    with pytest.raises(EmptyDocumentError) as excinfo:
        _extract(scanned_pdf, cfg, document_id="doc-scan-noocr")

    message = excinfo.value.message.lower()
    assert "ocr" in message and "disabled" in message


# =====================================================================
# Metadata preservation
# =====================================================================


def test_metadata_is_complete(contract_pdf, settings):
    document = extract_document(
        document_id="doc-77",
        tenant_id="tenant-alpha",
        file_path=contract_pdf.name,
        filename="vendor_contract_2024.pdf",
        document_type="contract",
        title="Managed Services Agreement",
        extra={"matter_id": "M-77", "nested": {"dropped": True}},
        settings=settings,
    )
    meta = document.metadata

    assert meta.document_id == "doc-77"
    assert meta.tenant_id == "tenant-alpha"
    assert meta.filename == "vendor_contract_2024.pdf"
    assert meta.document_type is DocumentType.CONTRACT
    assert meta.title == "Managed Services Agreement"
    assert meta.content_sha256 and len(meta.content_sha256) == 64
    assert meta.size_bytes > 0
    # Only scalars survive into metadata, alongside the content digest
    # the service carries onto every chunk.
    assert meta.extra["matter_id"] == "M-77"
    assert "nested" not in meta.extra
    assert meta.extra[DOCUMENT_SHA256] == meta.content_sha256


def test_a_caller_cannot_shadow_the_content_digest(contract_pdf, settings):
    """It is what the unchanged-document check depends on, so a
    caller-supplied value of the same name is dropped rather than
    trusted."""
    document = extract_document(
        document_id="doc-78",
        tenant_id="tenant-alpha",
        file_path=contract_pdf.name,
        extra={DOCUMENT_SHA256: "0" * 64, "matter_id": "M-78"},
        settings=settings,
    )
    assert document.metadata.extra[DOCUMENT_SHA256] != "0" * 64
    assert document.metadata.extra["matter_id"] == "M-78"


def test_every_block_can_produce_a_full_citation(multipage_pdf, settings):
    document = extract_document(
        document_id="doc-cite",
        tenant_id="tenant-beta",
        file_path=multipage_pdf.name,
        document_type="contract",
        settings=settings,
    )
    for block in document.iter_blocks():
        provenance = block.provenance()
        assert provenance["document_id"] == "doc-cite"
        assert provenance["tenant_id"] == "tenant-beta"
        assert provenance["filename"] == multipage_pdf.name
        assert provenance["page_number"] >= 1
        assert provenance["block_id"]
        # chunk_id belongs to Stage 3 and must not exist yet.
        assert "chunk_id" not in provenance


def test_block_ids_are_unique_and_deterministic(multipage_pdf, settings):
    first = _extract(multipage_pdf, settings)
    second = _extract(multipage_pdf, settings)

    ids_a = [b.block_id() for b in first.iter_blocks()]
    ids_b = [b.block_id() for b in second.iter_blocks()]

    assert ids_a == ids_b, "re-ingesting the same file must give the same ids"
    assert len(ids_a) == len(set(ids_a)), "block ids must be unique"


def test_content_hash_is_stable(contract_pdf, settings):
    a = _extract(contract_pdf, settings).metadata.content_sha256
    b = _extract(contract_pdf, settings).metadata.content_sha256
    assert a == b


def test_raw_text_is_retained_for_recovery(multipage_pdf, settings):
    document = _extract(multipage_pdf, settings)
    assert settings.keep_raw_text
    assert any(p.raw_text is not None for p in document.pages)


def test_stats_are_consistent(multipage_pdf, settings):
    document = _extract(multipage_pdf, settings)
    stats = document.stats

    assert stats.page_count == len(document.pages)
    assert stats.block_count == sum(len(p.blocks) for p in document.pages)
    assert stats.char_count == sum(p.char_count for p in document.pages)
    assert stats.duration_ms >= 0
    assert stats.cleaning_applied is True


def test_to_dict_round_trip(contract_pdf, settings):
    data = _extract(contract_pdf, settings).to_dict(include_blocks=True)

    assert data["metadata"]["document_id"] == "doc-1"
    assert data["stats"]["parser"] == "pymupdf"
    assert data["pages"][0]["page_number"] == 1
    assert "blocks" in data["pages"][0]

    lean = _extract(contract_pdf, settings).to_dict(include_blocks=False)
    assert "blocks" not in lean["pages"][0]
