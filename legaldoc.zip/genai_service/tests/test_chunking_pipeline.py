"""Stage 2 -> Stage 3 end to end, plus the HTTP contract.

Real PDFs and DOCX files (synthetic content) go through extraction and
then chunking, which is the path Stage 4 will call.
"""

from __future__ import annotations

import pytest

from app.chunking.chunker import chunk_document, chunk_with_stats
from app.ingestion.service import extract_document
from app.models.document import DocumentType


def _extract(path, settings, **kwargs):
    defaults = dict(document_id="doc-1", tenant_id="tenant-a", file_path=path.name)
    defaults.update(kwargs)
    return extract_document(settings=settings, **defaults)


# =====================================================================
# End to end on real files
# =====================================================================


def test_a_real_contract_chunks_by_clause(multipage_pdf, settings):
    document = _extract(multipage_pdf, settings, document_type="contract")
    chunks = chunk_document(document, settings)

    assert chunks
    sections = [c.section for c in chunks if c.section]
    assert sections, "no chunk carried a section label"

    # Each detected clause should be reachable, and no chunk should mix
    # the termination clause with the liability clause.
    termination = [c for c in chunks if c.section and "TERMINATION" in c.section]
    assert termination
    for chunk in termination:
        assert "LIMITATION OF LIABILITY" not in chunk.text


def test_real_contract_chunks_carry_full_metadata(multipage_pdf, settings):
    document = _extract(
        multipage_pdf,
        settings,
        document_id="doc-77",
        tenant_id="tenant-alpha",
        document_type="contract",
    )
    chunks = chunk_document(document, settings)

    for chunk in chunks:
        assert chunk.chunk_id
        assert chunk.document_id == "doc-77"
        assert chunk.tenant_id == "tenant-alpha"
        assert chunk.filename == multipage_pdf.name
        assert chunk.page_number >= 1
        assert chunk.document_type is DocumentType.CONTRACT
        assert chunk.text.strip()


def test_chunk_page_numbers_stay_within_the_document(multipage_pdf, settings):
    document = _extract(multipage_pdf, settings)
    chunks = chunk_document(document, settings)

    for chunk in chunks:
        assert 1 <= chunk.page_number <= document.page_count
        assert 1 <= (chunk.page_end or 0) <= document.page_count


def test_legal_substance_survives_extraction_and_chunking(multipage_pdf, settings):
    """The values a lawyer would actually ask about must still be there."""
    document = _extract(multipage_pdf, settings)
    combined = " ".join(c.text for c in chunk_document(document, settings))

    for needle in [
        "INR 4,50,000",
        "one hundred and twenty (120)",
        "thirty-six (36)",
        "Bengaluru",
        "Northwind Systems",
    ]:
        assert needle in combined, f"lost through the pipeline: {needle!r}"


def test_a_docx_chunks_end_to_end(nda_docx, settings):
    document = _extract(nda_docx, settings, document_id="doc-nda")
    chunks = chunk_document(document, settings)

    assert chunks
    assert "Delaware" in " ".join(c.text for c in chunks)
    assert all(c.filename == nda_docx.name for c in chunks)


def test_a_scanned_document_marks_its_chunks_as_ocr(scanned_pdf, settings):
    from app.ingestion.ocr import ocr_available

    if not ocr_available(settings):
        pytest.skip("tesseract is not installed")

    document = _extract(scanned_pdf, settings, document_id="doc-scan")
    chunks = chunk_document(document, settings)

    assert chunks
    assert all(c.ocr for c in chunks), (
        "chunks from an OCR'd page must be flagged, so a quotation from "
        "them can be treated with appropriate caution"
    )


def test_end_to_end_is_deterministic(multipage_pdf, settings):
    first = chunk_document(_extract(multipage_pdf, settings), settings)
    second = chunk_document(_extract(multipage_pdf, settings), settings)

    assert [c.chunk_id for c in first] == [c.chunk_id for c in second]
    assert [c.text for c in first] == [c.text for c in second]


def test_stats_are_reported_for_a_real_document(multipage_pdf, settings):
    document = _extract(multipage_pdf, settings)
    chunks, stats = chunk_with_stats(document, settings)

    assert stats.chunk_count == len(chunks)
    assert stats.pages_covered >= 1
    assert stats.tokenizer
    assert stats.duration_ms >= 0


def test_small_chunk_size_forces_more_chunks_on_a_real_document(
    multipage_pdf, make_settings
):
    document = _extract(multipage_pdf, make_settings())
    few = chunk_document(document, make_settings(chunk_size=500))
    many = chunk_document(document, make_settings(chunk_size=60, min_chunk_tokens=10))

    assert len(many) > len(few)


# =====================================================================
# HTTP contract
# =====================================================================


def _payload(path, **kwargs) -> dict:
    body = {
        "document_id": "doc-chunk-1",
        "tenant_id": "tenant-alpha",
        "file_path": path.name,
    }
    body.update(kwargs)
    return body


def test_chunk_endpoint_returns_chunks(client, multipage_pdf):
    response = client.post("/documents/chunk", json=_payload(multipage_pdf))
    assert response.status_code == 200

    body = response.json()
    assert body["status"] == "success"
    assert body["chunks"]
    assert body["chunking"]["chunk_count"] == len(body["chunks"])
    assert body["extraction"]["page_count"] >= 1


def test_chunk_endpoint_fields_match_the_contract(client, multipage_pdf):
    body = client.post("/documents/chunk", json=_payload(multipage_pdf)).json()
    chunk = body["chunks"][0]

    for field in (
        "chunk_id", "chunk_index", "document_id", "tenant_id", "filename",
        "page_number", "section", "document_type", "text", "token_count",
    ):
        assert field in chunk, f"{field} missing from the chunk contract"

    assert chunk["document_id"] == "doc-chunk-1"
    assert chunk["tenant_id"] == "tenant-alpha"
    assert chunk["chunk_index"] == 0


def test_chunk_indices_are_sequential_over_http(client, multipage_pdf):
    body = client.post("/documents/chunk", json=_payload(multipage_pdf)).json()
    indices = [c["chunk_index"] for c in body["chunks"]]
    assert indices == list(range(len(indices)))


def test_chunk_size_can_be_overridden_per_request(client, multipage_pdf):
    small = client.post(
        "/documents/chunk",
        json=_payload(multipage_pdf, chunk_size=60, min_chunk_tokens=10),
    ).json()
    large = client.post(
        "/documents/chunk", json=_payload(multipage_pdf, chunk_size=800)
    ).json()

    assert small["chunking"]["chunk_count"] > large["chunking"]["chunk_count"]
    assert small["chunking"]["chunk_size"] == 60
    assert large["chunking"]["chunk_size"] == 800


def test_overlap_can_be_overridden_per_request(client, multipage_pdf):
    body = client.post(
        "/documents/chunk",
        json=_payload(multipage_pdf, chunk_size=80, chunk_overlap=30,
                      min_chunk_tokens=10),
    ).json()
    assert body["chunking"]["chunk_overlap"] == 30


def test_a_request_override_does_not_leak_into_the_service_config(
    client, multipage_pdf, settings
):
    """One caller's tuning must not change the next caller's result."""
    before = settings.chunk_size
    client.post("/documents/chunk", json=_payload(multipage_pdf, chunk_size=64))
    assert settings.chunk_size == before

    body = client.post("/documents/chunk", json=_payload(multipage_pdf)).json()
    assert body["chunking"]["chunk_size"] == before


def test_sections_can_be_ignored_over_http(client, multipage_pdf):
    respecting = client.post(
        "/documents/chunk", json=_payload(multipage_pdf, respect_sections=True)
    ).json()
    ignoring = client.post(
        "/documents/chunk", json=_payload(multipage_pdf, respect_sections=False)
    ).json()

    assert ignoring["chunking"]["chunk_count"] <= respecting["chunking"]["chunk_count"]


def test_chunk_text_can_be_omitted(client, multipage_pdf):
    body = client.post(
        "/documents/chunk", json=_payload(multipage_pdf, include_chunk_text=False)
    ).json()

    assert body["chunks"]
    assert all(c["text"] == "" for c in body["chunks"])
    assert all(c["token_count"] > 0 for c in body["chunks"])


def test_chunk_endpoint_reports_extraction_and_chunking_stats(
    client, multipage_pdf
):
    body = client.post("/documents/chunk", json=_payload(multipage_pdf)).json()

    assert body["extraction"]["parser"] == "pymupdf"
    assert body["chunking"]["tokenizer"]
    assert body["chunking"]["mean_tokens"] > 0
    assert body["chunking"]["duration_ms"] >= 0


def test_chunk_endpoint_propagates_extraction_errors(client, corrupt_pdf):
    response = client.post("/documents/chunk", json=_payload(corrupt_pdf))
    assert response.status_code == 422
    assert response.json()["error"]["type"] == "corrupt_document"


def test_chunk_endpoint_rejects_an_unsupported_type(client, unsupported_file):
    response = client.post("/documents/chunk", json=_payload(unsupported_file))
    assert response.status_code == 415


def test_chunk_endpoint_rejects_path_traversal(client):
    response = client.post(
        "/documents/chunk",
        json={"document_id": "d", "tenant_id": "t", "file_path": "../../etc/passwd"},
    )
    assert response.status_code == 400


def test_chunk_endpoint_validates_chunk_size_bounds(client, multipage_pdf):
    response = client.post(
        "/documents/chunk", json=_payload(multipage_pdf, chunk_size=1)
    )
    assert response.status_code == 422
    assert response.json()["error"]["type"] == "validation_error"


def test_chunk_endpoint_requires_the_service_token(
    client_factory, make_settings, multipage_pdf
):
    with client_factory(make_settings(service_token="s3cret")) as c:
        assert c.post(
            "/documents/chunk", json=_payload(multipage_pdf)
        ).status_code == 401
        assert c.post(
            "/documents/chunk",
            json=_payload(multipage_pdf),
            headers={"X-Service-Token": "s3cret"},
        ).status_code == 200


def test_openapi_documents_the_chunk_endpoint(client):
    spec = client.get("/openapi.json").json()
    assert "/documents/chunk" in spec["paths"]
    assert "ChunkModel" in spec["components"]["schemas"]


def test_health_reports_the_chunking_component(client, settings):
    components = {c["name"]: c for c in client.get("/health").json()["components"]}

    assert "chunking" in components
    assert components["chunking"]["status"] == "ok"
    assert f"size={settings.chunk_size}" in components["chunking"]["detail"]


def test_health_flags_an_overlap_that_will_be_clamped(
    client_factory, make_settings
):
    cfg = make_settings(chunk_size=100, chunk_overlap=90)
    with client_factory(cfg) as c:
        body = c.get("/health").json()

    components = {comp["name"]: comp for comp in body["components"]}
    assert components["chunking"]["status"] == "degraded"
    assert "clamped" in components["chunking"]["detail"]
    assert body["status"] == "degraded"
