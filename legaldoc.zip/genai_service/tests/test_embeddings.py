"""Embedding generation and — above all — dimension discovery.

The dimension tests are the point of this file. A hard-coded 768 is the
classic way to break a vector pipeline, so the width is checked against
stub models at many sizes, against a *real* locally-built
SentenceTransformer at 96 dimensions, and against the config surface
(which has no dimension setting for the real provider at all).
"""

from __future__ import annotations

import math
import sys
import types

import pytest

from app.embeddings.base import EmbeddingError, EmbeddingModel
from app.embeddings.deterministic import DeterministicEmbedding
from app.embeddings.factory import (
    build_embedding_model,
    embed_in_batches,
    get_embedding_model,
    iter_batches,
    set_embedding_model,
)


# =====================================================================
# Stub Sentence-Transformers model
# =====================================================================


class _StubST:
    """Mimics only what the wrapper touches."""

    def __init__(
        self,
        dimension: int,
        declared=None,
        accessor: str = "get_embedding_dimension",
        max_seq: int = 256,
    ):
        self._dimension = dimension
        self._declared = dimension if declared is None else declared
        self.max_seq_length = max_seq
        if accessor:
            setattr(self, accessor, lambda: self._declared)

    def modules(self):
        return [self]

    def encode(self, texts, **kwargs):
        import numpy as np

        if isinstance(texts, str):
            return np.zeros(self._dimension, dtype="float32")
        return np.zeros((len(texts), self._dimension), dtype="float32")


def install_stub(monkeypatch, model):
    module = types.ModuleType("sentence_transformers")
    module.SentenceTransformer = lambda name, **kwargs: model
    monkeypatch.setitem(sys.modules, "sentence_transformers", module)


def _wrapper():
    from app.embeddings.sentence_transformer import SentenceTransformerEmbedding

    return SentenceTransformerEmbedding


# =====================================================================
# Dimension discovery — the headline requirement
# =====================================================================


@pytest.mark.parametrize("dimension", [64, 96, 128, 384, 512, 768, 1024, 1536, 3072])
def test_dimension_comes_from_the_model(monkeypatch, dimension):
    """Every common embedding width, including but not limited to 768."""
    install_stub(monkeypatch, _StubST(dimension))
    assert _wrapper()("stub/model").dimension == dimension


def test_768_is_never_assumed(monkeypatch):
    """The canonical failure: a 384-wide model treated as 768."""
    install_stub(monkeypatch, _StubST(384))
    assert _wrapper()("stub/model").dimension == 384


def test_dimension_falls_back_to_a_probe_encode(monkeypatch):
    """No accessor at all: measure a real output vector."""
    install_stub(monkeypatch, _StubST(200, accessor=""))
    assert _wrapper()("stub/model").dimension == 200


def test_legacy_accessor_name_is_supported(monkeypatch):
    """Sentence-Transformers < 6 used the longer name."""
    install_stub(
        monkeypatch,
        _StubST(312, accessor="get_sentence_embedding_dimension"),
    )
    assert _wrapper()("stub/model").dimension == 312


def test_a_model_that_lies_about_its_dimension_is_refused(monkeypatch):
    """Config says 768, the vectors are 384 wide.

    Indexing at the wrong width produces a collection that silently
    rejects or corrupts later writes, so refuse rather than guess.
    """
    install_stub(monkeypatch, _StubST(384, declared=768))
    with pytest.raises(EmbeddingError) as excinfo:
        _wrapper()("stub/model")

    message = str(excinfo.value)
    assert "768" in message and "384" in message


def test_a_zero_width_model_is_refused(monkeypatch):
    install_stub(monkeypatch, _StubST(0, accessor=""))
    with pytest.raises(EmbeddingError):
        _wrapper()("stub/model")


def test_vectors_match_the_reported_dimension(monkeypatch):
    install_stub(monkeypatch, _StubST(333))
    model = _wrapper()("stub/model")
    vectors = model.embed_documents(["clause a", "clause b"])

    assert len(vectors) == 2
    assert all(len(v) == model.dimension == 333 for v in vectors)


def test_max_sequence_length_is_read_from_the_model(monkeypatch):
    install_stub(monkeypatch, _StubST(128, max_seq=512))
    assert _wrapper()("stub/model").max_sequence_length == 512


def test_a_model_that_fails_to_load_raises(monkeypatch):
    module = types.ModuleType("sentence_transformers")

    def explode(*args, **kwargs):
        raise OSError("model download blocked")

    module.SentenceTransformer = explode
    monkeypatch.setitem(sys.modules, "sentence_transformers", module)

    with pytest.raises(EmbeddingError):
        _wrapper()("stub/model")


def test_there_is_no_dimension_setting_for_the_real_provider(settings):
    """The dimension must come from the model, so it is not configurable.

    A ``EMBEDDING_DIMENSION`` setting would be a footgun: someone would
    set it to 768 and it would disagree with the model.
    """
    fields = set(type(settings).model_fields)
    assert "embedding_dimension" not in fields
    assert "vector_dimension" not in fields
    # Only the deterministic test encoder has a configurable width.
    assert "deterministic_embedding_dim" in fields


# =====================================================================
# A real SentenceTransformer, built locally at 96 dimensions
# =====================================================================


def test_a_real_sentence_transformer_reports_its_own_dimension(
    tiny_st_model_path,
):
    """The genuine code path, no stub, no download, and not 768."""
    if tiny_st_model_path is None:
        pytest.skip("transformers/sentence-transformers unavailable")

    model = _wrapper()(str(tiny_st_model_path), normalize=True)

    assert model.dimension == 96, "the dimension must come from the model"
    assert model.name == "sentence_transformers"
    assert model.max_sequence_length == 32


def test_a_real_sentence_transformer_encodes(tiny_st_model_path):
    if tiny_st_model_path is None:
        pytest.skip("transformers/sentence-transformers unavailable")

    model = _wrapper()(str(tiny_st_model_path), normalize=True)
    vectors = model.embed_documents(
        ["termination of the agreement", "notice to the party"]
    )

    assert len(vectors) == 2
    assert all(len(v) == 96 for v in vectors)
    # normalize=True must actually produce unit vectors.
    for vector in vectors:
        assert math.isclose(
            math.sqrt(sum(v * v for v in vector)), 1.0, abs_tol=1e-4
        )


def test_a_real_sentence_transformer_embeds_a_query(tiny_st_model_path):
    if tiny_st_model_path is None:
        pytest.skip("transformers/sentence-transformers unavailable")

    model = _wrapper()(str(tiny_st_model_path))
    assert len(model.embed_query("termination notice")) == model.dimension


def test_a_real_model_round_trips_through_the_store(tiny_st_model_path, tmp_path):
    """The store is built at the model's width, whatever that is."""
    if tiny_st_model_path is None:
        pytest.skip("transformers/sentence-transformers unavailable")

    from app.models.chunk import Chunk
    from app.vectorstore.base import SearchFilter
    from app.vectorstore.memory import InMemoryVectorStore

    model = _wrapper()(str(tiny_st_model_path))
    store = InMemoryVectorStore(dimension=model.dimension)
    assert store.dimension == 96

    chunk = Chunk(
        chunk_id="c1", chunk_index=0, text="termination notice to the party",
        document_id="d1", tenant_id="t1", filename="a.pdf", page_number=1,
    )
    store.upsert([chunk], model.embed_documents([chunk.text]))

    hits = store.search(
        model.embed_query("termination notice"), SearchFilter(tenant_id="t1")
    )
    assert len(hits) == 1


# =====================================================================
# Deterministic encoder
# =====================================================================


@pytest.mark.parametrize("dimension", [8, 64, 128, 384, 768, 1024])
def test_deterministic_encoder_honours_its_width(dimension):
    model = DeterministicEmbedding(dimension=dimension)
    vectors = model.embed_documents(["clause one", "clause two"])

    assert model.dimension == dimension
    assert all(len(v) == dimension for v in vectors)


def test_deterministic_encoder_rejects_a_silly_width():
    with pytest.raises(ValueError):
        DeterministicEmbedding(dimension=2)


def test_deterministic_encoding_is_reproducible(embedder):
    text = "Either party may terminate on one hundred and twenty days notice."
    assert embedder.embed_query(text) == embedder.embed_query(text)


def test_two_instances_agree(embedder):
    """A restart must not invalidate an existing index."""
    other = DeterministicEmbedding(dimension=embedder.dimension)
    assert embedder.embed_query("termination") == other.embed_query("termination")


def test_empty_text_yields_a_zero_vector(embedder):
    vector = embedder.embed_query("")
    assert len(vector) == embedder.dimension
    assert all(v == 0.0 for v in vector)


def test_empty_input_list_returns_empty(embedder):
    assert embedder.embed_documents([]) == []


def test_normalized_vectors_are_unit_length():
    model = DeterministicEmbedding(dimension=64, normalize=True)
    vector = model.embed_query("termination of the agreement on notice")
    assert math.isclose(math.sqrt(sum(v * v for v in vector)), 1.0, abs_tol=1e-6)
    assert model.normalized is True


def test_normalization_can_be_disabled():
    model = DeterministicEmbedding(dimension=64, normalize=False)
    assert model.normalized is False
    vector = model.embed_query("termination of the agreement on notice")
    assert not math.isclose(math.sqrt(sum(v * v for v in vector)), 1.0, abs_tol=1e-6)


def test_related_text_scores_above_unrelated_text(embedder):
    """The lexical floor the deterministic encoder does guarantee."""

    def cosine(a, b):
        return sum(x * y for x, y in zip(a, b))

    anchor = embedder.embed_query(
        "either party may terminate this agreement on written notice"
    )
    similar = embedder.embed_query(
        "either party may terminate the agreement by written notice"
    )
    different = embedder.embed_query(
        "the fee schedule is set out in appendix seven"
    )
    assert cosine(anchor, similar) > cosine(anchor, different)


def test_word_order_has_some_effect(embedder):
    """Bigram hashing means these are not identical vectors."""
    a = embedder.embed_query("notice of termination")
    b = embedder.embed_query("termination of notice")
    assert a != b


# =====================================================================
# Batching
# =====================================================================


def test_batching_preserves_order_and_count(embedder):
    texts = [f"clause number {i} of the agreement" for i in range(37)]
    batched = embed_in_batches(embedder, texts, batch_size=8)
    single = embedder.embed_documents(texts)

    assert len(batched) == 37
    assert batched == single, "batching must not reorder or alter vectors"


@pytest.mark.parametrize("batch_size", [1, 3, 16, 100, 1000])
def test_batch_size_does_not_change_the_result(embedder, batch_size):
    texts = [f"clause {i}" for i in range(20)]
    assert embed_in_batches(embedder, texts, batch_size=batch_size) == (
        embedder.embed_documents(texts)
    )


def test_batching_on_empty_input(embedder):
    assert embed_in_batches(embedder, [], batch_size=8) == []


def test_batching_reports_progress(embedder):
    seen = []
    embed_in_batches(
        embedder,
        [f"c{i}" for i in range(10)],
        batch_size=4,
        on_progress=lambda done, total: seen.append((done, total)),
    )
    assert seen == [(4, 10), (8, 10), (10, 10)]


def test_batching_detects_a_miscounting_encoder(embedder):
    """A vector/text mismatch means every chunk gets the wrong vector."""

    class Broken(DeterministicEmbedding):
        def embed_documents(self, texts):
            return super().embed_documents(texts)[:-1]

    with pytest.raises(EmbeddingError):
        embed_in_batches(Broken(dimension=32), ["a", "b", "c"], batch_size=3)


def test_iter_batches_covers_everything():
    items = list(range(10))
    assert [b for b in iter_batches(items, 3)] == [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], [9]
    ]


def test_iter_batches_clamps_a_silly_size():
    assert list(iter_batches([1, 2, 3], 0)) == [[1], [2], [3]]


# =====================================================================
# Factory
# =====================================================================


def test_factory_selects_the_deterministic_provider(make_settings):
    model = build_embedding_model(
        make_settings(embedding_provider="deterministic",
                      deterministic_embedding_dim=96)
    )
    assert model.name == "deterministic"
    assert model.dimension == 96


def test_factory_falls_back_when_a_model_cannot_load(make_settings, monkeypatch):
    """Lenient mode: stay up, but the fallback must be loud."""
    module = types.ModuleType("sentence_transformers")
    module.SentenceTransformer = lambda *a, **k: (_ for _ in ()).throw(
        OSError("no network")
    )
    monkeypatch.setitem(sys.modules, "sentence_transformers", module)

    model = build_embedding_model(
        make_settings(
            embedding_provider="sentence_transformers",
            embedding_strict=False,
            deterministic_embedding_dim=77,
        )
    )
    assert model.name == "deterministic"
    assert model.dimension == 77


def test_strict_mode_makes_a_load_failure_fatal(make_settings, monkeypatch):
    """Production: serving meaningless vectors is worse than being down."""
    module = types.ModuleType("sentence_transformers")
    module.SentenceTransformer = lambda *a, **k: (_ for _ in ()).throw(
        OSError("no network")
    )
    monkeypatch.setitem(sys.modules, "sentence_transformers", module)

    with pytest.raises(EmbeddingError):
        build_embedding_model(
            make_settings(
                embedding_provider="sentence_transformers", embedding_strict=True
            )
        )


def test_the_model_is_a_singleton():
    set_embedding_model(None)
    try:
        assert get_embedding_model() is get_embedding_model()
    finally:
        set_embedding_model(None)


def test_a_model_can_be_injected():
    injected = DeterministicEmbedding(dimension=48)
    set_embedding_model(injected)
    try:
        assert get_embedding_model() is injected
        assert get_embedding_model().dimension == 48
    finally:
        set_embedding_model(None)


def test_describe_reports_the_contract(embedder):
    described = embedder.describe()
    assert described["dimension"] == embedder.dimension
    assert described["provider"] == "deterministic"
    assert "model" in described and "normalized" in described


def test_both_encoders_satisfy_the_interface(monkeypatch):
    install_stub(monkeypatch, _StubST(64))
    for model in (DeterministicEmbedding(dimension=64), _wrapper()("stub/model")):
        assert isinstance(model, EmbeddingModel)
        assert model.dimension == 64
        assert len(model.embed_query("x")) == 64
        assert len(model.embed_documents(["a", "b"])) == 2
