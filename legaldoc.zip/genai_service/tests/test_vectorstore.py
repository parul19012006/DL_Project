"""Vector store conformance.

Almost every test here takes the ``any_store`` fixture, which is
parametrised over **every registered backend**. That is deliberate: the
requirement is that ChromaDB can be swapped for Pinecone "without
rewriting the RAG pipeline", and this file is the executable definition
of what a backend has to do. A Pinecone adapter is correct when it
passes this file unchanged.

Tests that assert Chroma-specific behaviour (dimension recorded in
collection metadata, persistence across client restarts) take
``chroma_store`` directly and say why.
"""

from __future__ import annotations

import pytest

from app.models.chunk import Chunk
from app.models.document import DocumentType
from app.vectorstore.base import (
    DimensionMismatchError,
    SearchFilter,
    TenantScopeError,
    VectorStore,
)


# =====================================================================
# Corpus
# =====================================================================


def make_chunk(
    chunk_id: str,
    text: str,
    tenant_id: str = "tenant-a",
    document_id: str = "doc-1",
    page: int = 1,
    section: str = None,
    document_type: DocumentType = DocumentType.CONTRACT,
    index: int = 0,
    **extra,
) -> Chunk:
    return Chunk(
        chunk_id=chunk_id,
        chunk_index=index,
        text=text,
        document_id=document_id,
        tenant_id=tenant_id,
        filename=f"{document_id}.pdf",
        page_number=page,
        section=section,
        document_type=document_type,
        token_count=len(text.split()),
        extra=extra,
    )


CORPUS = [
    ("a1", "Either party may terminate this Agreement for convenience on one "
           "hundred and twenty days written notice.", "doc-1", 17, "4. TERMINATION"),
    ("a2", "The aggregate liability of either party shall not exceed the total "
           "fees paid in the preceding twelve months.", "doc-1", 21,
     "5. LIMITATION OF LIABILITY"),
    ("a3", "Confidential Information shall not be disclosed to third parties "
           "and the obligation survives termination for five years.", "doc-2", 4,
     "6. CONFIDENTIALITY"),
    ("a4", "Disputes shall be referred to arbitration seated in Bengaluru "
           "under the Arbitration and Conciliation Act.", "doc-2", 6,
     "8. ARBITRATION"),
]


@pytest.fixture
def seeded(any_store, embedder):
    """Two documents for tenant-a, one for tenant-b."""
    chunks = [
        make_chunk(cid, text, document_id=doc, page=page, section=section, index=i)
        for i, (cid, text, doc, page, section) in enumerate(CORPUS)
    ]
    chunks.append(
        make_chunk(
            "b1",
            "The buyer shall pay a break fee of two million dollars if it "
            "terminates the transaction before closing.",
            tenant_id="tenant-b",
            document_id="doc-b1",
            page=2,
            section="9. BREAK FEE",
            document_type=DocumentType.NDA,
        )
    )
    any_store.upsert(chunks, embedder.embed_documents([c.text for c in chunks]))
    return any_store


def query(embedder, text):
    return embedder.embed_query(text)


# =====================================================================
# Interface
# =====================================================================


def test_every_backend_implements_the_interface(any_store):
    assert isinstance(any_store, VectorStore)
    assert any_store.name
    assert any_store.dimension > 0


def test_registered_backends():
    from app.vectorstore.factory import available_backends

    assert "chroma" in available_backends()
    assert "memory" in available_backends()


def test_a_new_backend_can_be_registered(make_settings, embedder):
    """The extension point a Pinecone adapter would use."""
    from app.vectorstore.factory import (
        available_backends,
        build_vector_store,
        register_backend,
    )
    from app.vectorstore.memory import InMemoryVectorStore

    register_backend(
        "fake_pinecone",
        lambda settings, model: InMemoryVectorStore(dimension=model.dimension),
    )
    try:
        assert "fake_pinecone" in available_backends()
        store = build_vector_store(
            make_settings(vector_backend="fake_pinecone"), model=embedder
        )
        assert store.dimension == embedder.dimension
    finally:
        from app.vectorstore.factory import _BACKENDS

        _BACKENDS.pop("fake_pinecone", None)


def test_an_unknown_backend_is_rejected(make_settings, embedder):
    from app.vectorstore.base import VectorStoreError
    from app.vectorstore.factory import build_vector_store

    with pytest.raises(VectorStoreError):
        build_vector_store(
            make_settings(vector_backend="nope"), model=embedder
        )


def test_the_store_is_built_at_the_models_dimension(make_settings):
    """The factory couples the two — the store cannot be built without
    asking the model how wide its vectors are."""
    from app.embeddings.deterministic import DeterministicEmbedding
    from app.vectorstore.factory import build_vector_store

    for dimension in (64, 256, 1024):
        store = build_vector_store(
            make_settings(vector_backend="memory"),
            model=DeterministicEmbedding(dimension=dimension),
        )
        assert store.dimension == dimension


# =====================================================================
# Insertion
# =====================================================================


def test_insert_and_count(seeded):
    assert seeded.count() == 5
    assert seeded.count("tenant-a") == 4
    assert seeded.count("tenant-b") == 1


def test_insert_an_empty_list_is_a_noop(any_store):
    assert any_store.upsert([], []) == 0
    assert any_store.count() == 0


def test_insert_returns_the_number_stored(any_store, embedder):
    chunks = [make_chunk(f"c{i}", f"clause number {i}", index=i) for i in range(5)]
    stored = any_store.upsert(
        chunks, embedder.embed_documents([c.text for c in chunks])
    )
    assert stored == 5


def test_mismatched_vector_count_is_rejected(any_store, embedder):
    from app.vectorstore.base import VectorStoreError

    chunks = [make_chunk("c1", "one"), make_chunk("c2", "two")]
    with pytest.raises(VectorStoreError):
        any_store.upsert(chunks, embedder.embed_documents(["one"]))


def test_a_wrong_width_vector_is_rejected(any_store):
    """A vector from another model must never enter the index."""
    with pytest.raises(DimensionMismatchError):
        any_store.upsert([make_chunk("c1", "text")], [[0.1, 0.2, 0.3]])


def test_a_large_insert_succeeds(any_store, embedder):
    """Exercises the internal batching path."""
    chunks = [
        make_chunk(f"c{i}", f"clause number {i} of the agreement", index=i)
        for i in range(250)
    ]
    stored = any_store.upsert(
        chunks, embedder.embed_documents([c.text for c in chunks])
    )
    assert stored == 250
    assert any_store.count() == 250


def test_metadata_round_trips(seeded, embedder):
    hits = seeded.search(
        query(embedder, "terminate for convenience"),
        SearchFilter(tenant_id="tenant-a"),
        top_k=10,
    )
    hit = next(h for h in hits if h.chunk.chunk_id == "a1")
    chunk = hit.chunk

    assert chunk.document_id == "doc-1"
    assert chunk.tenant_id == "tenant-a"
    assert chunk.filename == "doc-1.pdf"
    assert chunk.page_number == 17
    assert chunk.section == "4. TERMINATION"
    assert chunk.document_type is DocumentType.CONTRACT
    assert "one hundred and twenty" in chunk.text


def test_extra_metadata_round_trips(any_store, embedder):
    chunk = make_chunk("c1", "a clause", matter_id="M-77", billable=True)
    any_store.upsert([chunk], embedder.embed_documents([chunk.text]))

    fetched = any_store.fetch(SearchFilter(tenant_id="tenant-a"))[0]
    assert fetched.extra.get("matter_id") == "M-77"
    assert fetched.extra.get("billable") is True


# =====================================================================
# Duplicate handling
# =====================================================================


def test_reinserting_the_same_chunk_does_not_duplicate(any_store, embedder):
    """Stable ids make re-indexing idempotent."""
    chunk = make_chunk("c1", "Either party may terminate on notice.")
    vector = embedder.embed_documents([chunk.text])

    any_store.upsert([chunk], vector)
    any_store.upsert([chunk], vector)
    any_store.upsert([chunk], vector)

    assert any_store.count() == 1


def test_upsert_replaces_the_text_of_an_existing_id(any_store, embedder):
    original = make_chunk("c1", "The original clause text.")
    any_store.upsert([original], embedder.embed_documents([original.text]))

    updated = make_chunk("c1", "The amended clause text.")
    any_store.upsert([updated], embedder.embed_documents([updated.text]))

    assert any_store.count() == 1
    assert any_store.fetch(SearchFilter(tenant_id="tenant-a"))[0].text == (
        "The amended clause text."
    )


def test_duplicate_ids_within_one_batch_collapse(any_store, embedder):
    """The same id twice in one call is still one row."""
    chunks = [make_chunk("c1", "first version"), make_chunk("c1", "second version")]
    any_store.upsert(chunks, embedder.embed_documents([c.text for c in chunks]))
    assert any_store.count() == 1


def test_identical_text_under_different_ids_is_kept(any_store, embedder):
    """Boilerplate repeated across documents is not a duplicate."""
    text = "This clause is repeated verbatim in both schedules."
    chunks = [
        make_chunk("c1", text, document_id="doc-1"),
        make_chunk("c2", text, document_id="doc-2"),
    ]
    any_store.upsert(chunks, embedder.embed_documents([c.text for c in chunks]))
    assert any_store.count() == 2


def test_reindexing_a_document_is_idempotent(any_store, embedder):
    chunks = [make_chunk(f"c{i}", f"clause {i}", index=i) for i in range(4)]
    vectors = embedder.embed_documents([c.text for c in chunks])

    for _ in range(3):
        any_store.upsert(chunks, vectors)

    assert any_store.count() == 4
    assert any_store.document_chunk_count("doc-1", "tenant-a") == 4


# =====================================================================
# Similarity search
# =====================================================================


def test_search_returns_hits_ordered_best_first(seeded, embedder):
    hits = seeded.search(
        query(embedder, "arbitration seated in Bengaluru"),
        SearchFilter(tenant_id="tenant-a"),
        top_k=4,
    )
    assert hits
    scores = [h.score for h in hits]
    assert scores == sorted(scores, reverse=True)
    assert [h.rank for h in hits] == list(range(1, len(hits) + 1))


def test_search_finds_the_relevant_chunk(seeded, embedder):
    hits = seeded.search(
        query(embedder, "arbitration seated in Bengaluru"),
        SearchFilter(tenant_id="tenant-a"),
        top_k=2,
    )
    assert hits[0].chunk.chunk_id == "a4"


def test_scores_are_higher_is_better_and_bounded(seeded, embedder):
    hits = seeded.search(
        query(embedder, "termination notice"),
        SearchFilter(tenant_id="tenant-a"),
        top_k=4,
    )
    for hit in hits:
        assert 0.0 <= hit.score <= 1.0


def test_an_exact_text_match_scores_near_one(any_store, embedder):
    text = "Either party may terminate this Agreement on ninety days notice."
    chunk = make_chunk("c1", text)
    any_store.upsert([chunk], embedder.embed_documents([text]))

    hits = any_store.search(
        query(embedder, text), SearchFilter(tenant_id="tenant-a"), top_k=1
    )
    assert hits[0].score > 0.95


def test_top_k_limits_the_result_size(seeded, embedder):
    for k in (1, 2, 3):
        hits = seeded.search(
            query(embedder, "termination"), SearchFilter(tenant_id="tenant-a"),
            top_k=k,
        )
        assert len(hits) <= k


def test_search_on_an_empty_store(any_store, embedder):
    assert any_store.search(
        query(embedder, "anything"), SearchFilter(tenant_id="tenant-a")
    ) == []


def test_a_wrong_width_query_vector_is_rejected(seeded):
    with pytest.raises(DimensionMismatchError):
        seeded.search([0.1, 0.2], SearchFilter(tenant_id="tenant-a"))


def test_search_returns_real_chunk_objects(seeded, embedder):
    hits = seeded.search(
        query(embedder, "termination"), SearchFilter(tenant_id="tenant-a"), top_k=1
    )
    assert isinstance(hits[0].chunk, Chunk)
    assert hits[0].chunk.citation()["chunk_id"] == hits[0].chunk_id


# =====================================================================
# Metadata filtering
# =====================================================================


def test_filter_by_document_id(seeded, embedder):
    hits = seeded.search(
        query(embedder, "termination"),
        SearchFilter(tenant_id="tenant-a", document_ids=["doc-2"]),
        top_k=10,
    )
    assert hits
    assert all(h.chunk.document_id == "doc-2" for h in hits)


def test_filter_by_several_document_ids(seeded, embedder):
    hits = seeded.search(
        query(embedder, "termination"),
        SearchFilter(tenant_id="tenant-a", document_ids=["doc-1", "doc-2"]),
        top_k=10,
    )
    assert {h.chunk.document_id for h in hits} <= {"doc-1", "doc-2"}


def test_filter_by_document_type(seeded, embedder):
    hits = seeded.search(
        query(embedder, "termination"),
        SearchFilter(tenant_id="tenant-a", document_type="contract"),
        top_k=10,
    )
    assert hits
    assert all(h.chunk.document_type is DocumentType.CONTRACT for h in hits)


def test_filter_by_section(seeded, embedder):
    hits = seeded.search(
        query(embedder, "anything at all"),
        SearchFilter(tenant_id="tenant-a", section="4. TERMINATION"),
        top_k=10,
    )
    assert hits
    assert all(h.chunk.section == "4. TERMINATION" for h in hits)


def test_filter_by_page_range(seeded, embedder):
    hits = seeded.search(
        query(embedder, "termination"),
        SearchFilter(tenant_id="tenant-a", page_range=(1, 10)),
        top_k=10,
    )
    assert hits
    assert all(1 <= h.chunk.page_number <= 10 for h in hits)


def test_page_range_is_normalised_when_reversed():
    assert SearchFilter(tenant_id="t", page_range=(20, 5)).page_range == (5, 20)


def test_filter_by_extra_metadata(any_store, embedder):
    chunks = [
        make_chunk("c1", "clause for matter 77", matter_id="M-77"),
        make_chunk("c2", "clause for matter 88", matter_id="M-88"),
    ]
    any_store.upsert(chunks, embedder.embed_documents([c.text for c in chunks]))

    hits = any_store.search(
        query(embedder, "clause"),
        SearchFilter(tenant_id="tenant-a", equals={"matter_id": "M-77"}),
        top_k=10,
    )
    assert [h.chunk.chunk_id for h in hits] == ["c1"]


def test_filters_combine(seeded, embedder):
    hits = seeded.search(
        query(embedder, "termination"),
        SearchFilter(
            tenant_id="tenant-a",
            document_ids=["doc-1"],
            document_type="contract",
            page_range=(15, 20),
        ),
        top_k=10,
    )
    assert [h.chunk.chunk_id for h in hits] == ["a1"]


def test_a_filter_matching_nothing_returns_nothing(seeded, embedder):
    assert seeded.search(
        query(embedder, "termination"),
        SearchFilter(tenant_id="tenant-a", document_ids=["doc-does-not-exist"]),
        top_k=10,
    ) == []


def test_non_scalar_extra_filters_are_dropped():
    """Vector stores accept scalar metadata only."""
    filters = SearchFilter(
        tenant_id="t", equals={"good": "x", "bad": {"nested": 1}, "worse": [1, 2]}
    )
    assert filters.equals == {"good": "x"}


def test_fetch_applies_the_same_filters(seeded):
    chunks = seeded.fetch(
        SearchFilter(tenant_id="tenant-a", document_ids=["doc-1"])
    )
    assert len(chunks) == 2
    assert all(c.document_id == "doc-1" for c in chunks)


def test_fetch_is_ordered_and_limitable(seeded):
    chunks = seeded.fetch(SearchFilter(tenant_id="tenant-a"))
    assert [c.chunk_index for c in chunks] == sorted(c.chunk_index for c in chunks)
    assert len(seeded.fetch(SearchFilter(tenant_id="tenant-a"), limit=2)) == 2


# =====================================================================
# Tenant isolation
# =====================================================================


def test_a_filter_cannot_be_built_without_a_tenant():
    """Unscoped retrieval is unrepresentable, not merely discouraged."""
    for bad in ("", "   ", None):
        with pytest.raises(TenantScopeError):
            SearchFilter(tenant_id=bad)


def test_tenant_id_is_always_the_first_clause():
    clauses = SearchFilter(tenant_id="t1", document_type="contract").to_clauses()
    assert clauses[0] == {"field": "tenant_id", "op": "eq", "value": "t1"}


def test_search_never_returns_another_tenants_chunks(seeded, embedder):
    """The query is aimed squarely at tenant-b's content."""
    hits = seeded.search(
        query(embedder, "break fee of two million dollars before closing"),
        SearchFilter(tenant_id="tenant-a"),
        top_k=10,
    )
    assert hits, "tenant-a should still match its own termination clause"
    assert all(h.chunk.tenant_id == "tenant-a" for h in hits)
    assert all("break fee" not in h.chunk.text.lower() for h in hits)


def test_each_tenant_sees_only_its_own(seeded, embedder):
    a = seeded.search(
        query(embedder, "termination"), SearchFilter(tenant_id="tenant-a"), top_k=10
    )
    b = seeded.search(
        query(embedder, "termination"), SearchFilter(tenant_id="tenant-b"), top_k=10
    )

    assert {h.chunk.tenant_id for h in a} == {"tenant-a"}
    assert {h.chunk.tenant_id for h in b} == {"tenant-b"}
    assert not ({h.chunk_id for h in a} & {h.chunk_id for h in b})


def test_an_unknown_tenant_sees_nothing(seeded, embedder):
    assert seeded.search(
        query(embedder, "termination"),
        SearchFilter(tenant_id="tenant-ghost"),
        top_k=10,
    ) == []


def test_fetch_is_tenant_scoped(seeded):
    assert all(
        c.tenant_id == "tenant-a"
        for c in seeded.fetch(SearchFilter(tenant_id="tenant-a"))
    )
    assert len(seeded.fetch(SearchFilter(tenant_id="tenant-b"))) == 1


def test_counts_are_tenant_scoped(seeded):
    assert seeded.count("tenant-a") == 4
    assert seeded.count("tenant-b") == 1
    assert seeded.count("tenant-ghost") == 0


def test_document_chunk_count_is_tenant_scoped(seeded):
    assert seeded.document_chunk_count("doc-1", "tenant-a") == 2
    assert seeded.document_chunk_count("doc-1", "tenant-b") == 0


def test_the_same_document_id_under_two_tenants_stays_separate(
    any_store, embedder
):
    """Backends may reuse document ids across tenants."""
    chunks = [
        make_chunk("x-a", "tenant a version", tenant_id="tenant-a",
                   document_id="shared-id"),
        make_chunk("x-b", "tenant b version", tenant_id="tenant-b",
                   document_id="shared-id"),
    ]
    any_store.upsert(chunks, embedder.embed_documents([c.text for c in chunks]))

    assert any_store.document_chunk_count("shared-id", "tenant-a") == 1
    assert any_store.document_chunk_count("shared-id", "tenant-b") == 1

    any_store.delete_document("shared-id", "tenant-a")
    assert any_store.document_chunk_count("shared-id", "tenant-a") == 0
    assert any_store.document_chunk_count("shared-id", "tenant-b") == 1


# =====================================================================
# Deletion
# =====================================================================


def test_delete_document_removes_only_that_document(seeded):
    removed = seeded.delete_document("doc-1", "tenant-a")

    assert removed == 2
    assert seeded.count("tenant-a") == 2
    assert seeded.count("tenant-b") == 1
    assert seeded.document_chunk_count("doc-1", "tenant-a") == 0


def test_deleted_chunks_stop_being_retrievable(seeded, embedder):
    seeded.delete_document("doc-1", "tenant-a")
    hits = seeded.search(
        query(embedder, "terminate for convenience on one hundred and twenty days"),
        SearchFilter(tenant_id="tenant-a"),
        top_k=10,
    )
    assert all(h.chunk.document_id != "doc-1" for h in hits)


def test_delete_document_cannot_cross_tenants(seeded):
    """The most important deletion test in a multi-tenant product."""
    assert seeded.delete_document("doc-b1", "tenant-a") == 0
    assert seeded.count("tenant-b") == 1


def test_deleting_an_unknown_document_is_a_noop(seeded):
    assert seeded.delete_document("no-such-doc", "tenant-a") == 0
    assert seeded.count() == 5


def test_delete_tenant_removes_everything_it_owns(seeded):
    removed = seeded.delete_tenant("tenant-a")

    assert removed == 4
    assert seeded.count("tenant-a") == 0
    assert seeded.count("tenant-b") == 1


def test_delete_tenant_leaves_other_tenants_intact(seeded):
    seeded.delete_tenant("tenant-b")
    assert seeded.count("tenant-a") == 4


def test_a_document_can_be_reindexed_after_deletion(seeded, embedder):
    seeded.delete_document("doc-1", "tenant-a")
    chunks = [
        make_chunk("a1", "The amended termination clause.", document_id="doc-1")
    ]
    seeded.upsert(chunks, embedder.embed_documents([c.text for c in chunks]))

    assert seeded.document_chunk_count("doc-1", "tenant-a") == 1


def test_reset_empties_the_store(seeded):
    seeded.reset()
    assert seeded.count() == 0


# =====================================================================
# Chroma specifics
# =====================================================================


def test_chroma_records_its_dimension_and_model(chroma_store, embedder):
    """So a later mismatch can be reported clearly instead of opaquely."""
    from app.vectorstore.chroma import DIMENSION_KEY, MODEL_KEY

    metadata = chroma_store._get_collection().metadata or {}
    assert int(metadata[DIMENSION_KEY]) == embedder.dimension
    assert metadata[MODEL_KEY] == embedder.model_id


def test_chroma_refuses_a_collection_built_at_another_dimension(
    chroma_store, tmp_path
):
    """Changing the embedding model must not silently corrupt an index."""
    from app.vectorstore.chroma import ChromaVectorStore

    other = ChromaVectorStore(
        persist_directory=chroma_store.persist_directory,
        collection_name=chroma_store.collection_name,
        dimension=chroma_store.dimension + 256,
        embedding_model_id="some/other-model",
    )
    with pytest.raises(DimensionMismatchError) as excinfo:
        other.ensure_ready()

    message = str(excinfo.value)
    assert "re-index" in message.lower()


def test_chroma_persists_across_client_instances(chroma_store, embedder):
    """The whole reason to use Chroma over the in-memory store."""
    from app.vectorstore.chroma import ChromaVectorStore

    chunk = make_chunk("c1", "A persisted clause about termination.")
    chroma_store.upsert([chunk], embedder.embed_documents([chunk.text]))

    reopened = ChromaVectorStore(
        persist_directory=chroma_store.persist_directory,
        collection_name=chroma_store.collection_name,
        dimension=embedder.dimension,
        embedding_model_id=embedder.model_id,
    )
    reopened.ensure_ready()

    assert reopened.count() == 1
    assert reopened.fetch(SearchFilter(tenant_id="tenant-a"))[0].text == chunk.text


def test_chroma_translates_filters_into_its_own_dialect(chroma_store):
    """The pipeline never sees this syntax — that is the point."""
    where = chroma_store._where(
        SearchFilter(tenant_id="t1", document_ids=["d1", "d2"])
    )
    assert "$and" in where
    assert {"tenant_id": {"$eq": "t1"}} in where["$and"]
    assert {"document_id": {"$in": ["d1", "d2"]}} in where["$and"]


def test_chroma_single_clause_needs_no_and(chroma_store):
    assert chroma_store._where(SearchFilter(tenant_id="t1")) == {
        "tenant_id": {"$eq": "t1"}
    }


def test_memory_store_applies_the_same_clauses(memory_store):
    """Both backends consume the identical portable clause list."""
    from app.vectorstore.memory import InMemoryVectorStore

    metadata = {"tenant_id": "t1", "document_id": "d1", "page_number": 5}
    assert InMemoryVectorStore._matches(
        metadata, SearchFilter(tenant_id="t1", page_range=(1, 10))
    )
    assert not InMemoryVectorStore._matches(
        metadata, SearchFilter(tenant_id="t2")
    )
    assert not InMemoryVectorStore._matches(
        metadata, SearchFilter(tenant_id="t1", page_range=(6, 10))
    )


# =====================================================================
# Stats
# =====================================================================


def test_stats_describe_the_store(seeded, embedder):
    stats = seeded.stats()
    assert stats.backend in {"chroma", "memory"}
    assert stats.dimension == embedder.dimension
    assert stats.total_chunks == 5
    assert stats.metric == "cosine"
    assert stats.embedding_model == embedder.model_id
