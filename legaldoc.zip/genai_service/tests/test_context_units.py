"""Stage 6 — the context builder's parts, tested separately.

Selection, ordering, budgeting and rendering are four independent
decisions. Testing them through the builder only would mean every
failure points at the same place; testing them directly is what makes
"independently testable" (requirement 10) true rather than claimed.
"""

from __future__ import annotations

import pytest

from app.chunking.tokenizer import HeuristicTokenCounter
from app.context.base import (
    UNKNOWN,
    UNKNOWN_PAGE,
    ContextError,
    ContextSource,
    OmissionReason,
    to_candidates,
)
from app.context.budget import (
    fit_to_budget,
    strip_repeated_heading,
    truncate_at_sentence,
)
from app.context.formatter import SEPARATOR, render, render_source
from app.context.ordering import DOCUMENT, RELEVANCE, order_sources
from app.context.selection import remove_redundant, select_evidence
from app.models.chunk import Chunk, make_chunk_id
from app.models.document import DocumentType
from app.retrieval.base import Candidate

COUNTER = HeuristicTokenCounter()

CLAUSE = (
    "Either party may terminate this Agreement for convenience on one "
    "hundred and twenty (120) days written notice to the other party. "
    "Either party may terminate immediately by written notice if the other "
    "party commits a material breach which is not remedied within thirty "
    "(30) days."
)


def _chunk(
    text: str = CLAUSE,
    index: int = 0,
    document_id: str = "doc-1",
    section: str = "4. TERMINATION",
    page: int = 1,
    filename: str = "contract.pdf",
    **kwargs,
) -> Chunk:
    return Chunk(
        chunk_id=make_chunk_id(document_id, index, text),
        chunk_index=index,
        text=text,
        document_id=document_id,
        tenant_id="tenant-a",
        filename=filename,
        page_number=page,
        document_type=DocumentType.CONTRACT,
        section=section,
        token_count=len(text.split()),
        **kwargs,
    )


def _candidate(score: float = 1.0, **kwargs) -> Candidate:
    candidate = Candidate.from_chunk(_chunk(**kwargs))
    candidate.final_score = score
    return candidate


# =====================================================================
# Input handling
# =====================================================================


def test_bare_chunks_are_accepted_as_input():
    """The builder must not require a retrieval outcome to be usable."""
    candidates = to_candidates([_chunk(), _chunk(index=1)])
    assert len(candidates) == 2
    assert all(isinstance(c, Candidate) for c in candidates)


def test_candidates_pass_through_unchanged():
    original = _candidate(score=0.7)
    assert to_candidates([original])[0] is original


def test_anything_else_is_rejected_clearly():
    with pytest.raises(ContextError):
        to_candidates(["just a string"])


# =====================================================================
# Selection
# =====================================================================


def test_selection_works_strongest_first():
    weak = _candidate(score=0.1, index=1, text="weak passage about nothing")
    strong = _candidate(score=0.9, index=2, text="strong passage about notice")
    selected, _ = select_evidence([weak, strong], max_sources=1)
    assert len(selected) == 1
    assert selected[0].final_score == pytest.approx(0.9)


def test_the_source_cap_records_what_it_dropped():
    candidates = [
        _candidate(score=1.0 - i / 10, index=i, text=f"passage number {i} here")
        for i in range(6)
    ]
    selected, omitted = select_evidence(candidates, max_sources=3)
    assert len(selected) == 3
    assert len(omitted) == 3
    assert all(o.reason == OmissionReason.MAX_SOURCES for o in omitted)
    assert all(o.citation for o in omitted)


def test_the_score_floor_records_what_it_dropped():
    candidates = [
        _candidate(score=0.9, index=1, text="a strong passage"),
        _candidate(score=0.1, index=2, text="a weak passage"),
    ]
    selected, omitted = select_evidence(candidates, min_score=0.5)
    assert len(selected) == 1
    assert omitted[0].reason == OmissionReason.BELOW_SCORE_FLOOR


def test_the_score_floor_is_off_by_default():
    candidates = [_candidate(score=0.0, index=1, text="a zero-scoring passage")]
    selected, _ = select_evidence(candidates)
    assert len(selected) == 1


def test_empty_passages_are_dropped_with_a_reason():
    """They cost header tokens and carry nothing."""
    selected, omitted = select_evidence(
        [_candidate(text="   ", index=1), _candidate(index=2)]
    )
    assert len(selected) == 1
    assert any(o.reason == OmissionReason.EMPTY_TEXT for o in omitted)


def test_selection_is_deterministic_for_equal_scores():
    candidates = [
        _candidate(score=0.5, index=i, text=f"passage {i} of the agreement")
        for i in range(5)
    ]
    first, _ = select_evidence(list(candidates), max_sources=2)
    second, _ = select_evidence(list(reversed(candidates)), max_sources=2)
    assert [c.chunk_id for c in first] == [c.chunk_id for c in second]


# =====================================================================
# Redundancy
# =====================================================================


def test_identical_passages_in_two_documents_collapse():
    kept, omitted = remove_redundant(
        [
            _candidate(document_id="doc-1", index=3),
            _candidate(document_id="doc-2", index=7),
        ]
    )
    assert len(kept) == 1
    assert omitted[0].reason == OmissionReason.REDUNDANT
    assert omitted[0].duplicate_of == kept[0].chunk_id


def test_the_collapsed_passage_keeps_its_citation():
    """Requirement 9: a dropped passage is never dropped silently."""
    _, omitted = remove_redundant(
        [
            _candidate(document_id="doc-1", filename="a.pdf"),
            _candidate(document_id="doc-2", filename="b.pdf"),
        ]
    )
    assert omitted[0].citation["filename"] == "b.pdf"
    assert omitted[0].citation["document_id"] == "doc-2"


def test_adjacent_chunks_of_one_document_are_not_collapsed():
    """Stage 3's overlap is deliberate and must survive."""
    first = _candidate(index=3, text=CLAUSE)
    second = _candidate(
        index=4,
        text=(
            "which is not remedied within thirty (30) days. On termination "
            "the Vendor shall return all Client data within fifteen (15) days."
        ),
    )
    kept, omitted = remove_redundant([first, second])
    assert len(kept) == 2
    assert omitted == []


def test_different_clauses_are_not_redundant():
    kept, _ = remove_redundant(
        [
            _candidate(index=1, text=CLAUSE),
            _candidate(
                index=5,
                text="The aggregate liability of either party shall not exceed the fees paid.",
            ),
        ]
    )
    assert len(kept) == 2


# =====================================================================
# Ordering
# =====================================================================


def test_document_order_groups_by_document_then_reading_order():
    candidates = [
        _candidate(score=0.5, document_id="doc-b", index=2, text="b two"),
        _candidate(score=0.9, document_id="doc-a", index=5, text="a five"),
        _candidate(score=0.4, document_id="doc-b", index=1, text="b one"),
        _candidate(score=0.8, document_id="doc-a", index=2, text="a two"),
    ]
    ordered = order_sources(candidates, DOCUMENT)
    assert [(c.chunk.document_id, c.chunk.chunk_index) for c in ordered] == [
        ("doc-a", 2),
        ("doc-a", 5),
        ("doc-b", 1),
        ("doc-b", 2),
    ]


def test_the_strongest_document_comes_first():
    candidates = [
        _candidate(score=0.2, document_id="doc-weak", index=0, text="weak one"),
        _candidate(score=0.95, document_id="doc-strong", index=0, text="strong one"),
    ]
    ordered = order_sources(candidates, DOCUMENT)
    assert ordered[0].chunk.document_id == "doc-strong"


def test_relevance_order_ignores_documents():
    candidates = [
        _candidate(score=0.5, document_id="doc-a", index=1, text="a one"),
        _candidate(score=0.9, document_id="doc-b", index=1, text="b one"),
        _candidate(score=0.7, document_id="doc-a", index=2, text="a two"),
    ]
    ordered = order_sources(candidates, RELEVANCE)
    assert [round(c.final_score, 2) for c in ordered] == [0.9, 0.7, 0.5]


def test_ordering_is_deterministic():
    candidates = [
        _candidate(score=0.5, document_id="doc-a", index=i, text=f"passage {i}")
        for i in range(4)
    ]
    assert [c.chunk_id for c in order_sources(list(candidates), DOCUMENT)] == [
        c.chunk_id for c in order_sources(list(reversed(candidates)), DOCUMENT)
    ]


def test_an_unknown_order_is_rejected_with_the_options():
    with pytest.raises(ContextError) as excinfo:
        order_sources([], "alphabetical")
    assert "document" in str(excinfo.value)


def test_ordering_an_empty_list_is_empty():
    assert order_sources([], DOCUMENT) == []


# =====================================================================
# Heading stripping
# =====================================================================


def test_a_repeated_heading_is_removed_from_the_body():
    text = "4. TERMINATION\n\nEither party may terminate on notice."
    body, stripped = strip_repeated_heading(text, "4. TERMINATION")
    assert stripped
    assert body == "Either party may terminate on notice."


def test_a_heading_only_chunk_keeps_its_text():
    """Stripping would leave a source with no body at all."""
    body, stripped = strip_repeated_heading("4. TERMINATION", "4. TERMINATION")
    assert not stripped
    assert body == "4. TERMINATION"


def test_a_body_that_does_not_start_with_the_heading_is_untouched():
    text = "Either party may terminate under Clause 4."
    body, stripped = strip_repeated_heading(text, "4. TERMINATION")
    assert not stripped
    assert body == text


def test_no_section_means_nothing_to_strip():
    assert strip_repeated_heading(CLAUSE, None) == (CLAUSE, False)


# =====================================================================
# Truncation
# =====================================================================


#: Several short sentences, so dropping the last one costs little and
#: the sentence boundary is worth keeping.
MANY_SENTENCES = (
    "The Vendor shall invoice monthly. The Client shall pay within thirty "
    "days. Late payment accrues interest. Interest is charged at one and a "
    "half percent per month. All fees exclude tax. Disputed sums are held "
    "in escrow."
)


def test_truncation_prefers_a_sentence_boundary():
    """Cutting mid-sentence produces text that reads as finished when it
    is not — the model cannot know the qualifier was in the next line."""
    budget = COUNTER.count(MANY_SENTENCES) - 6
    shortened = truncate_at_sentence(MANY_SENTENCES, budget, COUNTER)
    assert shortened != MANY_SENTENCES
    assert shortened.endswith(".")
    assert COUNTER.count(shortened) <= budget


def test_a_costly_sentence_boundary_is_given_up_to_keep_the_clause():
    """Alignment is worth having only while it is cheap.

    The fixture's termination clause sentence-aligns to 38 tokens of a
    60-token allowance — a 37% loss, and enough to push the passage below
    the "meaningful" floor and have it dropped entirely. Filling the
    budget on a word boundary keeps the clause; the block declares the
    truncation either way.
    """
    clause = CLAUSE
    aligned_only = " ".join(clause.split(". ")[:1]) + "."
    assert COUNTER.count(aligned_only) < 60 * 0.75

    shortened = truncate_at_sentence(clause, 60, COUNTER)
    assert COUNTER.count(shortened) > COUNTER.count(aligned_only)
    assert COUNTER.count(shortened) <= 60


def test_a_budget_below_the_first_sentence_still_returns_text():
    """Falls back to a word boundary rather than returning nothing."""
    first_sentence_cost = COUNTER.count(CLAUSE.split(". ")[0])
    shortened = truncate_at_sentence(CLAUSE, first_sentence_cost - 5, COUNTER)
    assert shortened
    assert COUNTER.count(shortened) <= first_sentence_cost - 5


def test_text_within_budget_is_returned_whole():
    assert truncate_at_sentence(CLAUSE, 10_000, COUNTER) == CLAUSE


def test_a_single_oversized_sentence_falls_back_to_words():
    """Legal drafting produces 300-word sentences; this is a normal path."""
    sentence = " ".join(["the vendor shall indemnify the client"] * 60)
    shortened = truncate_at_sentence(sentence, 40, COUNTER)
    assert shortened
    assert COUNTER.count(shortened) <= 40


def test_a_zero_budget_truncates_to_nothing():
    assert truncate_at_sentence(CLAUSE, 0, COUNTER) == ""


# =====================================================================
# Budget fitting
# =====================================================================


def test_the_header_is_charged_to_the_budget():
    """Counting only the passage text under-counts by ~50 tokens a source."""
    sources, _ = fit_to_budget(
        [_candidate()], counter=COUNTER, max_tokens=10_000
    )
    source = sources[0]
    assert source.total_tokens > source.text_tokens
    rendered = COUNTER.count(render_source(source))
    assert source.total_tokens == rendered


def test_a_passage_that_does_not_fit_is_shortened_and_flagged():
    sources, _ = fit_to_budget(
        [_candidate()], counter=COUNTER, max_tokens=120, min_source_tokens=10
    )
    assert sources[0].truncated
    assert sources[0].omitted_tokens > 0
    assert COUNTER.count(render(sources)) <= 120


def test_a_passage_too_small_to_be_meaningful_is_dropped_not_shortened():
    """Half a clause is worse input than no clause."""
    sources, omitted = fit_to_budget(
        [_candidate()], counter=COUNTER, max_tokens=80, min_source_tokens=200
    )
    assert sources == []
    assert omitted[0].reason in (
        OmissionReason.TOO_SMALL_TO_TRUNCATE,
        OmissionReason.BUDGET_EXHAUSTED,
    )
    assert omitted[0].citation


def test_truncation_can_be_switched_off():
    sources, omitted = fit_to_budget(
        [_candidate()], counter=COUNTER, max_tokens=100, truncate=False
    )
    assert sources == []
    assert omitted[0].reason == OmissionReason.BUDGET_EXHAUSTED


def test_the_per_source_cap_is_independent_of_the_budget():
    """One long schedule must not eat the space five clauses would use."""
    sources, _ = fit_to_budget(
        [_candidate()],
        counter=COUNTER,
        max_tokens=10_000,
        max_source_tokens=40,
        min_source_tokens=10,
    )
    assert sources[0].text_tokens <= 40
    assert sources[0].truncated


def test_the_strongest_passage_gets_first_call_on_the_budget():
    strong = _candidate(score=0.9, index=1, text=CLAUSE)
    weak = _candidate(score=0.1, index=2, text=CLAUSE.replace("terminate", "assign"))
    sources, omitted = fit_to_budget(
        [strong, weak], counter=COUNTER, max_tokens=160, min_source_tokens=20
    )
    assert len(sources) == 1
    assert sources[0].chunk_id == strong.chunk_id


# =====================================================================
# Rendering
# =====================================================================


def _rendered(**kwargs) -> str:
    sources, _ = fit_to_budget(
        [_candidate(**kwargs)], counter=COUNTER, max_tokens=10_000
    )
    sources[0].number = 1
    return render_source(sources[0])


def test_the_block_has_every_required_label():
    block = _rendered()
    for label in ("Source 1:", "Document:", "Page:", "Section:", "Chunk:", "Text:"):
        assert label in block


def test_the_labels_appear_in_the_documented_order():
    block = _rendered()
    positions = [
        block.index(label)
        for label in ("Source 1:", "Document:", "Page:", "Section:", "Chunk:", "Text:")
    ]
    assert positions == sorted(positions)


def test_missing_metadata_renders_an_explicit_marker():
    """Never a blank line — a model reads that as 'no section', not 'unknown'."""
    block = _rendered(section=None, page=0, filename="")
    assert f"Section: {UNKNOWN}" in block
    assert f"Page: {UNKNOWN_PAGE}" in block
    assert f"Document: {UNKNOWN}" in block


def test_a_page_span_renders_as_a_range():
    sources, _ = fit_to_budget(
        [Candidate.from_chunk(_chunk(page=7, page_end=9))],
        counter=COUNTER,
        max_tokens=10_000,
    )
    sources[0].number = 1
    assert "Page: 7-9" in render_source(sources[0])


def test_an_ocr_source_says_so():
    block = _rendered(ocr=True)
    assert "OCR" in block


def test_sources_are_separated_unambiguously():
    sources, _ = fit_to_budget(
        [_candidate(index=1, text="first passage"), _candidate(index=9, text="second passage")],
        counter=COUNTER,
        max_tokens=10_000,
    )
    for position, source in enumerate(sources, start=1):
        source.number = position
    block = render(sources)
    assert SEPARATOR in block
    assert block.count("Source ") == 2


def test_rendering_nothing_is_an_empty_string():
    assert render([]) == ""


def test_an_empty_source_list_does_not_crash_the_header_renderer():
    source = ContextSource(chunk=_chunk(), number=1, text="")
    assert "Text:" in render_source(source)
