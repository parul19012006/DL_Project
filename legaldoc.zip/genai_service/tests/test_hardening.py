"""Stage 9 — the hardening, one section per evaluation point.

Each section states the failure it prevents. Most of these are cheap
tests for expensive problems: a document silently vanishing from the
index, a corpus re-embedded for nothing, a stale cache citing a deleted
contract, a temp file that outlives the process that made it.
"""

from __future__ import annotations

import time

import pytest

from app.ingestion.errors import IndexingError
from app.retrieval.keyword import BM25Cache, BM25Index, KeywordRetriever
from app.retrieval.query import preprocess_query
from app.services import indexing
from app.vectorstore.base import SearchFilter, VectorStoreError
from tests import fixtures

TENANT = "tenant-a"


@pytest.fixture
def pipeline(settings, embedder, memory_store):
    return {"settings": settings, "model": embedder, "store": memory_store}


def _index(path, pipeline, **kwargs):
    defaults = dict(document_id="doc-1", tenant_id=TENANT, file_path=path.name)
    defaults.update(kwargs)
    return indexing.index_document(**defaults, **pipeline)


# =====================================================================
# 1. Memory — a large document must not hold every vector at once
# =====================================================================


def test_embedding_and_upsert_stream_in_bounded_slices(
    settings, embedder, memory_store, make_settings
):
    """A list of 384 floats is ~3 KB; 20,000 chunks held at once is
    ~60 MB of vectors alive beside the chunks they came from."""
    peak_alive = 0

    class CountingStore:
        def __init__(self, inner):
            self.inner = inner

        def __getattr__(self, name):
            return getattr(self.inner, name)

        def upsert(self, chunks, vectors):
            nonlocal peak_alive
            peak_alive = max(peak_alive, len(vectors))
            return self.inner.upsert(chunks, vectors)

    chunks = fixtures.make_chunks(fixtures.VENDOR_CONTRACT * 12, tenant_id=TENANT)
    assert len(chunks) > 64

    result = indexing.IndexResult(document_id="d", tenant_id=TENANT, filename="f")
    settings = make_settings(index_batch_size=16)
    indexing._embed_and_store(
        chunks, embedder, CountingStore(memory_store), settings, result
    )

    assert peak_alive <= 16
    assert memory_store.count() == len(chunks)


def test_the_slice_size_is_configurable(settings, embedder, memory_store, make_settings):
    chunks = fixtures.make_chunks(fixtures.VENDOR_CONTRACT, tenant_id=TENANT)
    result = indexing.IndexResult(document_id="d", tenant_id=TENANT, filename="f")
    stored = indexing._embed_and_store(
        chunks, embedder, memory_store, make_settings(index_batch_size=1), result
    )
    assert stored == len(chunks)


# =====================================================================
# 2 & 5. Partial failures — the index is never left half-written
# =====================================================================


class _FailingStore:
    """Fails after the first upsert slice, as a store under pressure would."""

    def __init__(self, inner, fail_after: int = 1):
        self.inner = inner
        self.fail_after = fail_after
        self.calls = 0

    def __getattr__(self, name):
        return getattr(self.inner, name)

    def upsert(self, chunks, vectors):
        self.calls += 1
        if self.calls > self.fail_after:
            raise VectorStoreError("the store went away")
        return self.inner.upsert(chunks, vectors)


def test_a_failed_write_leaves_no_partial_document(
    multipage_pdf, settings, embedder, memory_store, make_settings
):
    """Half a contract in the index is worse than none: retrieval would
    return some clauses and silently omit the rest."""
    store = _FailingStore(memory_store, fail_after=1)
    tuned = make_settings(index_batch_size=2)

    with pytest.raises(IndexingError) as excinfo:
        indexing.index_document(
            document_id="doc-partial",
            tenant_id=TENANT,
            file_path=multipage_pdf.name,
            settings=tuned,
            model=embedder,
            store=store,
        )

    assert "not indexed" in str(excinfo.value)
    assert memory_store.document_chunk_count("doc-partial", TENANT) == 0


def test_the_failure_says_the_document_must_be_re_ingested(
    multipage_pdf, settings, embedder, memory_store, make_settings
):
    store = _FailingStore(memory_store, fail_after=0)
    with pytest.raises(IndexingError) as excinfo:
        indexing.index_document(
            document_id="doc-partial",
            tenant_id=TENANT,
            file_path=multipage_pdf.name,
            settings=make_settings(index_batch_size=2),
            model=embedder,
            store=store,
        )
    assert "Re-ingest" in str(excinfo.value)
    assert excinfo.value.error_type == "indexing_failed"


def test_a_failed_rewrite_does_not_leave_the_old_version_half_replaced(
    multipage_pdf, settings, embedder, memory_store, make_settings
):
    """The old chunks are gone and the new ones did not arrive, so the
    document must be *absent*, not a mixture of two versions."""
    _index(multipage_pdf, {"settings": settings, "model": embedder, "store": memory_store},
           document_id="doc-rewrite")
    before = memory_store.document_chunk_count("doc-rewrite", TENANT)
    assert before > 0

    store = _FailingStore(memory_store, fail_after=1)
    with pytest.raises(IndexingError):
        indexing.index_document(
            document_id="doc-rewrite",
            tenant_id=TENANT,
            file_path=multipage_pdf.name,
            settings=make_settings(index_batch_size=2, skip_unchanged_documents=False),
            model=embedder,
            store=store,
        )

    assert memory_store.document_chunk_count("doc-rewrite", TENANT) == 0


# =====================================================================
# 3. Failure isolation — one document never harms another
# =====================================================================


def test_a_failed_document_does_not_disturb_its_neighbours(
    multipage_pdf, contract_pdf, settings, embedder, memory_store, make_settings
):
    pipe = {"settings": settings, "model": embedder, "store": memory_store}
    _index(contract_pdf, pipe, document_id="doc-good")
    good = memory_store.document_chunk_count("doc-good", TENANT)

    store = _FailingStore(memory_store, fail_after=0)
    with pytest.raises(IndexingError):
        indexing.index_document(
            document_id="doc-bad",
            tenant_id=TENANT,
            file_path=multipage_pdf.name,
            settings=make_settings(index_batch_size=2),
            model=embedder,
            store=store,
        )

    assert memory_store.document_chunk_count("doc-good", TENANT) == good


# =====================================================================
# 4. Duplicate documents — reported, never silently merged
# =====================================================================


def test_identical_content_under_a_second_id_is_reported(
    contract_pdf, settings, embedder, memory_store
):
    pipe = {"settings": settings, "model": embedder, "store": memory_store}
    _index(contract_pdf, pipe, document_id="doc-original")
    second = _index(contract_pdf, pipe, document_id="doc-copy")

    assert second.duplicate_of == "doc-original"
    assert any("already indexed" in w for w in second.warnings)


def test_a_duplicate_is_still_indexed(contract_pdf, settings, embedder, memory_store):
    """Two copies of one contract filed under two matters is legitimate;
    refusing the second would be the service overruling the user."""
    pipe = {"settings": settings, "model": embedder, "store": memory_store}
    _index(contract_pdf, pipe, document_id="doc-original")
    second = _index(contract_pdf, pipe, document_id="doc-copy")

    assert second.chunks_indexed > 0
    assert memory_store.document_chunk_count("doc-copy", TENANT) > 0


def test_the_same_content_in_two_tenants_is_not_a_duplicate(
    contract_pdf, settings, embedder, memory_store
):
    """Reporting it would leak the fact that another tenant holds it."""
    pipe = {"settings": settings, "model": embedder, "store": memory_store}
    _index(contract_pdf, pipe, document_id="doc-a", tenant_id="tenant-one")
    second = _index(contract_pdf, pipe, document_id="doc-b", tenant_id="tenant-two")

    assert second.duplicate_of is None


def test_duplicate_detection_can_be_switched_off(
    contract_pdf, settings, embedder, memory_store, make_settings
):
    pipe = {"settings": settings, "model": embedder, "store": memory_store}
    _index(contract_pdf, pipe, document_id="doc-original")
    quiet = {**pipe, "settings": make_settings(detect_duplicate_documents=False)}
    second = _index(contract_pdf, quiet, document_id="doc-copy")

    assert second.duplicate_of is None


# =====================================================================
# 8. Repeated ingestion — unchanged content is not re-processed
# =====================================================================


def test_an_unchanged_document_skips_extraction_and_embedding(
    multipage_pdf, settings, embedder, memory_store
):
    pipe = {"settings": settings, "model": embedder, "store": memory_store}
    first = _index(multipage_pdf, pipe)
    second = _index(multipage_pdf, pipe)

    assert first.status == "success"
    assert second.status == "unchanged"
    assert second.extract_ms == 0 and second.embed_ms == 0
    assert second.chunks_indexed == first.chunks_indexed


def test_an_edited_document_is_re_processed(
    settings, embedder, memory_store, doc_root
):
    """The check is on content, not on the id: a changed file must not
    be mistaken for an unchanged one."""
    path = doc_root / "edited_agreement.pdf"
    fixtures.make_pdf(path, "AGREEMENT", fixtures.VENDOR_CONTRACT[:3])

    pipe = {"settings": settings, "model": embedder, "store": memory_store}
    first = _index(path, pipe, document_id="doc-edit")

    fixtures.make_pdf(path, "AGREEMENT", fixtures.VENDOR_CONTRACT[:6])
    second = _index(path, pipe, document_id="doc-edit")

    assert second.status == "success"
    assert second.extract_ms >= 0
    assert second.chunks_indexed != first.chunks_indexed


def test_the_same_content_under_a_different_id_is_not_skipped(
    contract_pdf, settings, embedder, memory_store
):
    """The digest matches but the id does not, so it is a new document."""
    pipe = {"settings": settings, "model": embedder, "store": memory_store}
    _index(contract_pdf, pipe, document_id="doc-one")
    second = _index(contract_pdf, pipe, document_id="doc-two")

    assert second.status == "success"
    assert memory_store.document_chunk_count("doc-two", TENANT) > 0


def test_forcing_ocr_always_re_processes(
    contract_pdf, settings, embedder, memory_store
):
    """The bytes are unchanged but the caller is asking for a different
    reading of them."""
    pipe = {"settings": settings, "model": embedder, "store": memory_store}
    _index(contract_pdf, pipe)
    second = _index(contract_pdf, pipe, force_ocr=True)
    assert second.status != "unchanged"


# =====================================================================
# 9. Vector-store consistency — the BM25 cache cannot go stale
# =====================================================================


def test_the_store_reports_a_version_that_changes_on_every_write(
    embedder, memory_store
):
    start = memory_store.version(TENANT)
    chunks = fixtures.make_chunks(fixtures.VENDOR_CONTRACT, tenant_id=TENANT)
    memory_store.upsert(chunks, embedder.embed_documents([c.text for c in chunks]))
    after_write = memory_store.version(TENANT)
    memory_store.delete_document("doc-contract", TENANT)
    after_delete = memory_store.version(TENANT)

    assert after_write > start
    assert after_delete > after_write


def test_a_write_to_one_tenant_does_not_invalidate_another(embedder, memory_store):
    chunks = fixtures.make_chunks(fixtures.VENDOR_CONTRACT, tenant_id="tenant-one")
    before = memory_store.version("tenant-two")
    memory_store.upsert(chunks, embedder.embed_documents([c.text for c in chunks]))
    assert memory_store.version("tenant-two") == before


def test_the_cache_is_reused_while_the_corpus_is_unchanged(
    settings, indexed_store
):
    retriever = KeywordRetriever(indexed_store, settings)
    query = preprocess_query("termination notice")
    filters = SearchFilter(tenant_id=TENANT)

    retriever.retrieve(query, filters, limit=5)
    assert retriever.last_cache_hit is False

    retriever.retrieve(query, filters, limit=5)
    assert retriever.last_cache_hit is True


def test_indexing_a_document_invalidates_the_cache(
    settings, indexed_store, embedder
):
    """The failure this prevents: citing a document the user deleted, or
    missing one they just uploaded."""
    retriever = KeywordRetriever(indexed_store, settings)
    query = preprocess_query("termination notice")
    filters = SearchFilter(tenant_id=TENANT)

    retriever.retrieve(query, filters, limit=5)
    retriever.retrieve(query, filters, limit=5)
    assert retriever.last_cache_hit is True

    fresh = fixtures.make_chunks(
        fixtures.MUTUAL_NDA, document_id="doc-new", tenant_id=TENANT
    )
    indexed_store.upsert(fresh, embedder.embed_documents([c.text for c in fresh]))

    retriever.retrieve(query, filters, limit=5)
    assert retriever.last_cache_hit is False


def test_deleting_a_document_invalidates_the_cache(settings, indexed_store):
    retriever = KeywordRetriever(indexed_store, settings)
    query = preprocess_query("termination notice")
    filters = SearchFilter(tenant_id=TENANT)

    retriever.retrieve(query, filters, limit=5)
    retriever.retrieve(query, filters, limit=5)
    assert retriever.last_cache_hit is True

    indexed_store.delete_document("doc-nda", TENANT)
    retriever.retrieve(query, filters, limit=5)
    assert retriever.last_cache_hit is False


def test_a_deleted_document_stops_being_retrievable_immediately(
    settings, indexed_store
):
    """The behaviour behind the invalidation, asserted end to end."""
    retriever = KeywordRetriever(indexed_store, settings)
    query = preprocess_query("confidential information disclosed")
    filters = SearchFilter(tenant_id=TENANT)

    retriever.retrieve(query, filters, limit=20)
    indexed_store.delete_document("doc-nda", TENANT)
    after = retriever.retrieve(query, filters, limit=20)

    assert all(c.chunk.document_id != "doc-nda" for c in after)


def test_a_filtered_query_is_not_served_from_the_tenant_cache(
    settings, indexed_store
):
    """A filtered corpus is a different corpus; serving the tenant-wide
    index for it would return documents the filter excluded."""
    retriever = KeywordRetriever(indexed_store, settings)
    query = preprocess_query("termination")

    retriever.retrieve(query, SearchFilter(tenant_id=TENANT), limit=5)
    filtered = retriever.retrieve(
        query, SearchFilter(tenant_id=TENANT, document_type="nda"), limit=5
    )

    assert retriever.last_cache_hit is False
    assert all(c.chunk.document_id == "doc-nda" for c in filtered)


def test_retrievers_with_different_settings_do_not_share_an_index(
    settings, indexed_store, make_settings
):
    """Caught by the suite when the key was the tenant id alone: a
    retriever limited to 3 chunks was being served the full index."""
    full = KeywordRetriever(indexed_store, settings)
    limited = KeywordRetriever(indexed_store, make_settings(keyword_corpus_limit=3))
    query = preprocess_query("termination")
    filters = SearchFilter(tenant_id=TENANT)

    full.retrieve(query, filters, limit=5)
    limited.retrieve(query, filters, limit=5)

    assert limited.last_corpus_size == 3
    assert limited.last_corpus_truncated


def test_the_cache_can_be_switched_off(settings, indexed_store, make_settings):
    """The escape hatch for a deployment with a second writer."""
    retriever = KeywordRetriever(
        indexed_store, make_settings(keyword_cache_enabled=False)
    )
    query = preprocess_query("termination")
    filters = SearchFilter(tenant_id=TENANT)

    retriever.retrieve(query, filters, limit=5)
    retriever.retrieve(query, filters, limit=5)
    assert retriever.last_cache_hit is False


# -- the cache itself -------------------------------------------------


def _index_of(size: int) -> BM25Index:
    chunks = fixtures.make_chunks(fixtures.VENDOR_CONTRACT, tenant_id=TENANT)
    while len(chunks) < size:
        chunks = chunks + chunks
    return BM25Index(chunks=chunks[:size])


def test_the_cache_evicts_least_recently_used_to_stay_in_budget():
    cache = BM25Cache(max_chunks=20)
    cache.put("a", 1, _index_of(8))
    cache.put("b", 1, _index_of(8))
    cache.get("a", 1)                      # 'a' is now the most recent
    cache.put("c", 1, _index_of(8))        # 24 > 20, so one must go

    assert cache.cached_chunks <= 20
    assert cache.get("b", 1) is None
    assert cache.get("a", 1) is not None


def test_a_corpus_larger_than_the_whole_budget_is_not_cached():
    """Evicting everything else for one oversized entry helps nobody."""
    cache = BM25Cache(max_chunks=10)
    cache.put("big", 1, _index_of(40))
    assert cache.get("big", 1) is None
    assert cache.cached_chunks == 0


def test_a_stale_entry_is_dropped_rather_than_left_occupying_the_budget():
    cache = BM25Cache(max_chunks=100)
    cache.put("a", 1, _index_of(8))
    assert cache.get("a", 2) is None
    assert cache.cached_chunks == 0


def test_the_cache_reports_its_own_behaviour():
    cache = BM25Cache(max_chunks=100)
    cache.put("a", 1, _index_of(8))
    cache.get("a", 1)
    cache.get("b", 1)

    stats = cache.stats()
    assert stats["hits"] == 1
    assert stats["misses"] == 1
    assert stats["entries"] == 1
    assert stats["cached_chunks"] == 8


def test_a_zero_budget_disables_caching_entirely():
    cache = BM25Cache(max_chunks=0)
    cache.put("a", 1, _index_of(4))
    assert cache.get("a", 1) is None


# =====================================================================
# 10. Tenant isolation — still holds with the cache in play
# =====================================================================


def test_the_cache_is_keyed_per_tenant(settings, indexed_store, corpus_chunks):
    retriever = KeywordRetriever(indexed_store, settings)
    query = preprocess_query("termination notice")

    a = retriever.retrieve(query, SearchFilter(tenant_id=TENANT), limit=20)
    b = retriever.retrieve(query, SearchFilter(tenant_id="tenant-b"), limit=20)

    assert all(c.chunk.tenant_id == TENANT for c in a)
    assert all(c.chunk.tenant_id == "tenant-b" for c in b)


def test_a_cached_tenant_never_leaks_into_another(settings, indexed_store):
    retriever = KeywordRetriever(indexed_store, settings)
    query = preprocess_query("termination notice")

    retriever.retrieve(query, SearchFilter(tenant_id=TENANT), limit=20)
    retriever.retrieve(query, SearchFilter(tenant_id=TENANT), limit=20)
    assert retriever.last_cache_hit is True

    other = retriever.retrieve(query, SearchFilter(tenant_id="tenant-b"), limit=20)
    assert all(c.chunk.tenant_id == "tenant-b" for c in other)


# =====================================================================
# Temp files — nothing outlives the process that made it
# =====================================================================


def test_stale_temp_files_are_swept(settings, make_settings):
    """A SIGKILL skips the finally that would have removed them; on a
    shared volume they then accumulate until the disk fills."""
    from app.ingestion.tempfiles import _temp_root, sweep_stale_temp_files

    root = _temp_root(settings)
    stale = root / "stale-leftover.tmp"
    stale.write_bytes(b"x" * 128)
    old = time.time() - 48 * 3600
    import os

    os.utime(stale, (old, old))

    fresh = root / "fresh-in-flight.tmp"
    fresh.write_bytes(b"y" * 128)

    removed = sweep_stale_temp_files(settings, max_age_hours=6)

    assert removed >= 1
    assert not stale.exists()
    # A file younger than the cut-off may belong to a live request.
    assert fresh.exists()
    fresh.unlink()


def test_the_sweep_can_be_disabled(settings):
    from app.ingestion.tempfiles import _temp_root, sweep_stale_temp_files

    root = _temp_root(settings)
    stale = root / "keep-me.tmp"
    stale.write_bytes(b"z")
    import os

    old = time.time() - 48 * 3600
    os.utime(stale, (old, old))

    assert sweep_stale_temp_files(settings, max_age_hours=0) == 0
    assert stale.exists()
    stale.unlink()


def test_the_sweep_never_raises_on_a_missing_directory(make_settings):
    from app.ingestion.tempfiles import sweep_stale_temp_files

    settings = make_settings(temp_dir="/nonexistent/path/that/cannot/be/made")
    try:
        sweep_stale_temp_files(settings)
    except Exception as exc:  # pragma: no cover - the point of the test
        pytest.fail(f"the sweep raised {type(exc).__name__}")


# =====================================================================
# The stage number — asserted here, by the stage that owns it
# =====================================================================


def test_the_service_root_reports_stage_nine():
    """The one place the current stage number is asserted.

    Every other test asserts its own stage's *durable* claim instead, so
    advancing a stage never fails a test that was passing correctly.
    """
    from fastapi.testclient import TestClient

    from app.main import app

    with TestClient(app) as client:
        stage = client.get("/").json()["stage"]

    assert stage.startswith("9")
    assert "hardened" in stage.lower()
