"""Health endpoint tests."""

from __future__ import annotations

from datetime import datetime


def test_health_returns_200(client):
    assert client.get("/health").status_code == 200


def test_health_reports_the_expected_shape(client, settings):
    body = client.get("/health").json()

    # The aggregate depends on which backends are configured (the test
    # suite runs on the in-memory store, which reports degraded on
    # purpose), so assert the contract, not one particular value.
    assert body["status"] in {"ok", "degraded", "unavailable"}
    assert body["service"] == settings.app_name
    assert body["version"] == settings.app_version
    assert body["environment"] == settings.environment
    assert isinstance(body["uptime_seconds"], (int, float))
    assert body["uptime_seconds"] >= 0
    assert body["timestamp"]
    assert isinstance(body["components"], list)


def test_health_timestamp_is_valid_iso8601(client):
    stamp = client.get("/health").json()["timestamp"]
    parsed = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
    assert parsed.tzinfo is not None


def test_health_reports_the_configuration_component(client):
    components = client.get("/health").json()["components"]
    names = {c["name"] for c in components}
    assert "configuration" in names
    config = next(c for c in components if c["name"] == "configuration")
    assert config["status"] == "ok"


def test_every_component_reports_a_valid_status(client):
    for component in client.get("/health").json()["components"]:
        assert component["status"] in {"ok", "degraded", "unavailable"}
        assert component["name"]


def test_uptime_increases_between_calls(client):
    first = client.get("/health").json()["uptime_seconds"]
    second = client.get("/health").json()["uptime_seconds"]
    assert second >= first


def test_health_needs_no_service_token(client_factory, make_settings):
    """An orchestrator must be able to probe without credentials."""
    with client_factory(make_settings(service_token="s3cret")) as c:
        assert c.get("/health").status_code == 200
        assert c.get("/health/live").status_code == 200
        assert c.get("/health/ready").status_code == 200


def test_liveness_probe(client):
    response = client.get("/health/live")
    assert response.status_code == 200
    assert response.json() == {"status": "alive"}


def test_readiness_probe_is_ready(client):
    body = client.get("/health/ready").json()
    assert body["ready"] is True
    assert body["detail"] is None


def test_production_without_a_token_reports_degraded(client_factory, make_settings):
    cfg = make_settings(environment="production", service_token="")
    with client_factory(cfg) as c:
        body = c.get("/health").json()
    assert body["status"] == "degraded"
    assert any(comp["name"] == "service_token" for comp in body["components"])


def test_production_with_a_token_does_not_flag_the_token(
    client_factory, make_settings
):
    """The service_token warning must disappear once one is configured."""
    cfg = make_settings(environment="production", service_token="s3cret")
    with client_factory(cfg) as c:
        body = c.get("/health").json()

    assert "service_token" not in {comp["name"] for comp in body["components"]}


def test_health_response_carries_a_request_id_header(client):
    response = client.get("/health")
    assert response.headers.get("X-Request-ID")
    assert response.headers.get("X-Response-Time-ms")


def test_incoming_request_id_is_echoed(client):
    response = client.get("/health", headers={"X-Request-ID": "abc123"})
    assert response.headers["X-Request-ID"] == "abc123"
