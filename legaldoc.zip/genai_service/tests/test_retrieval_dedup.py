"""Stage 5 — near-duplicate removal.

The hard part is not detecting duplicates; it is *not* detecting the
ones that are meant to be there. Stage 3 deliberately repeats ~50 tokens
between neighbouring chunks, and collapsing those would undo the
mechanism that makes an answer straddling a chunk boundary retrievable.
Both directions are asserted here.
"""

from __future__ import annotations

import pytest

from app.models.chunk import Chunk, make_chunk_id
from app.models.document import DocumentType
from app.retrieval.base import Candidate
from app.retrieval.dedup import (
    jaccard,
    normalize_for_comparison,
    remove_duplicates,
    shingles,
)
from tests import fixtures

TERMINATION = (
    "4. TERMINATION\n\nEither party may terminate this Agreement for "
    "convenience on one hundred and twenty (120) days written notice to the "
    "other party. Either party may terminate immediately by written notice "
    "if the other party commits a material breach."
)
LIABILITY = (
    "5. LIMITATION OF LIABILITY\n\nThe aggregate liability of either party "
    "shall not exceed the total fees paid in the twelve (12) months "
    "preceding the event giving rise to the claim."
)


def _candidate(
    text: str,
    document_id: str = "doc-1",
    chunk_index: int = 0,
    score: float = 1.0,
) -> Candidate:
    chunk = Chunk(
        chunk_id=make_chunk_id(document_id, chunk_index, text),
        chunk_index=chunk_index,
        text=text,
        document_id=document_id,
        tenant_id="tenant-a",
        filename=f"{document_id}.pdf",
        page_number=1,
        document_type=DocumentType.CONTRACT,
        token_count=len(text.split()),
    )
    candidate = Candidate(chunk=chunk)
    candidate.fused_score = score
    candidate.rank_score = score
    candidate.final_score = score
    return candidate


# ---------------------------------------------------------------------
# Primitives
# ---------------------------------------------------------------------


def test_normalisation_ignores_punctuation_and_whitespace():
    a = normalize_for_comparison('The "Vendor" shall pay —  promptly.')
    b = normalize_for_comparison("the vendor shall pay promptly")
    assert a == b


def test_shingles_of_a_short_string_are_the_string():
    assert shingles("abc", size=5) == {"abc"}


def test_shingles_of_empty_text_are_empty():
    assert shingles("   ") == set()


def test_jaccard_bounds():
    assert jaccard({"a"}, {"a"}) == 1.0
    assert jaccard({"a"}, {"b"}) == 0.0
    assert jaccard(set(), set()) == 1.0
    assert jaccard({"a"}, set()) == 0.0
    assert 0.0 < jaccard({"a", "b"}, {"b", "c"}) < 1.0


# ---------------------------------------------------------------------
# What must be removed
# ---------------------------------------------------------------------


def test_identical_text_in_two_documents_is_collapsed():
    """The same agreement uploaded twice — the common real case."""
    kept, removed = remove_duplicates(
        [
            _candidate(TERMINATION, "doc-1", 3, score=1.0),
            _candidate(TERMINATION, "doc-2", 7, score=0.8),
        ]
    )
    assert len(kept) == 1
    assert removed == 1


def test_the_better_scoring_copy_is_the_one_kept():
    first = _candidate(TERMINATION, "doc-1", 3, score=1.0)
    second = _candidate(TERMINATION, "doc-2", 7, score=0.8)
    kept, _ = remove_duplicates([first, second])
    assert kept[0].chunk.document_id == "doc-1"


def test_the_dropped_citation_is_not_lost():
    """The passage is not repeated; the chunk_id still travels with it."""
    first = _candidate(TERMINATION, "doc-1", 3)
    second = _candidate(TERMINATION, "doc-2", 7)
    kept, _ = remove_duplicates([first, second])
    assert second.chunk_id in kept[0].duplicates


def test_near_identical_text_is_collapsed():
    """OCR noise and a renamed party must not produce two 'results'."""
    variant = TERMINATION.replace("Agreement", "Aqreement").replace(
        "other party", "other Party"
    )
    kept, removed = remove_duplicates(
        [_candidate(TERMINATION, "doc-1", 1), _candidate(variant, "doc-2", 1)]
    )
    assert len(kept) == 1
    assert removed == 1


def test_exact_duplicates_are_collapsed_even_when_adjacent():
    """The adjacency exemption covers *overlap*, not identical text."""
    kept, removed = remove_duplicates(
        [
            _candidate(TERMINATION, "doc-1", 4),
            _candidate(TERMINATION, "doc-1", 5),
        ]
    )
    assert len(kept) == 1
    assert removed == 1


# ---------------------------------------------------------------------
# What must be kept
# ---------------------------------------------------------------------


def test_different_clauses_are_not_duplicates():
    kept, removed = remove_duplicates(
        [_candidate(TERMINATION, "doc-1", 3), _candidate(LIABILITY, "doc-1", 4)]
    )
    assert len(kept) == 2
    assert removed == 0


def test_stage_three_chunk_overlap_is_preserved():
    """Neighbouring chunks share ~50 tokens by design.

    If dedup collapsed these, an answer spanning the boundary would stop
    being retrievable from both sides — exactly what the overlap exists
    to guarantee.
    """
    tail = TERMINATION.split(". ")[-1]
    first = _candidate(TERMINATION, "doc-1", 3)
    second = _candidate(f"{tail} On termination the Vendor shall return all "
                        f"Client data within fifteen (15) days.", "doc-1", 4)
    kept, removed = remove_duplicates([first, second])
    assert len(kept) == 2
    assert removed == 0


def test_a_whole_real_corpus_survives_deduplication():
    """No clause of the synthetic contract is a duplicate of another."""
    candidates = [
        _candidate(c.text, "doc-contract", c.chunk_index)
        for c in fixtures.make_chunks(fixtures.VENDOR_CONTRACT)
    ]
    kept, removed = remove_duplicates(candidates)
    assert removed == 0
    assert len(kept) == len(candidates)


def test_cross_document_deduplication_can_be_switched_off():
    """Some callers want both citations as separate results."""
    kept, removed = remove_duplicates(
        [
            _candidate(TERMINATION, "doc-1", 3),
            _candidate(TERMINATION, "doc-2", 7),
        ],
        across_documents=False,
    )
    # Exact-text collapsing still applies; it is the *near*-duplicate
    # comparison that is restricted to one document.
    assert removed == 1
    variant = TERMINATION.replace("Agreement", "Aqreement")
    kept, removed = remove_duplicates(
        [_candidate(TERMINATION, "doc-1", 3), _candidate(variant, "doc-2", 7)],
        across_documents=False,
    )
    assert len(kept) == 2
    assert removed == 0


# ---------------------------------------------------------------------
# Threshold and edge cases
# ---------------------------------------------------------------------


def test_the_threshold_controls_how_aggressive_removal_is():
    variant = TERMINATION.replace(
        "one hundred and twenty (120)", "sixty (60)"
    ).replace("material breach", "serious default")
    pair = [_candidate(TERMINATION, "doc-1", 1), _candidate(variant, "doc-2", 1)]

    loose, removed_loose = remove_duplicates(list(pair), threshold=0.5)
    strict, removed_strict = remove_duplicates(list(pair), threshold=0.99)
    assert removed_loose >= removed_strict
    assert len(loose) <= len(strict)


def test_an_empty_candidate_list_is_handled():
    assert remove_duplicates([]) == ([], 0)


def test_a_single_candidate_survives():
    kept, removed = remove_duplicates([_candidate(TERMINATION)])
    assert len(kept) == 1 and removed == 0


def test_empty_text_candidates_do_not_crash():
    kept, removed = remove_duplicates(
        [_candidate("", "doc-1", 1), _candidate("", "doc-2", 2)]
    )
    assert len(kept) + removed == 2


@pytest.mark.parametrize("size", [2, 5, 12])
def test_shingle_size_does_not_change_the_identical_case(size):
    kept, removed = remove_duplicates(
        [_candidate(TERMINATION, "doc-1", 1), _candidate(TERMINATION, "doc-2", 1)],
        shingle_size=size,
    )
    assert len(kept) == 1 and removed == 1
