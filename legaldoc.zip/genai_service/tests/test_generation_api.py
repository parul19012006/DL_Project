"""Stage 7 — the HTTP contract for grounded answers.

`POST /answer` is the end of the pipeline and the endpoint a chat feature
calls. These run over the real application, because what the MERN backend
depends on is the JSON.
"""

from __future__ import annotations

import pytest

from app.generation.base import LLMUnavailableError
from app.generation.factory import set_llm_provider
from tests import fixtures
from tests.fixtures import StubProvider, answer_json

TENANT_A = "tenant-a"
TENANT_B = "tenant-b"
QUESTION = "How much notice is required to terminate for convenience?"


@pytest.fixture
def indexed(client, corpus_chunks):
    from app.services.indexing import index_chunks

    for chunks in corpus_chunks.values():
        index_chunks(chunks)
    return client


@pytest.fixture
def scripted(indexed):
    """Install a scripted model behind the running application."""

    def _install(provider):
        set_llm_provider(provider)
        return indexed

    return _install


def _ask(client, **body):
    payload = {"query": QUESTION, "tenant_id": TENANT_A}
    payload.update(body)
    return client.post("/answer", json=payload)


# ---------------------------------------------------------------------
# The happy path
# ---------------------------------------------------------------------


def test_a_grounded_answer_comes_back_in_the_required_shape(scripted):
    client = scripted(StubProvider(answer_json("Notice is 120 days.", [1])))
    response = _ask(client)

    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["answer"]
    assert body["citations"]
    for citation in body["citations"]:
        assert set(citation) >= {"document", "page", "section", "chunk_id"}


def test_citations_resolve_to_the_returned_sources(scripted):
    client = scripted(StubProvider(answer_json("Notice is 120 days.", [1, 2])))
    body = _ask(client).json()

    source_ids = {s["chunk_id"] for s in body["sources"]}
    assert {c["chunk_id"] for c in body["citations"]} <= source_ids
    for citation in body["citations"]:
        assert any(s["source"] == citation["source"] for s in body["sources"])


def test_the_validation_report_is_returned(scripted):
    client = scripted(StubProvider(answer_json("Notice is 120 days.", [1])))
    body = _ask(client).json()

    assert body["validation"]["grounded"] is True
    assert body["validation"]["valid_citations"] == len(body["citations"])
    assert body["grounded"] is True


def test_interpretation_is_a_separate_field(scripted):
    client = scripted(
        StubProvider(
            answer_json(
                "The contract requires 120 days notice.",
                [1],
                interpretation="You would need to serve notice by March.",
            )
        )
    )
    body = _ask(client).json()
    assert "March" in body["interpretation"]
    assert "March" not in body["answer"]


def test_timings_and_usage_are_reported(scripted):
    client = scripted(StubProvider(answer_json("An answer.", [1])))
    body = _ask(client).json()

    assert set(body["timings_ms"]) >= {"retrieval", "context", "generation"}
    assert body["usage"]["total_tokens"] > 0
    assert body["duration_ms"] >= 0


def test_the_response_names_the_provider(scripted):
    client = scripted(StubProvider(answer_json("An answer.", [1])))
    body = _ask(client).json()

    assert body["provider"] == "stub"
    assert body["is_language_model"] is True


# ---------------------------------------------------------------------
# Options
# ---------------------------------------------------------------------


def test_the_prompt_block_can_be_returned_for_inspection(scripted):
    client = scripted(StubProvider(answer_json("An answer.", [1])))
    body = _ask(client, include_context=True).json()
    assert body["context"].startswith("Source 1:")


def test_the_prompt_block_is_omitted_by_default(scripted):
    client = scripted(StubProvider(answer_json("An answer.", [1])))
    assert _ask(client).json()["context"] is None


def test_sources_can_be_omitted(scripted):
    client = scripted(StubProvider(answer_json("An answer.", [1])))
    body = _ask(client, include_sources=False).json()
    assert body["sources"] == []
    assert body["citations"]


def test_retrieval_and_context_options_still_apply(scripted):
    client = scripted(StubProvider(answer_json("An answer.", [1])))
    body = _ask(client, document_type="nda", context_max_sources=2).json()

    assert all(s["document_id"] == "doc-nda" for s in body["sources"])
    assert len(body["sources"]) <= 2


def test_an_out_of_range_temperature_is_rejected(indexed):
    response = indexed.post(
        "/answer",
        json={"query": QUESTION, "tenant_id": TENANT_A, "temperature": 5},
    )
    assert response.status_code == 422


# ---------------------------------------------------------------------
# Grounding failures
# ---------------------------------------------------------------------


def test_an_invented_citation_is_dropped_and_reported(scripted):
    client = scripted(StubProvider(answer_json("An answer.", [1, 99])))
    body = _ask(client).json()

    assert 99 not in [c["source"] for c in body["citations"]]
    rejected = body["validation"]["rejected"]
    assert any(r["claimed_source"] == 99 for r in rejected)


def test_an_uncited_answer_is_marked_ungrounded(scripted):
    client = scripted(StubProvider(answer_json("Notice is 120 days.", [])))
    body = _ask(client).json()

    assert body["status"] == "ok"
    assert body["grounded"] is False
    assert body["warnings"]


def test_an_unverifiable_quotation_is_reported(scripted):
    client = scripted(
        StubProvider(
            answer_json('The clause says "notice may be given by telephone".', [1])
        )
    )
    body = _ask(client).json()

    assert body["validation"]["unverified_quotes"]
    assert body["grounded"] is False


# ---------------------------------------------------------------------
# Insufficient evidence
# ---------------------------------------------------------------------


def test_a_tenant_with_no_documents_gets_a_plain_refusal(scripted):
    client = scripted(StubProvider(answer_json("From memory: 30 days.", [1])))
    body = _ask(client, tenant_id="tenant-nobody").json()

    assert body["status"] == "insufficient_evidence"
    assert body["insufficient_evidence"] is True
    assert body["citations"] == []


def test_a_model_reporting_insufficient_evidence_is_surfaced(scripted):
    client = scripted(
        StubProvider(answer_json("Not addressed by the passages.", [], insufficient=True))
    )
    body = _ask(client).json()

    assert body["status"] == "insufficient_evidence"
    assert body["sources"]


# ---------------------------------------------------------------------
# Failure handling
# ---------------------------------------------------------------------


def test_an_llm_outage_returns_the_evidence_rather_than_an_error_page(scripted):
    """The retrieval succeeded; discarding it would serve the user worse."""
    client = scripted(StubProvider(raises=LLMUnavailableError("upstream down")))
    response = _ask(client)

    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "llm_unavailable"
    assert body["answer"] is None
    assert body["sources"]
    assert body["error"]


def test_a_malformed_reply_is_reported_with_an_excerpt(scripted):
    client = scripted(StubProvider(["not json at all"]))
    body = _ask(client).json()

    assert body["status"] == "malformed_response"
    assert body["answer"] is None
    assert body["raw_excerpt"].startswith("not json")
    assert body["attempts"] == 2


def test_a_recovered_reply_still_answers(scripted):
    client = scripted(
        StubProvider(["blah", answer_json("Notice is 120 days.", [1])])
    )
    body = _ask(client).json()
    assert body["status"] == "ok"
    assert body["answer"]


# ---------------------------------------------------------------------
# Isolation and validation
# ---------------------------------------------------------------------


def test_tenant_isolation_holds_through_generation(scripted, corpus_chunks):
    foreign = {c.chunk_id for c in corpus_chunks["other_tenant"]}
    client = scripted(StubProvider(answer_json("An answer.", [1])))

    body = _ask(client).json()
    assert not ({s["chunk_id"] for s in body["sources"]} & foreign)

    other = _ask(client, tenant_id=TENANT_B).json()
    assert all(s["document_id"] == "doc-rival" for s in other["sources"])


def test_a_missing_tenant_is_a_validation_error(indexed):
    response = indexed.post("/answer", json={"query": QUESTION})
    assert response.status_code == 422
    assert response.json()["error"]["type"] == "validation_error"


def test_an_empty_question_is_rejected(indexed):
    response = indexed.post("/answer", json={"query": "", "tenant_id": TENANT_A})
    assert response.status_code == 422


# ---------------------------------------------------------------------
# Config, health and wiring
# ---------------------------------------------------------------------


def test_the_config_endpoint_never_returns_a_key(client):
    body = client.get("/answer/config").json()
    text = str(body)
    assert "sk-" not in text
    assert "api_key" not in [k for k in body if k != "api_key_configured"]
    assert "api_key_configured" in body


def test_the_config_endpoint_reports_the_live_provider(client):
    body = client.get("/answer/config").json()
    assert body["provider_active"]
    assert set(body["available_providers"]) >= {"extractive", "openai", "anthropic"}
    assert body["temperature"] == 0.0


def test_the_default_deployment_reports_no_language_model(client):
    """The suite runs offline, and the response says so rather than
    implying a model wrote the answer."""
    body = client.get("/answer/config").json()
    assert body["is_language_model"] is False


def test_health_reports_the_llm_component(client):
    components = {c["name"]: c for c in client.get("/health").json()["components"]}
    assert "llm" in components
    assert components["llm"]["detail"]


def test_the_openapi_document_includes_the_answer_endpoints(client):
    paths = client.get("/openapi.json").json()["paths"]
    assert "/answer" in paths
    assert "/answer/config" in paths


def test_the_service_root_advertises_grounded_generation(client):
    """Stage 7's durable claim on the root document.

    The stage *number* belongs to whichever stage is current and is
    asserted there; what must stay true here is that generation and
    citation validation are named as things this service does.
    """
    body = client.get("/").json()
    assert "generation" in body["stage"].lower()
    assert "citation" in body["scope"].lower()


def test_the_earlier_endpoints_still_work(indexed):
    """Stage 7 sits on top of 5 and 6; it does not replace them."""
    for path, payload in (
        ("/retrieve", {"query": QUESTION, "tenant_id": TENANT_A}),
        ("/context", {"query": QUESTION, "tenant_id": TENANT_A}),
    ):
        response = indexed.post(path, json=payload)
        assert response.status_code == 200, path


def test_a_newly_indexed_document_can_be_answered_from(client):
    from app.services.indexing import index_chunks

    set_llm_provider(StubProvider(answer_json("Notice is 120 days.", [1])))
    index_chunks(
        fixtures.make_chunks(
            fixtures.VENDOR_CONTRACT,
            document_id="doc-fresh",
            tenant_id="tenant-fresh",
            filename="fresh.pdf",
        )
    )
    body = client.post(
        "/answer", json={"query": QUESTION, "tenant_id": "tenant-fresh"}
    ).json()

    assert body["status"] == "ok"
    assert all(s["document_id"] == "doc-fresh" for s in body["sources"])
