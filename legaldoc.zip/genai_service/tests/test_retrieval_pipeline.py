"""Stage 5 — the retrieval pipeline end to end.

The unit suites cover each stage in isolation; this one covers the
contract the rest of the system depends on: what comes out, for whom,
with what metadata, and what happens when there is nothing to find.

A note on the embedding model these tests run against. The suite uses
the *deterministic* encoder — a lexical hashing function, not a semantic
model — because the real one cannot be downloaded in this environment.
So these tests never assert that retrieval *understands* a paraphrase;
that is a property of the embedding model, not of this pipeline, and
asserting it here would be asserting something the fixture cannot
deliver. What is asserted is everything the pipeline itself is
responsible for: scoping, filtering, ordering, metadata preservation,
duplicate removal, stage accounting and degradation.
"""

from __future__ import annotations

import pytest

from app.retrieval.base import SOURCE_KEYWORD, SOURCE_SEMANTIC
from app.retrieval.pipeline import HYBRID, KEYWORD_ONLY, SEMANTIC_ONLY, MODES
from app.retrieval.base import RetrievalError
from app.retrieval.rerank import LexicalReranker
from app.vectorstore.base import TenantScopeError
from tests import fixtures

TENANT_A = "tenant-a"
TENANT_B = "tenant-b"
QUERY = "How much notice is required to terminate for convenience?"


# ---------------------------------------------------------------------
# Semantic retrieval
# ---------------------------------------------------------------------


def test_semantic_only_mode_retrieves_from_the_vector_store(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A, mode=SEMANTIC_ONLY)
    assert outcome.results
    assert outcome.counts.semantic > 0
    assert outcome.counts.keyword == 0
    assert all(SOURCE_SEMANTIC in c.sources for c in outcome.results)


def test_semantic_retrieval_respects_the_candidate_pool(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(
        QUERY, TENANT_A, mode=SEMANTIC_ONLY, candidate_pool=3, top_k=3
    )
    assert outcome.counts.semantic <= 3


def test_semantic_scores_are_higher_is_better(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A, mode=SEMANTIC_ONLY)
    scores = [c.semantic_score for c in outcome.results]
    assert all(s >= 0 for s in scores)


# ---------------------------------------------------------------------
# Keyword retrieval
# ---------------------------------------------------------------------


def test_keyword_only_mode_retrieves_by_bm25(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A, mode=KEYWORD_ONLY)
    assert outcome.results
    assert outcome.counts.keyword > 0
    assert outcome.counts.semantic == 0
    assert all(SOURCE_KEYWORD in c.sources for c in outcome.results)


def test_keyword_retrieval_finds_the_termination_clause(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A, mode=KEYWORD_ONLY)
    assert outcome.results[0].chunk.section == "4. TERMINATION"


def test_keyword_retrieval_reports_the_corpus_it_scored(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A, mode=KEYWORD_ONLY)
    assert outcome.counts.corpus_size > 0


# ---------------------------------------------------------------------
# Hybrid merging
# ---------------------------------------------------------------------


def test_hybrid_mode_runs_both_retrievers(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A, mode=HYBRID)
    assert outcome.counts.semantic > 0
    assert outcome.counts.keyword > 0
    assert outcome.results


def test_hybrid_is_the_default_mode(lexical_pipeline):
    assert lexical_pipeline.retrieve(QUERY, TENANT_A).mode == HYBRID


def test_hybrid_retrieves_at_least_as_much_as_either_signal_alone(
    lexical_pipeline,
):
    """Fusion is a union, so recall cannot go down by adding a signal."""
    semantic = lexical_pipeline.retrieve(QUERY, TENANT_A, mode=SEMANTIC_ONLY)
    keyword = lexical_pipeline.retrieve(QUERY, TENANT_A, mode=KEYWORD_ONLY)
    hybrid = lexical_pipeline.retrieve(QUERY, TENANT_A, mode=HYBRID)
    assert hybrid.counts.fused >= max(
        semantic.counts.fused, keyword.counts.fused
    )


def test_agreement_between_retrievers_is_reported(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A, mode=HYBRID)
    assert 0.0 <= outcome.agreement <= 1.0


def test_an_unknown_mode_is_rejected(lexical_pipeline):
    with pytest.raises(RetrievalError) as excinfo:
        lexical_pipeline.retrieve(QUERY, TENANT_A, mode="telepathy")
    for mode in MODES:
        assert mode in str(excinfo.value)


# ---------------------------------------------------------------------
# Ranking and top-k
# ---------------------------------------------------------------------


def test_results_are_ordered_best_first(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A)
    scores = [c.final_score for c in outcome.results]
    assert scores == sorted(scores, reverse=True)


def test_ranks_are_contiguous_and_one_based(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A)
    assert [c.rank for c in outcome.results] == list(
        range(1, len(outcome.results) + 1)
    )


@pytest.mark.parametrize("top_k", [1, 3, 5, 8])
def test_top_k_is_configurable(lexical_pipeline, top_k):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A, top_k=top_k)
    assert len(outcome.results) <= top_k
    assert outcome.top_k == top_k


def test_the_candidate_pool_is_larger_than_the_returned_set(lexical_pipeline):
    """The point of the whole design: rerank from more than you return."""
    outcome = lexical_pipeline.retrieve(
        QUERY, TENANT_A, top_k=3, candidate_pool=15
    )
    assert outcome.candidate_pool == 15
    assert outcome.counts.fused > len(outcome.results)


def test_a_pool_smaller_than_top_k_is_raised_to_it(lexical_pipeline):
    """Reranking must never choose from fewer passages than it returns."""
    outcome = lexical_pipeline.retrieve(
        QUERY, TENANT_A, top_k=6, candidate_pool=2
    )
    assert outcome.candidate_pool == 6


def test_a_named_clause_is_promoted(lexical_pipeline):
    outcome = lexical_pipeline.retrieve("what does clause 7 say", TENANT_A)
    assert outcome.results[0].chunk.section == "7. GOVERNING LAW"
    assert outcome.results[0].pinned


def test_a_named_clause_beats_the_clause_that_merely_cites_it(lexical_pipeline):
    """Clause 7 of the fixture contract says "subject to the arbitration
    provisions in Clause 8", so it is the passage a term-overlap
    reranker prefers for a query about clause 8. Clause 8 must still
    come first."""
    outcome = lexical_pipeline.retrieve("what does clause 8 say", TENANT_A)
    assert outcome.results[0].chunk.section == "8. DISPUTE RESOLUTION"


def test_retrieval_is_deterministic(lexical_pipeline):
    first = lexical_pipeline.retrieve(QUERY, TENANT_A)
    second = lexical_pipeline.retrieve(QUERY, TENANT_A)
    assert [c.chunk_id for c in first.results] == [
        c.chunk_id for c in second.results
    ]


# ---------------------------------------------------------------------
# Metadata preservation
# ---------------------------------------------------------------------


def test_every_result_carries_full_provenance(lexical_pipeline):
    """A retrieved passage must be citable without a second lookup."""
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A)
    assert outcome.results
    for candidate in outcome.results:
        chunk = candidate.chunk
        assert chunk.chunk_id
        assert chunk.document_id
        assert chunk.tenant_id == TENANT_A
        assert chunk.filename
        assert chunk.page_number >= 1
        assert chunk.chunk_index >= 0
        assert chunk.document_type is not None
        citation = candidate.citation()
        assert set(citation) >= {"document_id", "filename", "page", "chunk_id"}


def test_section_labels_survive_the_whole_pipeline(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A)
    assert any(c.chunk.section for c in outcome.results)


def test_every_stage_score_is_available_for_explanation(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A)
    scores = outcome.results[0].scores()
    assert set(scores) >= {
        "semantic",
        "keyword",
        "fused",
        "ranked",
        "rerank",
        "final",
        "sources",
    }


# ---------------------------------------------------------------------
# Metadata filtering
# ---------------------------------------------------------------------


def test_document_type_filter_applies_to_both_retrievers(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A, document_type="nda")
    assert outcome.results
    assert all(c.chunk.document_id == "doc-nda" for c in outcome.results)


def test_document_ids_filter_restricts_the_search(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(
        QUERY, TENANT_A, document_ids=["doc-contract"]
    )
    assert outcome.results
    assert all(c.chunk.document_id == "doc-contract" for c in outcome.results)


def test_a_filter_matching_nothing_returns_nothing(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(
        QUERY, TENANT_A, document_ids=["doc-that-does-not-exist"]
    )
    assert outcome.results == []


def test_page_range_filter_is_applied(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A, page_range=(1, 1))
    assert all(c.chunk.page_number == 1 for c in outcome.results)


def test_the_filters_are_echoed_back(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A, document_type="contract")
    assert outcome.filters["tenant_id"] == TENANT_A
    assert outcome.filters["document_type"] == "contract"


# ---------------------------------------------------------------------
# Tenant isolation
# ---------------------------------------------------------------------


def test_results_never_cross_tenants(lexical_pipeline, corpus_chunks):
    """The failure that would end a legal product."""
    foreign_ids = {c.chunk_id for c in corpus_chunks["other_tenant"]}
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A)
    assert outcome.results
    assert not ({c.chunk_id for c in outcome.results} & foreign_ids)


def test_the_other_tenant_sees_only_its_own_copy(lexical_pipeline):
    """Both tenants hold the same contract text; each gets its own."""
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_B)
    assert outcome.results
    assert all(c.chunk.tenant_id == TENANT_B for c in outcome.results)
    assert all(c.chunk.document_id == "doc-rival" for c in outcome.results)


def test_a_tenant_with_no_documents_gets_nothing(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, "tenant-with-no-documents")
    assert outcome.results == []
    assert outcome.counts.returned == 0


@pytest.mark.parametrize("tenant", ["", "   ", None])
def test_retrieval_without_a_tenant_is_impossible(lexical_pipeline, tenant):
    """Not "should not" — cannot. SearchFilter refuses to construct."""
    with pytest.raises(TenantScopeError):
        lexical_pipeline.retrieve(QUERY, tenant)


def test_both_retrievers_are_scoped_not_just_the_vector_one(lexical_pipeline):
    """BM25 builds its corpus through the same filter, so a keyword-only
    query cannot leak either."""
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_B, mode=KEYWORD_ONLY)
    assert outcome.results
    assert all(c.chunk.tenant_id == TENANT_B for c in outcome.results)


# ---------------------------------------------------------------------
# Duplicate removal
# ---------------------------------------------------------------------


def test_a_re_uploaded_document_does_not_produce_duplicate_results(
    lexical_pipeline, indexed_store, embedder
):
    from app.embeddings.factory import embed_in_batches

    twin = fixtures.make_chunks(
        fixtures.VENDOR_CONTRACT,
        document_id="doc-contract-copy",
        tenant_id=TENANT_A,
        filename="vendor_contract_2024 (1).pdf",
        document_type="contract",
    )
    indexed_store.upsert(twin, embed_in_batches(embedder, [c.text for c in twin]))

    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A, top_k=6)
    assert outcome.counts.duplicates_removed > 0
    texts = [c.text for c in outcome.results]
    assert len(texts) == len(set(texts))


def test_the_collapsed_citation_is_still_reported(
    lexical_pipeline, indexed_store, embedder
):
    from app.embeddings.factory import embed_in_batches

    twin = fixtures.make_chunks(
        fixtures.VENDOR_CONTRACT,
        document_id="doc-contract-copy",
        tenant_id=TENANT_A,
        filename="copy.pdf",
    )
    indexed_store.upsert(twin, embed_in_batches(embedder, [c.text for c in twin]))

    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A, top_k=6)
    assert any(c.duplicates for c in outcome.results)


def test_deduplication_can_be_disabled_per_request(
    lexical_pipeline, indexed_store, embedder
):
    from app.embeddings.factory import embed_in_batches

    twin = fixtures.make_chunks(
        fixtures.VENDOR_CONTRACT,
        document_id="doc-contract-copy",
        tenant_id=TENANT_A,
        filename="copy.pdf",
    )
    indexed_store.upsert(twin, embed_in_batches(embedder, [c.text for c in twin]))

    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A, dedupe=False)
    assert outcome.counts.duplicates_removed == 0


# ---------------------------------------------------------------------
# Empty and irrelevant queries
# ---------------------------------------------------------------------


@pytest.mark.parametrize("query", ["", "   ", "\n\t "])
def test_an_empty_query_returns_nothing_and_says_why(lexical_pipeline, query):
    outcome = lexical_pipeline.retrieve(query, TENANT_A)
    assert outcome.results == []
    assert outcome.warnings
    assert "empty" in outcome.warnings[0].lower()


def test_an_empty_query_still_validates_the_tenant(lexical_pipeline):
    with pytest.raises(TenantScopeError):
        lexical_pipeline.retrieve("", "")


def test_an_irrelevant_query_matches_nothing_lexically(lexical_pipeline):
    """No contract clause is about baking, so BM25 finds nothing.

    ("schedule" would have matched "Schedule A" - a reminder that a
    lexical signal is literal, and that picking a genuinely unrelated
    query is part of writing the test honestly.)

    Vector search still returns its nearest neighbours — that is what a
    nearest-neighbour index does — so the honest test is that the
    *keyword* signal is silent and the scores are weak, not that the
    index refuses to answer.
    """
    outcome = lexical_pipeline.retrieve(
        "sourdough levain autolyse hydration", TENANT_A
    )
    assert outcome.counts.keyword == 0


def test_a_score_floor_filters_out_a_weak_match(lexical_pipeline):
    """How a caller turns 'nothing relevant' into an empty result set."""
    relevant = lexical_pipeline.retrieve(QUERY, TENANT_A, min_score=0.99)
    irrelevant = lexical_pipeline.retrieve(
        "sourdough levain autolyse hydration", TENANT_A, min_score=0.99
    )
    assert len(irrelevant.results) <= len(relevant.results)
    assert all(c.final_score >= 0.99 for c in irrelevant.results)


def test_an_empty_index_returns_nothing_without_error(
    settings, embedder, memory_store
):
    from app.retrieval.pipeline import RetrievalPipeline

    pipeline = RetrievalPipeline(
        settings=settings,
        model=embedder,
        store=memory_store,
        reranker=LexicalReranker(),
    )
    outcome = pipeline.retrieve(QUERY, TENANT_A)
    assert outcome.results == []
    assert outcome.counts.fused == 0


# ---------------------------------------------------------------------
# Reranking within the pipeline
# ---------------------------------------------------------------------


def test_reranking_runs_and_is_reported(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A)
    assert outcome.reranked
    assert outcome.reranker
    # The fixture uses the fallback, and the outcome says so plainly.
    assert outcome.rerank_is_cross_encoder is False


def test_reranking_can_be_disabled_per_request(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A, rerank=False)
    assert not outcome.reranked
    assert outcome.reranker == "disabled"
    assert outcome.results
    assert all(c.rerank_score is None for c in outcome.results)


def test_a_failing_reranker_degrades_to_retrieval_order(
    settings, embedder, indexed_store
):
    """A reranker blowing up must not discard retrieval that succeeded."""
    from app.retrieval.pipeline import RetrievalPipeline
    from app.retrieval.rerank import Reranker

    class Exploding(Reranker):
        name = "exploding"
        model_id = "test"

        def score(self, query, passages):
            raise RuntimeError("model went away")

    pipeline = RetrievalPipeline(
        settings=settings,
        model=embedder,
        store=indexed_store,
        reranker=Exploding(),
    )
    outcome = pipeline.retrieve(QUERY, TENANT_A)

    assert outcome.results
    assert not outcome.reranked
    assert any("Reranking failed" in w for w in outcome.warnings)


# ---------------------------------------------------------------------
# Observability
# ---------------------------------------------------------------------


def test_every_stage_is_timed(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A)
    for stage in ("preprocess", "semantic", "keyword", "fusion", "rank", "rerank"):
        assert stage in outcome.timings_ms
    assert outcome.duration_ms >= 0


def test_stage_counts_are_consistent(lexical_pipeline):
    outcome = lexical_pipeline.retrieve(QUERY, TENANT_A, top_k=4)
    counts = outcome.counts
    assert counts.fused >= counts.after_dedupe >= counts.returned
    assert counts.returned == len(outcome.results)


def test_the_outcome_serialises(lexical_pipeline):
    data = lexical_pipeline.retrieve(QUERY, TENANT_A).to_dict(explain=True)
    assert data["results"]
    assert "scores" in data["results"][0]
    assert data["counts"]["returned"] == len(data["results"])
