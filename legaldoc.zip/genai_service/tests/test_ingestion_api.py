"""HTTP layer for Stage 2 — the contract the MERN backend calls."""

from __future__ import annotations

import pytest


def _payload(path, **kwargs) -> dict:
    body = {
        "document_id": "doc-api-1",
        "tenant_id": "tenant-alpha",
        "file_path": path.name,
    }
    body.update(kwargs)
    return body


# =====================================================================
# Extract by path
# =====================================================================


def test_extract_returns_the_documented_shape(client, contract_pdf):
    response = client.post("/documents/extract", json=_payload(contract_pdf))
    assert response.status_code == 200

    body = response.json()
    assert body["status"] == "success"
    assert body["metadata"]["document_id"] == "doc-api-1"
    assert body["metadata"]["tenant_id"] == "tenant-alpha"
    assert body["metadata"]["content_sha256"]
    assert body["stats"]["parser"] == "pymupdf"
    assert body["stats"]["page_count"] >= 1
    assert body["stats"]["method"] in {"native", "ocr", "mixed", "none"}
    assert body["pages"][0]["page_number"] == 1
    assert body["pages"][0]["text"]


def test_extract_omits_blocks_by_default(client, contract_pdf):
    body = client.post("/documents/extract", json=_payload(contract_pdf)).json()
    assert body["pages"][0]["blocks"] is None


def test_extract_can_include_blocks(client, contract_pdf):
    body = client.post(
        "/documents/extract", json=_payload(contract_pdf, include_blocks=True)
    ).json()
    blocks = body["pages"][0]["blocks"]
    assert blocks
    assert blocks[0]["block_id"]
    assert blocks[0]["kind"] in {"heading", "paragraph", "table", "list_item", "caption"}


def test_extract_can_omit_text(client, contract_pdf):
    """Metadata-only mode, for a backend that just wants the stats."""
    body = client.post(
        "/documents/extract", json=_payload(contract_pdf, include_text=False)
    ).json()
    assert body["pages"][0]["text"] == ""
    assert body["stats"]["char_count"] > 0


def test_extract_reports_sections(client, multipage_pdf):
    body = client.post("/documents/extract", json=_payload(multipage_pdf)).json()
    assert body["sections"]


def test_extract_docx(client, nda_docx):
    body = client.post("/documents/extract", json=_payload(nda_docx)).json()
    assert body["stats"]["parser"] == "python-docx"
    assert body["metadata"]["document_type"] == "nda"
    assert body["pages"][0]["synthetic"] is True


def test_extract_passes_through_extra_metadata(client, contract_pdf):
    response = client.post(
        "/documents/extract",
        json=_payload(contract_pdf, metadata={"matter_id": "M-99"}),
    )
    assert response.status_code == 200


# =====================================================================
# Error responses
# =====================================================================


def test_corrupt_document_returns_422_in_the_error_envelope(client, corrupt_pdf):
    response = client.post("/documents/extract", json=_payload(corrupt_pdf))
    assert response.status_code == 422
    body = response.json()
    assert body["error"]["type"] == "corrupt_document"
    assert body["request_id"]


def test_unsupported_type_returns_415(client, unsupported_file):
    response = client.post("/documents/extract", json=_payload(unsupported_file))
    assert response.status_code == 415
    assert response.json()["error"]["type"] == "unsupported_file_type"


def test_empty_document_returns_422(client, blank_pdf):
    response = client.post("/documents/extract", json=_payload(blank_pdf))
    assert response.status_code == 422
    assert response.json()["error"]["type"] == "empty_document"


def test_missing_file_returns_404(client):
    response = client.post(
        "/documents/extract",
        json={
            "document_id": "d",
            "tenant_id": "t",
            "file_path": "nope.pdf",
        },
    )
    assert response.status_code == 404
    assert response.json()["error"]["type"] == "document_not_found"


def test_path_traversal_returns_400(client):
    response = client.post(
        "/documents/extract",
        json={
            "document_id": "d",
            "tenant_id": "t",
            "file_path": "../../etc/passwd",
        },
    )
    assert response.status_code == 400
    assert response.json()["error"]["type"] == "unsafe_path"


def test_spoofed_extension_returns_415(client, fake_pdf):
    response = client.post("/documents/extract", json=_payload(fake_pdf))
    assert response.status_code == 415


def test_missing_required_field_returns_422_validation(client):
    response = client.post("/documents/extract", json={"document_id": "d"})
    assert response.status_code == 422
    body = response.json()
    assert body["error"]["type"] == "validation_error"
    fields = {f["field"] for f in body["error"]["details"]["fields"]}
    assert "tenant_id" in fields and "file_path" in fields


def test_an_error_never_leaks_a_filesystem_path(client):
    response = client.post(
        "/documents/extract",
        json={"document_id": "d", "tenant_id": "t", "file_path": "../../etc/passwd"},
    )
    assert "/etc/passwd" not in response.text
    assert "/home/" not in response.text


# =====================================================================
# Batch
# =====================================================================


def test_batch_isolates_failures(client, contract_pdf, corrupt_pdf, nda_docx):
    response = client.post(
        "/documents/extract/batch",
        json={
            "documents": [
                _payload(contract_pdf, document_id="b-ok-1"),
                _payload(corrupt_pdf, document_id="b-bad-1"),
                _payload(nda_docx, document_id="b-ok-2"),
            ]
        },
    )
    assert response.status_code == 200

    body = response.json()
    assert body["total"] == 3
    assert body["succeeded"] == 2
    assert body["failed"] == 1

    failed = next(r for r in body["results"] if r["status"] == "failed")
    assert failed["document_id"] == "b-bad-1"
    assert failed["error"]["type"] == "corrupt_document"
    assert failed["stats"] is None

    succeeded = next(r for r in body["results"] if r["document_id"] == "b-ok-1")
    assert succeeded["stats"]["page_count"] >= 1
    assert succeeded["error"] is None


def test_batch_preserves_request_order(client, contract_pdf, nda_docx):
    body = client.post(
        "/documents/extract/batch",
        json={
            "documents": [
                _payload(contract_pdf, document_id="first"),
                _payload(nda_docx, document_id="second"),
            ]
        },
    ).json()
    assert [r["document_id"] for r in body["results"]] == ["first", "second"]


def test_batch_rejects_an_empty_list(client):
    assert client.post("/documents/extract/batch", json={"documents": []}).status_code == 422


# =====================================================================
# Upload
# =====================================================================


def test_upload_extracts_a_streamed_pdf(client, contract_pdf):
    with contract_pdf.open("rb") as handle:
        response = client.post(
            "/documents/extract/upload",
            files={"file": (contract_pdf.name, handle, "application/pdf")},
            data={"document_id": "up-1", "tenant_id": "tenant-up"},
        )
    assert response.status_code == 200
    body = response.json()
    assert body["metadata"]["filename"] == contract_pdf.name
    assert body["stats"]["page_count"] >= 1


def test_upload_rejects_an_unsupported_type(client):
    import io

    response = client.post(
        "/documents/extract/upload",
        files={"file": ("notes.txt", io.BytesIO(b"plain text"), "text/plain")},
        data={"document_id": "up-2", "tenant_id": "tenant-up"},
    )
    assert response.status_code == 415


def test_upload_ignores_a_traversal_attempt_in_the_filename(client, contract_pdf):
    """Only the basename is trusted."""
    with contract_pdf.open("rb") as handle:
        response = client.post(
            "/documents/extract/upload",
            files={
                "file": ("../../../evil.pdf", handle, "application/pdf")
            },
            data={"document_id": "up-3", "tenant_id": "tenant-up"},
        )
    assert response.status_code == 200
    assert response.json()["metadata"]["filename"] == "evil.pdf"


def test_upload_leaves_no_temp_file_behind(client, contract_pdf, settings):
    before = set(settings.temp_dir_path.iterdir())
    with contract_pdf.open("rb") as handle:
        client.post(
            "/documents/extract/upload",
            files={"file": (contract_pdf.name, handle, "application/pdf")},
            data={"document_id": "up-4", "tenant_id": "tenant-up"},
        )
    assert set(settings.temp_dir_path.iterdir()) == before


def test_upload_of_a_corrupt_file_still_cleans_up(client, corrupt_pdf, settings):
    before = set(settings.temp_dir_path.iterdir())
    with corrupt_pdf.open("rb") as handle:
        response = client.post(
            "/documents/extract/upload",
            files={"file": ("broken.pdf", handle, "application/pdf")},
            data={"document_id": "up-5", "tenant_id": "tenant-up"},
        )
    assert response.status_code == 422
    assert set(settings.temp_dir_path.iterdir()) == before


def test_upload_rejects_a_bad_identifier(client, contract_pdf):
    with contract_pdf.open("rb") as handle:
        response = client.post(
            "/documents/extract/upload",
            files={"file": (contract_pdf.name, handle, "application/pdf")},
            data={"document_id": "up-6", "tenant_id": "bad/tenant"},
        )
    assert response.status_code == 400


# =====================================================================
# Formats and health
# =====================================================================


def test_formats_endpoint(client, settings):
    body = client.get("/documents/formats").json()
    assert body["extensions"] == settings.allowed_extension_list
    assert body["max_file_size_mb"] == settings.max_file_size_mb
    assert isinstance(body["ocr_available"], bool)


def test_health_reports_the_ingestion_component(client):
    components = {c["name"]: c for c in client.get("/health").json()["components"]}
    assert "ingestion" in components
    assert components["ingestion"]["status"] == "ok"
    assert ".pdf" in components["ingestion"]["detail"]


def test_health_reports_the_ocr_component(client):
    components = {c["name"]: c for c in client.get("/health").json()["components"]}
    assert "ocr" in components
    assert components["ocr"]["status"] in {"ok", "degraded"}


def test_missing_ocr_degrades_but_does_not_break_health(
    client_factory, make_settings, monkeypatch
):
    """OCR is an enhancement; without it the service still serves."""
    import app.ingestion.ocr as ocr_module

    monkeypatch.setattr(ocr_module, "ocr_available", lambda settings=None: False)
    with client_factory(make_settings(ocr_enabled=True)) as c:
        body = c.get("/health").json()
        assert body["status"] == "degraded"
        assert c.get("/health/ready").json()["ready"] is True

    components = {c["name"]: c for c in body["components"]}
    assert components["ocr"]["status"] == "degraded"


def test_ocr_disabled_is_reported_as_ok(client_factory, make_settings):
    with client_factory(make_settings(ocr_enabled=False)) as c:
        components = {c["name"]: c for c in c.get("/health").json()["components"]}
    assert components["ocr"]["status"] == "ok"
    assert "disabled" in components["ocr"]["detail"]


# =====================================================================
# Auth
# =====================================================================


def test_document_endpoints_require_the_service_token(
    client_factory, make_settings, contract_pdf
):
    with client_factory(make_settings(service_token="s3cret")) as c:
        unauthorised = c.post("/documents/extract", json=_payload(contract_pdf))
        assert unauthorised.status_code == 401

        authorised = c.post(
            "/documents/extract",
            json=_payload(contract_pdf),
            headers={"X-Service-Token": "s3cret"},
        )
        assert authorised.status_code == 200


def test_openapi_documents_the_stage_2_endpoints(client):
    paths = client.get("/openapi.json").json()["paths"]
    for path in (
        "/documents/extract",
        "/documents/extract/batch",
        "/documents/extract/upload",
        "/documents/formats",
    ):
        assert path in paths
