"""Synthetic legal documents for the test suite.

Every fixture is generated at test time from **invented** parties,
amounts and clauses. No real or confidential legal material is used
anywhere in this repository.

The generators are here rather than in ``conftest.py`` so tests can also
build one-off variants (a two-page contract, a footer-heavy scan) inline.
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, List, Sequence, Tuple

Section = Tuple[str, str]

# ---------------------------------------------------------------------
# Content
# ---------------------------------------------------------------------

VENDOR_CONTRACT: List[Section] = [
    (
        "1. DEFINITIONS",
        'In this Agreement, "Services" means the managed hosting services '
        'described in Schedule A. "Vendor" means Northwind Systems Private '
        'Limited. "Client" means Harbour Legal LLP. "Effective Date" means '
        "1 March 2024.",
    ),
    (
        "2. TERM",
        "This Agreement commences on the Effective Date and continues for an "
        "initial period of thirty-six (36) months, renewing automatically for "
        "successive twelve (12) month periods unless either party gives "
        "written notice of non-renewal at least ninety (90) days before the "
        "end of the then-current period.",
    ),
    (
        "3. FEES AND PAYMENT",
        "The Client shall pay the Vendor a monthly fee of INR 4,50,000 within "
        "thirty (30) days of receipt of a valid invoice. Late payments accrue "
        "interest at 1.5% per month. All fees are exclusive of applicable "
        "taxes.",
    ),
    (
        "4. TERMINATION",
        "Either party may terminate this Agreement for convenience on one "
        "hundred and twenty (120) days written notice to the other party. "
        "Either party may terminate immediately by written notice if the "
        "other party commits a material breach which is not remedied within "
        "thirty (30) days of notice of that breach, or becomes insolvent. On "
        "termination the Vendor shall return all Client data within fifteen "
        "(15) days.",
    ),
    (
        "5. LIMITATION OF LIABILITY",
        "The aggregate liability of either party arising out of or in "
        "connection with this Agreement shall not exceed the total fees paid "
        "in the twelve (12) months preceding the event giving rise to the "
        "claim. Neither party excludes liability for fraud or for death or "
        "personal injury caused by negligence.",
    ),
    (
        "6. CONFIDENTIALITY",
        "Each party shall keep confidential all Confidential Information of "
        "the other party and shall not disclose it to any third party except "
        "to its personnel who need to know it for the purposes of this "
        "Agreement. This obligation survives termination for five (5) years.",
    ),
    (
        "7. GOVERNING LAW",
        "This Agreement is governed by the laws of India. The courts at "
        "Bengaluru have exclusive jurisdiction, subject to the arbitration "
        "provisions in Clause 8.",
    ),
    (
        "8. DISPUTE RESOLUTION",
        "Any dispute arising out of this Agreement shall be referred to "
        "arbitration seated in Bengaluru under the Arbitration and "
        "Conciliation Act, before a sole arbitrator appointed jointly by the "
        "parties.",
    ),
]

MUTUAL_NDA: List[Section] = [
    (
        "1. PURPOSE",
        "Meridian Analytics Inc. and Cobalt Ventures LLC wish to explore a "
        "potential commercial relationship and will exchange confidential "
        "information for that purpose only.",
    ),
    (
        "2. CONFIDENTIAL INFORMATION",
        "Confidential Information means any non-public information disclosed "
        "by either party, whether orally or in writing, that is designated as "
        "confidential or would reasonably be understood to be confidential.",
    ),
    (
        "3. TERMINATION",
        "This Agreement terminates two (2) years from the date of signature. "
        "The confidentiality obligations survive for a further three (3) "
        "years after termination.",
    ),
    (
        "4. GOVERNING LAW",
        "This Agreement is governed by the laws of the State of Delaware.",
    ),
]

SCANNED_AWARD_LINES = [
    "ARBITRAL AWARD",
    "In the matter between Calder Shipping Ltd and Pentland Freight AG",
    "The Tribunal awards damages of USD 250,000 to the Claimant.",
    "Costs shall be borne equally by the parties.",
]


# ---------------------------------------------------------------------
# Generators
# ---------------------------------------------------------------------


def make_pdf(
    path: Path,
    title: str,
    sections: Sequence[Section],
    footer: str = "",
    page_break_every: int = 0,
) -> Path:
    """Render a text-layer PDF with reportlab.

    ``footer`` is stamped on every page together with a page number, so
    the running-header/footer detector has something real to find.
    ``page_break_every`` forces a new page after N sections, which is how
    the multi-page fixture is built deterministically.
    """
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas

    width, height = A4
    pdf = canvas.Canvas(str(path), pagesize=A4)
    margin, leading = 60, 14
    y = height - margin

    def stamp_footer() -> None:
        if not footer:
            return
        pdf.setFont("Helvetica", 8)
        pdf.drawString(margin, 30, footer)
        pdf.drawString(width - margin - 50, 30, f"Page {pdf.getPageNumber()}")

    def new_page() -> None:
        nonlocal y
        stamp_footer()
        pdf.showPage()
        y = height - margin

    pdf.setFont("Helvetica-Bold", 14)
    pdf.drawString(margin, y, title)
    y -= leading * 2

    for index, (heading, body) in enumerate(sections):
        if page_break_every and index and index % page_break_every == 0:
            new_page()
        if y < margin + leading * 6:
            new_page()

        pdf.setFont("Helvetica-Bold", 11)
        pdf.drawString(margin, y, heading)
        y -= leading

        pdf.setFont("Helvetica", 10)
        line = ""
        for word in body.split():
            if len(line) + len(word) + 1 > 95:
                pdf.drawString(margin, y, line)
                y -= leading
                line = word
                if y < margin + leading * 3:
                    new_page()
                    pdf.setFont("Helvetica", 10)
            else:
                line = f"{line} {word}".strip()
        if line:
            pdf.drawString(margin, y, line)
            y -= leading
        y -= leading

    stamp_footer()
    pdf.save()
    return path


def make_docx(
    path: Path,
    title: str,
    sections: Sequence[Section],
    with_table: bool = True,
) -> Path:
    """Write a DOCX with real heading styles and a table."""
    import docx

    document = docx.Document()
    document.add_heading(title, level=0)
    for heading, body in sections:
        document.add_heading(heading, level=1)
        document.add_paragraph(body)

    if with_table:
        document.add_heading("5. NOTICES", level=1)
        table = document.add_table(rows=3, cols=2)
        table.cell(0, 0).text = "Party"
        table.cell(0, 1).text = "Notice Address"
        table.cell(1, 0).text = "Meridian Analytics Inc."
        table.cell(1, 1).text = "44 Ridgeway Road, Wilmington, DE"
        table.cell(2, 0).text = "Cobalt Ventures LLC"
        table.cell(2, 1).text = "9 Beacon Street, Boston, MA"

    document.save(str(path))
    return path


def make_docx_with_page_breaks(path: Path, sections: Sequence[Section]) -> Path:
    """A DOCX with explicit page breaks between sections."""
    import docx
    from docx.enum.text import WD_BREAK

    document = docx.Document()
    for index, (heading, body) in enumerate(sections):
        if index:
            paragraph = document.add_paragraph()
            paragraph.add_run().add_break(WD_BREAK.PAGE)
        document.add_heading(heading, level=1)
        document.add_paragraph(body)
    document.save(str(path))
    return path


def make_scanned_pdf(path: Path, lines: Iterable[str] = ()) -> Path:
    """A PDF whose pages are images of text — no text layer at all.

    Rendered large and high-contrast so Tesseract has a fair chance;
    the tests that depend on OCR output skip when Tesseract is absent.
    """
    from PIL import Image, ImageDraw, ImageFont

    lines = list(lines) or SCANNED_AWARD_LINES
    image = Image.new("RGB", (1700, 240 + 60 * len(lines)), "white")
    draw = ImageDraw.Draw(image)

    font = None
    for candidate in (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    ):
        if Path(candidate).exists():
            font = ImageFont.truetype(candidate, 34)
            break

    y = 60
    for line in lines:
        draw.text((60, y), line, fill="black", font=font)
        y += 60

    image.save(str(path), "PDF", resolution=150.0)
    return path


def make_blank_pdf(path: Path, pages: int = 2) -> Path:
    """A structurally valid PDF with no text on any page."""
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas

    pdf = canvas.Canvas(str(path), pagesize=A4)
    for _ in range(pages):
        pdf.showPage()
    pdf.save()
    return path


def make_empty_docx(path: Path) -> Path:
    """A valid DOCX containing no text."""
    import docx

    docx.Document().save(str(path))
    return path


def make_corrupt_pdf(path: Path) -> Path:
    """Correct PDF magic bytes, truncated body — passes validation,
    fails parsing. That split is the point of the fixture."""
    path.write_bytes(
        b"%PDF-1.4\n1 0 obj\n<< /Type /Catalog >>\nendobj\n"
        b"truncated before the xref table"
    )
    return path


def make_corrupt_docx(path: Path) -> Path:
    """ZIP magic bytes, not a real OOXML package."""
    path.write_bytes(b"PK\x03\x04" + b"\x00" * 64 + b"not a real docx package")
    return path


def make_fake_pdf(path: Path) -> Path:
    """A .pdf extension over content that is not a PDF at all."""
    path.write_bytes(b"This is plain text pretending to be a PDF document.")
    return path


def make_unsupported_file(path: Path) -> Path:
    path.write_text("Plain text notes about a matter.\n", encoding="utf-8")
    return path


# ---------------------------------------------------------------------
# Stage 5 — chunks without a document round-trip
# ---------------------------------------------------------------------


def make_chunks(
    sections: Sequence[Section] = (),
    document_id: str = "doc-contract",
    tenant_id: str = "tenant-a",
    filename: str = "vendor_contract_2024.pdf",
    document_type: str = "contract",
    start_page: int = 1,
    start_index: int = 0,
):
    """Build :class:`Chunk` objects straight from section text.

    Retrieval tests care about *what is in the index*, not about how it
    got there — extraction and chunking have their own suites. Building
    chunks directly keeps these tests fast, deterministic and focused on
    the stage under test, and it makes the corpus readable in the test
    that uses it.
    """
    from app.models.chunk import Chunk, make_chunk_id
    from app.models.document import DocumentType

    try:
        kind = DocumentType(document_type)
    except ValueError:
        kind = DocumentType.UNKNOWN

    out = []
    for offset, (heading, body) in enumerate(sections or VENDOR_CONTRACT):
        index = start_index + offset
        text = f"{heading}\n\n{body}"
        out.append(
            Chunk(
                chunk_id=make_chunk_id(document_id, index, text),
                chunk_index=index,
                text=text,
                document_id=document_id,
                tenant_id=tenant_id,
                filename=filename,
                page_number=start_page + (offset // 3),
                document_type=kind,
                section=heading,
                token_count=max(1, len(text.split())),
            )
        )
    return out


# ---------------------------------------------------------------------
# Stage 7 — a scriptable LLM provider
# ---------------------------------------------------------------------


class StubProvider:
    """An :class:`~app.generation.base.LLMProvider` that returns a script.

    Generation tests need to control exactly what the model says — a
    perfect answer, an invented citation, a truncated JSON object, an
    outage. A stub returning scripted replies does that; the *real*
    provider code paths (request building, HTTP, error mapping) are
    exercised separately against ``httpx.MockTransport``, so nothing is
    mocked twice and nothing important is mocked away.
    """

    name = "stub"
    model = "stub-1"
    is_language_model = True
    requires_key = False

    def __init__(self, replies=(), raises=None, model: str = "stub-1"):
        if isinstance(replies, str):
            replies = [replies]
        self.replies = list(replies)
        self.raises = raises
        self.model = model
        #: Every request the service made, for asserting on the prompt.
        self.calls = []

    def describe(self) -> str:
        return f"{self.name}:{self.model}"

    def check(self) -> None:
        return None

    def generate(self, request):
        from app.generation.base import LLMResponse

        self.calls.append(request)
        if self.raises is not None:
            raise self.raises
        if not self.replies:
            raise AssertionError("StubProvider ran out of scripted replies")
        text = self.replies.pop(0) if len(self.replies) > 1 else self.replies[0]
        return LLMResponse(
            text=text,
            model=self.model,
            provider=self.name,
            finish_reason="stop",
            prompt_tokens=100,
            completion_tokens=50,
        )


def answer_json(answer: str, sources=(), insufficient: bool = False,
                interpretation: str = "") -> str:
    """Build a well-formed model reply."""
    import json

    return json.dumps(
        {
            "answer": answer,
            "citations": [{"source": n} for n in sources],
            "insufficient_evidence": insufficient,
            "interpretation": interpretation,
        }
    )


__all__ = [
    "VENDOR_CONTRACT",
    "MUTUAL_NDA",
    "SCANNED_AWARD_LINES",
    "make_chunks",
    "StubProvider",
    "answer_json",
    "make_pdf",
    "make_docx",
    "make_docx_with_page_breaks",
    "make_scanned_pdf",
    "make_blank_pdf",
    "make_empty_docx",
    "make_corrupt_pdf",
    "make_corrupt_docx",
    "make_fake_pdf",
    "make_unsupported_file",
]
