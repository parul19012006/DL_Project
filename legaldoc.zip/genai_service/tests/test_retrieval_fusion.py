"""Stage 5 — hybrid merging and candidate ranking.

Fusion is where the two incompatible score scales are reconciled, and
ranking is where the signals fusion cannot see are applied. Both are
pure functions over candidates, so they are tested directly on
hand-built inputs where the expected ordering is obvious by inspection.
"""

from __future__ import annotations

import pytest

from app.models.chunk import Chunk, make_chunk_id
from app.models.document import DocumentType
from app.retrieval.base import SOURCE_KEYWORD, SOURCE_SEMANTIC, Candidate
from app.retrieval.fusion import (
    RRF,
    WEIGHTED,
    agreement_ratio,
    fuse,
    reciprocal_rank_fusion,
    weighted_fusion,
)
from app.retrieval.base import RetrievalError
from app.retrieval.query import preprocess_query
from app.retrieval.rank import rank_candidates


def _chunk(index: int, text: str, section: str = "", heading_only: bool = False):
    return Chunk(
        chunk_id=make_chunk_id("doc-1", index, text),
        chunk_index=index,
        text=text,
        document_id="doc-1",
        tenant_id="tenant-a",
        filename="contract.pdf",
        page_number=1 + index,
        document_type=DocumentType.CONTRACT,
        section=section or None,
        heading_only=heading_only,
        token_count=len(text.split()),
    )


def _semantic(index: int, rank: int, score: float = 0.8, **kwargs) -> Candidate:
    return Candidate(
        chunk=_chunk(index, kwargs.pop("text", f"passage {index}"), **kwargs),
        semantic_score=score,
        semantic_rank=rank,
        sources={SOURCE_SEMANTIC},
    )


def _keyword(index: int, rank: int, score: float = 0.7, **kwargs) -> Candidate:
    return Candidate(
        chunk=_chunk(index, kwargs.pop("text", f"passage {index}"), **kwargs),
        keyword_score=score,
        keyword_score_raw=score * 10,
        keyword_rank=rank,
        sources={SOURCE_KEYWORD},
    )


# ---------------------------------------------------------------------
# Merging mechanics
# ---------------------------------------------------------------------


def test_the_same_chunk_from_both_retrievers_is_merged_once():
    merged = fuse([_semantic(1, 1)], [_keyword(1, 1)])
    assert len(merged) == 1
    assert merged[0].sources == {SOURCE_SEMANTIC, SOURCE_KEYWORD}


def test_merging_keeps_both_signals():
    merged = fuse([_semantic(1, 2, score=0.9)], [_keyword(1, 5, score=0.4)])
    candidate = merged[0]
    assert candidate.semantic_rank == 2
    assert candidate.keyword_rank == 5
    assert candidate.semantic_score == pytest.approx(0.9)
    assert candidate.keyword_score == pytest.approx(0.4)


def test_distinct_chunks_from_both_lists_all_survive():
    merged = fuse([_semantic(1, 1), _semantic(2, 2)], [_keyword(3, 1)])
    assert len({c.chunk_id for c in merged}) == 3


def test_metadata_survives_fusion():
    """Nothing in the pipeline may reduce a chunk to a string."""
    merged = fuse([_semantic(4, 1, section="4. TERMINATION")], [])
    chunk = merged[0].chunk
    assert chunk.document_id == "doc-1"
    assert chunk.section == "4. TERMINATION"
    assert chunk.page_number == 5
    assert chunk.chunk_id


# ---------------------------------------------------------------------
# Reciprocal rank fusion
# ---------------------------------------------------------------------


def test_rrf_prefers_agreement_over_a_single_strong_signal():
    """The behaviour that justifies hybrid retrieval.

    A passage both retrievers found, at ranks 2 and 3, beats one only
    the vector search found — even at rank 1.
    """
    semantic = [_semantic(1, 1), _semantic(2, 2)]
    keyword = [_keyword(2, 3)]

    merged = reciprocal_rank_fusion(semantic, keyword, k=60)
    assert merged[0].chunk.chunk_index == 2
    assert merged[0].matched_both


def test_rrf_ignores_the_magnitude_of_the_scores():
    """Only positions count, so an unbounded BM25 score cannot dominate."""
    semantic = [_semantic(1, 1, score=0.01)]
    keyword = [_keyword(2, 1, score=999.0)]
    merged = reciprocal_rank_fusion(
        semantic, keyword, k=60, semantic_weight=1.0, keyword_weight=1.0
    )
    assert merged[0].fused_score == merged[1].fused_score


def test_rrf_k_damps_the_gap_between_top_ranks():
    small_k = reciprocal_rank_fusion(
        [_semantic(1, 1), _semantic(2, 2)], [], k=1
    )
    large_k = reciprocal_rank_fusion(
        [_semantic(1, 1), _semantic(2, 2)], [], k=1000
    )
    small_gap = small_k[0].boosts["rrf_raw"] - small_k[1].boosts["rrf_raw"]
    large_gap = large_k[0].boosts["rrf_raw"] - large_k[1].boosts["rrf_raw"]
    assert large_gap < small_gap


def test_fused_scores_are_normalised_into_the_unit_interval():
    """So the ranking stage's additive boosts are on the same scale."""
    merged = reciprocal_rank_fusion(
        [_semantic(i, i) for i in range(1, 6)], [_keyword(3, 1)]
    )
    assert all(0.0 <= c.fused_score <= 1.0 for c in merged)
    assert merged[0].fused_score == pytest.approx(1.0)


# ---------------------------------------------------------------------
# Weighted fusion
# ---------------------------------------------------------------------


def test_weighted_fusion_respects_its_weights():
    semantic = [_semantic(1, 1, score=1.0)]
    keyword = [_keyword(2, 1, score=1.0)]

    semantic_heavy = weighted_fusion(
        semantic, keyword, semantic_weight=0.9, keyword_weight=0.1
    )
    assert semantic_heavy[0].chunk.chunk_index == 1

    keyword_heavy = weighted_fusion(
        [_semantic(1, 1, score=1.0)],
        [_keyword(2, 1, score=1.0)],
        semantic_weight=0.1,
        keyword_weight=0.9,
    )
    assert keyword_heavy[0].chunk.chunk_index == 2


def test_weighted_fusion_rejects_zero_weights():
    with pytest.raises(RetrievalError):
        weighted_fusion([_semantic(1, 1)], [], 0.0, 0.0)


def test_unknown_fusion_method_is_rejected_with_the_options():
    with pytest.raises(RetrievalError) as excinfo:
        fuse([], [], method="magic")
    assert "rrf" in str(excinfo.value)


# ---------------------------------------------------------------------
# Degenerate inputs
# ---------------------------------------------------------------------


@pytest.mark.parametrize("method", [RRF, WEIGHTED])
def test_fusion_of_two_empty_lists_is_empty(method):
    assert fuse([], [], method=method) == []


@pytest.mark.parametrize("method", [RRF, WEIGHTED])
def test_a_single_signal_still_produces_ordered_results(method):
    """A query with no content terms produces no keyword run; retrieval
    must still work rather than collapsing."""
    merged = fuse([_semantic(1, 1), _semantic(2, 2)], [], method=method)
    assert [c.chunk.chunk_index for c in merged] == [1, 2]


def test_agreement_ratio_reports_the_overlap():
    merged = fuse([_semantic(1, 1), _semantic(2, 2)], [_keyword(1, 1)])
    assert agreement_ratio(merged) == pytest.approx(0.5)
    assert agreement_ratio([]) == 0.0


# ---------------------------------------------------------------------
# Candidate ranking
# ---------------------------------------------------------------------


def test_a_named_clause_beats_a_better_fused_score():
    """The user said "clause 4". Vector similarity does not get a vote."""
    wrong = _semantic(1, 1, section="2. TERM")
    right = _semantic(2, 8, section="4. TERMINATION")
    merged = fuse([wrong, right], [])
    assert merged[0].chunk.section == "2. TERM"  # before ranking

    ranked = rank_candidates(merged, preprocess_query("what does clause 4 say"))
    assert ranked[0].chunk.section == "4. TERMINATION"
    assert ranked[0].boosts["reference"] > 0


def test_naming_a_clause_pins_the_clause_itself():
    """Being the named clause is a lookup, not a ranking opinion."""
    is_clause = _semantic(1, 9, section="8. DISPUTE RESOLUTION", text="Arbitration.")
    mentions = _semantic(
        2, 1, section="7. GOVERNING LAW", text="subject to arbitration in Clause 8."
    )
    ranked = rank_candidates(
        fuse([is_clause, mentions], []), preprocess_query("clause 8")
    )
    assert ranked[0].pinned is True
    assert ranked[0].chunk.section == "8. DISPUTE RESOLUTION"
    # Merely mentioning the clause is a boost, not a pin.
    assert ranked[1].pinned is False
    assert ranked[1].boosts["reference"] > 0


def test_nothing_is_pinned_when_the_query_names_no_clause():
    ranked = rank_candidates(
        fuse([_semantic(1, 1, section="4. TERMINATION")], []),
        preprocess_query("how do I end the agreement"),
    )
    assert ranked[0].pinned is False


def test_being_the_clause_beats_mentioning_the_clause():
    is_clause = _semantic(1, 2, section="8. DISPUTE RESOLUTION", text="Arbitration.")
    mentions = _semantic(
        2, 1, section="7. GOVERNING LAW", text="subject to the arbitration in Clause 8."
    )
    ranked = rank_candidates(
        fuse([is_clause, mentions], []), preprocess_query("clause 8")
    )
    assert ranked[0].chunk.section == "8. DISPUTE RESOLUTION"


def test_a_clause_number_does_not_match_inside_a_larger_number():
    """"clause 4" must not match "14.25" or "USD 4.20"."""
    decoy = _semantic(1, 1, section="14. MISC", text="the cap is USD 4.20 per unit")
    ranked = rank_candidates([*fuse([decoy], [])], preprocess_query("clause 4"))
    assert "reference" not in ranked[0].boosts


def test_an_exact_quoted_phrase_is_rewarded():
    has_phrase = _semantic(1, 5, text="A material breach which is not remedied.")
    no_phrase = _semantic(2, 1, text="Something else entirely.")
    ranked = rank_candidates(
        fuse([has_phrase, no_phrase], []),
        preprocess_query('find the "material breach" clause'),
    )
    assert ranked[0].chunk.chunk_index == 1
    assert ranked[0].boosts["phrase"] > 0


def test_agreement_between_retrievers_is_rewarded():
    both = fuse([_semantic(1, 1)], [_keyword(1, 1)])
    ranked = rank_candidates(both, preprocess_query("passage"))
    assert ranked[0].boosts["agreement"] > 0


def test_a_heading_only_chunk_is_pushed_down():
    """A bare heading carries no obligation and must never be the answer."""
    heading = _semantic(1, 1, text="4. TERMINATION", heading_only=True)
    body = _semantic(2, 2, text="Either party may terminate on notice.")
    ranked = rank_candidates(fuse([heading, body], []), preprocess_query("terminate"))
    assert ranked[0].chunk.chunk_index == 2
    assert ranked[-1].boosts["heading_only"] < 0


def test_ranking_assigns_contiguous_ranks_and_respects_the_pool_limit():
    merged = fuse([_semantic(i, i) for i in range(1, 11)], [])
    ranked = rank_candidates(merged, preprocess_query("passage"), limit=4)
    assert len(ranked) == 4
    assert [c.rank for c in ranked] == [1, 2, 3, 4]


def test_ranking_is_deterministic_for_tied_scores():
    merged = fuse([_semantic(1, 1), _semantic(2, 1)], [])
    first = [c.chunk_id for c in rank_candidates(merged, preprocess_query("x"))]
    merged2 = fuse([_semantic(2, 1), _semantic(1, 1)], [])
    second = [c.chunk_id for c in rank_candidates(merged2, preprocess_query("x"))]
    assert first == second


def test_every_score_survives_to_the_end():
    """Explainability: no stage overwrites another stage's number."""
    merged = fuse([_semantic(1, 1, score=0.9)], [_keyword(1, 2, score=0.4)])
    ranked = rank_candidates(merged, preprocess_query("passage"))
    scores = ranked[0].scores()
    assert scores["semantic"] == pytest.approx(0.9)
    assert scores["keyword"] == pytest.approx(0.4)
    assert scores["fused"] >= 0
    assert scores["ranked"] >= 0
    assert set(scores["sources"]) == {SOURCE_SEMANTIC, SOURCE_KEYWORD}
