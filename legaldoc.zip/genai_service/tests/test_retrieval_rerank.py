"""Stage 5 — reranking.

Two things are under test and they are different:

* the **fallback** reranker's behaviour, which must be sensible enough
  to keep the service usable when the cross-encoder is missing;
* the **cross-encoder integration** itself — loading, pair construction,
  ``predict``, and the score-shape conversion — exercised against a real
  ``CrossEncoder`` built locally, because the Hugging Face hub is not
  reachable from this environment and a mock would test nothing.

The locally built model has random weights, so no test asserts on the
*order* it produces. What is asserted is that the integration works and
that the outputs are well-formed probabilities — which is precisely the
part that breaks when a library version changes.
"""

from __future__ import annotations

import pytest

from app.models.chunk import Chunk, make_chunk_id
from app.models.document import DocumentType
from app.retrieval.base import Candidate, RerankerUnavailableError
from app.retrieval.query import preprocess_query
from app.retrieval.rerank import (
    CROSS_ENCODER,
    LEXICAL,
    CrossEncoderReranker,
    LexicalReranker,
    apply_reranking,
    build_reranker,
    get_reranker,
    set_reranker,
)

NOTICE_CLAUSE = (
    "Either party may terminate this Agreement for convenience on one "
    "hundred and twenty (120) days written notice to the other party."
)
SURVIVAL_CLAUSE = (
    "Termination shall not affect any accrued rights or remedies of either "
    "party as at the date of termination."
)
UNRELATED = "The Vendor shall provide monthly service reports in PDF form."


def _candidate(text: str, index: int, rank_score: float = 0.5) -> Candidate:
    chunk = Chunk(
        chunk_id=make_chunk_id("doc-1", index, text),
        chunk_index=index,
        text=text,
        document_id="doc-1",
        tenant_id="tenant-a",
        filename="contract.pdf",
        page_number=1,
        document_type=DocumentType.CONTRACT,
        token_count=len(text.split()),
    )
    candidate = Candidate(chunk=chunk)
    candidate.fused_score = rank_score
    candidate.rank_score = rank_score
    candidate.final_score = rank_score
    return candidate


# ---------------------------------------------------------------------
# Lexical fallback
# ---------------------------------------------------------------------


def test_lexical_reranker_declares_that_it_is_not_a_cross_encoder():
    """The substitution must never be able to pass for the real thing."""
    reranker = LexicalReranker()
    assert reranker.is_cross_encoder is False
    assert "not a cross-encoder" in reranker.describe()


def test_lexical_reranker_scores_term_coverage():
    reranker = LexicalReranker()
    query = preprocess_query("how much written notice to terminate")
    scores = reranker.score(query, [NOTICE_CLAUSE, UNRELATED])
    assert scores[0] > scores[1]


def test_lexical_reranker_rewards_an_exact_phrase():
    reranker = LexicalReranker()
    query = preprocess_query('the "written notice" requirement')
    with_phrase, without = reranker.score(
        query, [NOTICE_CLAUSE, "Notice must be given in writing."]
    )
    assert with_phrase > without


def test_lexical_reranker_returns_one_score_per_passage():
    scores = LexicalReranker().score(
        preprocess_query("termination"), [NOTICE_CLAUSE, UNRELATED, ""]
    )
    assert len(scores) == 3
    assert all(0.0 <= s <= 1.0 for s in scores)


def test_lexical_reranker_handles_a_query_with_nothing_to_match():
    scores = LexicalReranker().score(preprocess_query("the"), [NOTICE_CLAUSE])
    assert len(scores) == 1


def test_lexical_reranker_handles_no_passages():
    assert LexicalReranker().score(preprocess_query("notice"), []) == []


# ---------------------------------------------------------------------
# Applying a reranker
# ---------------------------------------------------------------------


def test_reranking_reorders_by_relevance():
    candidates = [
        _candidate(SURVIVAL_CLAUSE, 1, rank_score=1.0),   # retrieval's favourite
        _candidate(NOTICE_CLAUSE, 2, rank_score=0.9),
    ]
    final = apply_reranking(
        candidates,
        preprocess_query("how much written notice to terminate for convenience"),
        LexicalReranker(),
        top_k=2,
    )
    assert final[0].chunk.chunk_index == 2


def test_reranking_truncates_to_top_k_and_renumbers():
    candidates = [_candidate(f"passage {i} notice", i) for i in range(1, 11)]
    final = apply_reranking(
        candidates, preprocess_query("notice"), LexicalReranker(), top_k=4
    )
    assert len(final) == 4
    assert [c.rank for c in final] == [1, 2, 3, 4]


def test_the_rerank_score_is_recorded_separately():
    """Retrieval's numbers are not overwritten by the reranker's."""
    candidates = [_candidate(NOTICE_CLAUSE, 1, rank_score=0.7)]
    final = apply_reranking(
        candidates, preprocess_query("notice"), LexicalReranker(), top_k=1
    )
    assert final[0].rerank_score is not None
    assert final[0].rank_score == pytest.approx(0.7)
    assert final[0].scores()["rerank"] is not None


def test_weight_one_hands_the_ordering_to_the_reranker():
    candidates = [
        _candidate(UNRELATED, 1, rank_score=1.0),
        _candidate(NOTICE_CLAUSE, 2, rank_score=0.0),
    ]
    final = apply_reranking(
        candidates,
        preprocess_query("written notice to terminate"),
        LexicalReranker(),
        top_k=2,
        weight=1.0,
    )
    assert final[0].chunk.chunk_index == 2


def test_weight_zero_keeps_the_retrieval_ordering():
    """The escape hatch: the reranker is scored but does not decide."""
    candidates = [
        _candidate(UNRELATED, 1, rank_score=1.0),
        _candidate(NOTICE_CLAUSE, 2, rank_score=0.1),
    ]
    final = apply_reranking(
        candidates,
        preprocess_query("written notice to terminate"),
        LexicalReranker(),
        top_k=2,
        weight=0.0,
    )
    assert final[0].chunk.chunk_index == 1
    # Scored anyway, so the number is available for debugging.
    assert final[0].rerank_score is not None


def test_a_pinned_candidate_cannot_be_demoted_by_the_reranker():
    """The user named this clause. The reranker does not get a vote.

    This is the concrete failure it prevents: asked "what does clause 8
    say", a term-overlap reranker scores the passage that *mentions*
    "Clause 8" far above clause 8 itself, whose own text never contains
    the string. Without the pin, the one passage the user explicitly
    asked for is the one that gets pushed down.
    """
    pinned = _candidate("Any dispute shall be referred to arbitration.", 1, 0.5)
    pinned.pinned = True
    mentions = _candidate("...subject to the arbitration in Clause 8.", 2, 1.0)

    final = apply_reranking(
        [mentions, pinned],
        preprocess_query("what does clause 8 say"),
        LexicalReranker(),
        top_k=2,
    )
    assert final[0].chunk.chunk_index == 1
    assert final[0].rank == 1
    # It is still scored, so the number remains visible for debugging.
    assert final[0].rerank_score is not None


def test_pinning_does_not_bypass_top_k():
    candidates = [_candidate(f"passage {i}", i) for i in range(1, 6)]
    for candidate in candidates:
        candidate.pinned = True
    final = apply_reranking(
        candidates, preprocess_query("passage"), LexicalReranker(), top_k=2
    )
    assert len(final) == 2


def test_reranking_an_empty_list_is_empty():
    assert apply_reranking([], preprocess_query("x"), LexicalReranker(), 5) == []


def test_metadata_survives_reranking():
    final = apply_reranking(
        [_candidate(NOTICE_CLAUSE, 3)],
        preprocess_query("notice"),
        LexicalReranker(),
        top_k=1,
    )
    chunk = final[0].chunk
    assert chunk.document_id == "doc-1"
    assert chunk.page_number == 1
    assert chunk.chunk_id


# ---------------------------------------------------------------------
# The real cross-encoder code path
# ---------------------------------------------------------------------


def test_cross_encoder_integration(tiny_cross_encoder_path):
    """Exercise sentence_transformers.CrossEncoder for real.

    Not a mock: a genuine model is built on disk and loaded through the
    same class production uses, so a breaking change in the library's
    constructor or ``predict`` signature fails here rather than in a
    deployment.
    """
    if tiny_cross_encoder_path is None:
        pytest.skip("transformers is unavailable")

    reranker = CrossEncoderReranker(
        model_id=str(tiny_cross_encoder_path), batch_size=2, max_chars=200
    )
    assert not reranker.loaded
    scores = reranker.score(
        preprocess_query("how much notice to terminate"),
        [NOTICE_CLAUSE, SURVIVAL_CLAUSE, UNRELATED],
    )

    assert reranker.loaded
    assert reranker.is_cross_encoder
    assert len(scores) == 3
    # Random weights, so the order is meaningless — but every score must
    # be a well-formed probability.
    assert all(0.0 <= s <= 1.0 for s in scores)


def test_cross_encoder_truncates_long_passages(tiny_cross_encoder_path):
    """A 40-page clause must not be fed whole to a 512-token model."""
    if tiny_cross_encoder_path is None:
        pytest.skip("transformers is unavailable")

    reranker = CrossEncoderReranker(
        model_id=str(tiny_cross_encoder_path), max_chars=64
    )
    scores = reranker.score(preprocess_query("notice"), ["notice " * 5000])
    assert len(scores) == 1


def test_cross_encoder_scores_no_passages_without_loading():
    reranker = CrossEncoderReranker(model_id="definitely/not-a-real-model")
    assert reranker.score(preprocess_query("notice"), []) == []
    assert not reranker.loaded


def test_a_missing_cross_encoder_raises_on_load():
    reranker = CrossEncoderReranker(model_id="definitely/not-a-real-model")
    with pytest.raises(RerankerUnavailableError):
        reranker.load()


@pytest.mark.parametrize(
    "raw,expected_length",
    [
        ([0.0, 2.0, -2.0], 3),                    # one logit per pair
        ([[1.0, 2.0], [0.5, 0.1]], 2),            # two-class output
    ],
)
def test_model_output_shapes_are_converted_to_probabilities(raw, expected_length):
    """The conversion is decided by shape, never by the values.

    A data-dependent rule would apply a sigmoid to one query and not the
    next, making scores incomparable between requests.
    """
    values = CrossEncoderReranker._to_probabilities(raw)
    assert len(values) == expected_length
    assert all(0.0 <= v <= 1.0 for v in values)


def test_sigmoid_conversion_is_monotonic():
    values = CrossEncoderReranker._to_probabilities([-5.0, 0.0, 5.0])
    assert values == sorted(values)


def test_extreme_logits_do_not_overflow():
    values = CrossEncoderReranker._to_probabilities([1e6, -1e6])
    assert values[0] == pytest.approx(1.0)
    assert values[1] == pytest.approx(0.0)


# ---------------------------------------------------------------------
# Factory and failure handling
# ---------------------------------------------------------------------


def test_the_factory_honours_the_lexical_provider(make_settings):
    reranker = build_reranker(make_settings(reranker_provider=LEXICAL))
    assert reranker.name == LEXICAL


def test_an_unloadable_cross_encoder_falls_back_by_default(make_settings):
    settings = make_settings(
        reranker_provider=CROSS_ENCODER,
        reranker_model="definitely/not-a-real-model",
        rerank_strict=False,
    )
    reranker = build_reranker(settings)
    assert reranker.name == LEXICAL
    assert not reranker.is_cross_encoder


def test_strict_mode_makes_an_unloadable_cross_encoder_fatal(make_settings):
    """Production: being down beats silently ranking worse."""
    settings = make_settings(
        reranker_provider=CROSS_ENCODER,
        reranker_model="definitely/not-a-real-model",
        rerank_strict=True,
    )
    with pytest.raises(RerankerUnavailableError):
        build_reranker(settings)


def test_an_unknown_provider_is_rejected(make_settings):
    settings = make_settings(reranker_provider=LEXICAL)
    object.__setattr__(settings, "reranker_provider", "magic")
    with pytest.raises(RerankerUnavailableError):
        build_reranker(settings)


def test_the_reranker_singleton_is_reused(settings):
    set_reranker(None)
    first = get_reranker(settings)
    assert get_reranker(settings) is first
