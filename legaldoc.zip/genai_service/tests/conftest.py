"""Test configuration.

The environment is pinned before any application module is imported, so
a stray ``.env`` on the developer's machine cannot change test results.
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

import pytest

# Point ENV_FILE at a path that does not exist: settings then come from
# the environment and the declared defaults only.
_NO_ENV = Path(tempfile.gettempdir()) / "legaldocai-tests-nonexistent.env"
os.environ.setdefault("ENV_FILE", str(_NO_ENV))
os.environ.setdefault("LOG_LEVEL", "WARNING")
os.environ.setdefault("ENVIRONMENT", "development")
os.environ.setdefault("SERVICE_TOKEN", "")

# Stage 2: give ingestion its own throwaway document root and temp dir so
# the suite never reads or writes anywhere the developer cares about.
_INGEST_ROOT = Path(tempfile.mkdtemp(prefix="legaldocai-docs-"))
(_INGEST_ROOT / "documents").mkdir(parents=True, exist_ok=True)
(_INGEST_ROOT / "tmp").mkdir(parents=True, exist_ok=True)
os.environ.setdefault("DOCUMENT_ROOT", str(_INGEST_ROOT / "documents"))
os.environ.setdefault("TEMP_DIR", str(_INGEST_ROOT / "tmp"))

# Stage 4: the deterministic encoder keeps the suite hermetic — no model
# download, no network — and a non-default width catches any hard-coded
# dimension. The in-memory backend keeps it fast; the conformance suite
# runs against Chroma too.
(_INGEST_ROOT / "vectors").mkdir(parents=True, exist_ok=True)
os.environ.setdefault("VECTOR_PERSIST_DIR", str(_INGEST_ROOT / "vectors"))
os.environ.setdefault("EMBEDDING_PROVIDER", "deterministic")
os.environ.setdefault("DETERMINISTIC_EMBEDDING_DIM", "128")
os.environ.setdefault("VECTOR_BACKEND", "memory")
os.environ.setdefault("VECTOR_COLLECTION", "test_chunks")

# Stage 5: the lexical reranker by default, so the suite never reaches
# for a model download. The genuine CrossEncoder code path is exercised
# separately in test_retrieval_rerank.py against a model built locally.
os.environ.setdefault("RERANKER_PROVIDER", "lexical")

from fastapi.testclient import TestClient  # noqa: E402

from app.config import Settings, get_settings, reset_settings_cache  # noqa: E402
from app.main import create_app  # noqa: E402

from tests import fixtures  # noqa: E402


@pytest.fixture(scope="session")
def settings() -> Settings:
    return get_settings()


@pytest.fixture
def make_settings():
    """Build a Settings object with overrides, without touching the env."""

    def _make(**overrides) -> Settings:
        return Settings(**{**get_settings().model_dump(), **overrides})

    return _make


@pytest.fixture(scope="session")
def client():
    """TestClient over the default application (runs lifespan)."""
    with TestClient(create_app()) as test_client:
        yield test_client


@pytest.fixture
def client_factory():
    """Build a TestClient over an app configured with custom settings."""
    from contextlib import contextmanager

    @contextmanager
    def _factory(settings: Settings):
        with TestClient(create_app(settings)) as test_client:
            yield test_client

    return _factory


@pytest.fixture(autouse=True)
def _clear_settings_cache():
    """Keep the settings cache from leaking between tests."""
    yield
    reset_settings_cache()


# =====================================================================
# Stage 2 — document fixtures
# =====================================================================

DOC_ROOT = Path(os.environ["DOCUMENT_ROOT"])


def pytest_sessionfinish(session, exitstatus):  # pragma: no cover
    """Remove every temporary directory the suite created."""
    import shutil

    shutil.rmtree(_INGEST_ROOT, ignore_errors=True)


@pytest.fixture(scope="session")
def doc_root() -> Path:
    return DOC_ROOT


def _build_once(name: str, builder, *args, **kwargs) -> Path:
    """Generate a fixture document once per session."""
    path = DOC_ROOT / name
    if not path.exists():
        builder(path, *args, **kwargs)
    return path


@pytest.fixture(scope="session")
def contract_pdf() -> Path:
    """A single-page-ish text PDF with numbered legal clauses."""
    return _build_once(
        "vendor_contract_2024.pdf",
        fixtures.make_pdf,
        "MANAGED SERVICES AGREEMENT",
        fixtures.VENDOR_CONTRACT[:3],
    )


@pytest.fixture(scope="session")
def multipage_pdf() -> Path:
    """A multi-page PDF with a repeated footer and page numbers."""
    return _build_once(
        "multipage_agreement.pdf",
        fixtures.make_pdf,
        "MASTER SERVICES AGREEMENT",
        fixtures.VENDOR_CONTRACT,
        footer="Northwind Systems - Confidential - Managed Services Agreement",
        page_break_every=2,
    )


@pytest.fixture(scope="session")
def nda_docx() -> Path:
    return _build_once(
        "mutual_nda_2024.docx",
        fixtures.make_docx,
        "MUTUAL NON-DISCLOSURE AGREEMENT",
        fixtures.MUTUAL_NDA,
    )


@pytest.fixture(scope="session")
def paged_docx() -> Path:
    return _build_once(
        "paged_nda.docx", fixtures.make_docx_with_page_breaks, fixtures.MUTUAL_NDA
    )


@pytest.fixture(scope="session")
def scanned_pdf() -> Path:
    """An image-only PDF — no text layer, so OCR is the only route in."""
    return _build_once("scanned_award_2023.pdf", fixtures.make_scanned_pdf)


@pytest.fixture(scope="session")
def blank_pdf() -> Path:
    return _build_once("blank_document.pdf", fixtures.make_blank_pdf)


@pytest.fixture(scope="session")
def empty_docx() -> Path:
    return _build_once("empty_document.docx", fixtures.make_empty_docx)


@pytest.fixture
def corrupt_pdf() -> Path:
    return fixtures.make_corrupt_pdf(DOC_ROOT / "corrupt_document.pdf")


@pytest.fixture
def corrupt_docx() -> Path:
    return fixtures.make_corrupt_docx(DOC_ROOT / "corrupt_document.docx")


@pytest.fixture
def fake_pdf() -> Path:
    """A .pdf that is not a PDF — magic-byte validation must catch it."""
    return fixtures.make_fake_pdf(DOC_ROOT / "not_really_a.pdf")


@pytest.fixture
def unsupported_file() -> Path:
    return fixtures.make_unsupported_file(DOC_ROOT / "matter_notes.txt")


@pytest.fixture
def ocr_available() -> bool:
    from app.ingestion.ocr import ocr_available as probe

    return probe()


# =====================================================================
# Stage 4 — embeddings and vector store
# =====================================================================

VECTOR_ROOT = Path(os.environ["VECTOR_PERSIST_DIR"])


@pytest.fixture(autouse=True)
def _reset_singletons():
    """The model, store, reranker and pipeline are process-wide singletons.

    Rebuilding them between tests stops a store created at one dimension
    — or a pipeline holding a store from a previous test — from leaking
    into a test that configured something else.
    """
    from app.context.builder import set_context_builder
    from app.embeddings.factory import set_embedding_model
    from app.generation.factory import set_llm_provider
    from app.generation.service import set_answer_service
    from app.retrieval.keyword import set_bm25_cache
    from app.retrieval.pipeline import set_pipeline
    from app.retrieval.rerank import set_reranker
    from app.services.jobs import set_job_registry
    from app.vectorstore.factory import set_vector_store

    yield
    set_bm25_cache(None)
    set_job_registry(None)
    set_answer_service(None)
    set_llm_provider(None)
    set_context_builder(None)
    set_pipeline(None)
    set_reranker(None)
    set_vector_store(None)
    set_embedding_model(None)


@pytest.fixture
def embedder():
    """The deterministic encoder at the suite's configured width."""
    from app.embeddings.deterministic import DeterministicEmbedding

    return DeterministicEmbedding(dimension=128)


@pytest.fixture
def memory_store(embedder):
    from app.vectorstore.memory import InMemoryVectorStore

    store = InMemoryVectorStore(
        dimension=embedder.dimension, embedding_model_id=embedder.model_id
    )
    store.ensure_ready()
    return store


@pytest.fixture
def chroma_store(embedder, tmp_path):
    """A Chroma store in its own directory and collection per test."""
    from app.vectorstore.chroma import ChromaVectorStore

    store = ChromaVectorStore(
        persist_directory=str(tmp_path / "chroma"),
        # Chroma requires 3-512 chars starting/ending alphanumeric.
        collection_name=f"t{abs(hash(str(tmp_path))) % 10**10}x",
        dimension=embedder.dimension,
        embedding_model_id=embedder.model_id,
    )
    store.ensure_ready()
    yield store
    try:
        store.reset()
    except Exception:
        pass


@pytest.fixture(params=["memory", "chroma"])
def any_store(request):
    """Every backend, so the conformance suite runs against all of them.

    This is what makes the VectorStore abstraction a verified contract
    rather than a claim — and it is the suite a future Pinecone adapter
    must pass.
    """
    return request.getfixturevalue(f"{request.param}_store")


# =====================================================================
# Stage 5 — retrieval
# =====================================================================

TENANT_A = "tenant-a"
TENANT_B = "tenant-b"


@pytest.fixture
def corpus_chunks():
    """A small, readable, entirely synthetic multi-tenant corpus.

    tenant-a holds a vendor contract and a mutual NDA; tenant-b holds its
    own copy of the same contract text under a different document id and
    tenant. That last part is the point: every isolation test needs a
    neighbour whose content would match the query if scoping failed.
    """
    return {
        "contract": fixtures.make_chunks(
            fixtures.VENDOR_CONTRACT,
            document_id="doc-contract",
            tenant_id=TENANT_A,
            filename="vendor_contract_2024.pdf",
            document_type="contract",
        ),
        "nda": fixtures.make_chunks(
            fixtures.MUTUAL_NDA,
            document_id="doc-nda",
            tenant_id=TENANT_A,
            filename="mutual_nda_2024.docx",
            document_type="nda",
        ),
        "other_tenant": fixtures.make_chunks(
            fixtures.VENDOR_CONTRACT,
            document_id="doc-rival",
            tenant_id=TENANT_B,
            filename="rival_contract.pdf",
            document_type="contract",
        ),
    }


@pytest.fixture
def indexed_store(embedder, memory_store, corpus_chunks):
    """The corpus above, embedded and upserted into the memory store."""
    from app.embeddings.factory import embed_in_batches

    for chunks in corpus_chunks.values():
        vectors = embed_in_batches(embedder, [c.text for c in chunks])
        memory_store.upsert(chunks, vectors)
    return memory_store


@pytest.fixture
def lexical_pipeline(settings, embedder, indexed_store):
    """A pipeline wired to the fixture store and the fallback reranker.

    Explicit rather than singleton-driven: a test that has to reset four
    globals to be reproducible is a test that will eventually not be.
    """
    from app.retrieval.pipeline import RetrievalPipeline
    from app.retrieval.rerank import LexicalReranker

    return RetrievalPipeline(
        settings=settings,
        model=embedder,
        store=indexed_store,
        reranker=LexicalReranker(),
    )


@pytest.fixture(scope="session")
def tiny_cross_encoder_path(tmp_path_factory) -> Path:
    """Build a real CrossEncoder-compatible model locally.

    Same reasoning as ``tiny_st_model_path``: the point is to run the
    genuine ``sentence_transformers.CrossEncoder`` code path — loading,
    pair construction, ``predict``, the score-shape conversion — without
    a model download. The model is random, so its *scores* are
    meaningless and no test asserts on their order; what is asserted is
    that the integration works and that the outputs are well-formed
    probabilities. Returns None when transformers is unavailable, and the
    tests using it skip.
    """
    try:
        from transformers import (
            BertConfig,
            BertForSequenceClassification,
            BertTokenizerFast,
        )
    except Exception:
        return None

    try:
        base = tmp_path_factory.mktemp("tiny-cross-encoder")
        vocab = (
            ["[PAD]", "[UNK]", "[CLS]", "[SEP]", "[MASK]"]
            + [f"tok{i}" for i in range(30)]
            + [
                "the", "a", "of", "and", "to", "notice", "termination",
                "terminate", "agreement", "party", "days", "written",
                "liability", "fee", "payment", "confidential",
            ]
        )
        (base / "vocab.txt").write_text("\n".join(vocab) + "\n")

        config = BertConfig(
            vocab_size=len(vocab),
            hidden_size=32,
            num_hidden_layers=1,
            num_attention_heads=2,
            intermediate_size=64,
            max_position_embeddings=128,
            num_labels=1,          # the ms-marco reranker shape
        )
        BertForSequenceClassification(config).save_pretrained(str(base))
        BertTokenizerFast(vocab_file=str(base / "vocab.txt")).save_pretrained(
            str(base)
        )
        return base
    except Exception:
        return None


@pytest.fixture(scope="session")
def tiny_st_model_path(tmp_path_factory) -> Path:
    """Build a real SentenceTransformer locally, at 96 dimensions.

    The point is to exercise the genuine Sentence-Transformers code path
    — including dimension discovery — without a model download, and at a
    width that is emphatically not 768. Returns None when transformers
    is unavailable, and the tests using it skip.
    """
    try:
        from sentence_transformers import SentenceTransformer
        from sentence_transformers.sentence_transformer import modules
        from transformers import BertConfig, BertModel, BertTokenizerFast
    except Exception:
        return None

    try:
        base = tmp_path_factory.mktemp("tiny-bert")
        vocab = (
            ["[PAD]", "[UNK]", "[CLS]", "[SEP]", "[MASK]"]
            + [f"tok{i}" for i in range(40)]
            + [
                "the", "a", "of", "and", "to", "in", "agreement", "termination",
                "notice", "party", "liability", "clause", "shall", "vendor",
                "client", "fee", "dimension", "probe",
            ]
        )
        (base / "vocab.txt").write_text("\n".join(vocab) + "\n")

        config = BertConfig(
            vocab_size=len(vocab),
            hidden_size=96,          # deliberately not 768
            num_hidden_layers=1,
            num_attention_heads=2,
            intermediate_size=128,
            max_position_embeddings=64,
        )
        BertModel(config).save_pretrained(str(base))
        BertTokenizerFast(vocab_file=str(base / "vocab.txt")).save_pretrained(str(base))

        word = modules.Transformer(str(base), max_seq_length=32)
        pooling = modules.Pooling(
            word.get_embedding_dimension()
            if hasattr(word, "get_embedding_dimension")
            else word.get_word_embedding_dimension(),
            pooling_mode="mean",
        )
        model = SentenceTransformer(modules=[word, pooling])

        out = tmp_path_factory.mktemp("tiny-st")
        model.save(str(out))
        return out
    except Exception:
        return None
