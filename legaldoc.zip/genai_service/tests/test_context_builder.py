"""Stage 6 — the context builder end to end.

The seven scenarios Stage 6 required, each in its own section: multiple
documents, duplicate chunks, the context limit, missing metadata, long
chunks, insufficient evidence, and source ordering.

Every test builds from plain :class:`~app.models.chunk.Chunk` objects
rather than from a retrieval run. That is the point of requirement 10 —
if checking a token budget needed a vector store, an embedding model and
a reranker first, the builder would not be independently testable and
every one of these failures would be ambiguous about its cause.
"""

from __future__ import annotations

import pytest

from app.context.base import OmissionReason
from app.context.builder import ContextBuilder
from app.context.formatter import SEPARATOR
from app.models.chunk import Chunk, make_chunk_id
from app.models.document import DocumentType
from app.retrieval.base import Candidate
from tests import fixtures

QUERY = "How much notice is required to terminate for convenience?"


@pytest.fixture
def builder(settings):
    return ContextBuilder(settings)


def _chunk(
    text: str,
    index: int = 0,
    document_id: str = "doc-1",
    filename: str = "vendor_contract_2024.pdf",
    section: str = "4. TERMINATION",
    page: int = 1,
    **kwargs,
) -> Chunk:
    return Chunk(
        chunk_id=make_chunk_id(document_id, index, text),
        chunk_index=index,
        text=text,
        document_id=document_id,
        tenant_id="tenant-a",
        filename=filename,
        page_number=page,
        document_type=DocumentType.CONTRACT,
        section=section,
        token_count=len(text.split()),
        **kwargs,
    )


def _scored(chunk: Chunk, score: float) -> Candidate:
    candidate = Candidate.from_chunk(chunk)
    candidate.final_score = score
    return candidate


def _contract_chunks(**kwargs):
    return fixtures.make_chunks(fixtures.VENDOR_CONTRACT, **kwargs)


# =====================================================================
# The basic contract
# =====================================================================


def test_the_block_has_the_required_structure(builder):
    context = builder.build(_contract_chunks()[:2], query=QUERY)
    assert context.text.startswith("Source 1:")
    for label in ("Document:", "Page:", "Section:", "Chunk:", "Text:"):
        assert label in context.text


def test_no_answer_and_no_instructions_are_generated(builder):
    """This stage assembles evidence. It does not write the prompt.

    Putting instructions here would fix them for every future caller,
    and putting an answer here would be a different stage entirely.
    """
    context = builder.build(_contract_chunks()[:2], query=QUERY)
    lowered = context.text.lower()
    for phrase in ("you are", "answer the", "based on the context", "question:"):
        assert phrase not in lowered
    assert QUERY.lower() not in lowered


def test_the_builder_is_deterministic(builder):
    chunks = _contract_chunks()
    assert builder.build(chunks, query=QUERY).text == (
        builder.build(chunks, query=QUERY).text
    )


def test_an_empty_input_produces_an_empty_context(builder):
    context = builder.build([], query=QUERY)
    assert context.text == ""
    assert context.sources == []
    assert not context.sufficient


# =====================================================================
# 1. Multiple documents
# =====================================================================


def test_passages_from_several_documents_are_all_present(builder):
    chunks = (
        _contract_chunks(document_id="doc-contract", filename="contract.pdf")[:2]
        + fixtures.make_chunks(
            fixtures.MUTUAL_NDA,
            document_id="doc-nda",
            filename="nda.docx",
            document_type="nda",
        )[:2]
    )
    context = builder.build(chunks, query=QUERY, max_tokens=4000)

    assert context.stats.documents == 2
    assert set(context.document_ids) == {"doc-contract", "doc-nda"}
    assert "contract.pdf" in context.text
    assert "nda.docx" in context.text


def test_each_document_keeps_its_own_metadata(builder):
    chunks = [
        _chunk("Clause about termination notice.", 0, "doc-a", "a.pdf", "4. TERM", 2),
        _chunk("Clause about confidentiality.", 0, "doc-b", "b.docx", "6. CONF", 5),
    ]
    context = builder.build(chunks, query=QUERY)

    by_document = {s.chunk.document_id: s for s in context.sources}
    assert by_document["doc-a"].chunk.page_number == 2
    assert by_document["doc-a"].chunk.section == "4. TERM"
    assert by_document["doc-b"].chunk.page_number == 5
    assert by_document["doc-b"].chunk.section == "6. CONF"


def test_a_stronger_document_is_presented_first(builder):
    chunks = [
        _scored(_chunk("Weak passage about invoicing.", 0, "doc-weak"), 0.2),
        _scored(_chunk("Strong passage about notice.", 0, "doc-strong"), 0.95),
    ]
    context = builder.build(chunks, query=QUERY)
    assert context.sources[0].chunk.document_id == "doc-strong"


def test_citations_cover_every_document(builder):
    chunks = [
        _chunk("Termination on notice.", 0, "doc-a", "a.pdf"),
        _chunk("Confidentiality survives.", 0, "doc-b", "b.pdf"),
    ]
    citations = builder.build(chunks, query=QUERY).citations()
    assert {c["document_id"] for c in citations} == {"doc-a", "doc-b"}
    assert {c["source"] for c in citations} == {1, 2}


# =====================================================================
# 2. Duplicate chunks
# =====================================================================


TERMINATION = (
    "Either party may terminate this Agreement for convenience on one "
    "hundred and twenty (120) days written notice to the other party."
)


def test_the_same_passage_from_two_documents_appears_once(builder):
    chunks = [
        _chunk(TERMINATION, 3, "doc-1", "original.pdf"),
        _chunk(TERMINATION, 7, "doc-2", "re-upload.pdf"),
    ]
    context = builder.build(chunks, query=QUERY)

    assert len(context.sources) == 1
    assert context.stats.redundant_removed == 1
    assert context.text.count("Source ") == 1


def test_the_duplicate_citation_survives_in_the_rendered_block(builder):
    """Requirement 9: the second copy's provenance is not discarded."""
    chunks = [
        _chunk(TERMINATION, 3, "doc-1", "original.pdf"),
        _chunk(TERMINATION, 7, "doc-2", "re-upload.pdf"),
    ]
    context = builder.build(chunks, query=QUERY)

    assert "Also appears in:" in context.text
    assert "re-upload.pdf" in context.text
    assert context.sources[0].duplicate_citations


def test_the_dropped_duplicate_is_listed_with_its_reason(builder):
    chunks = [
        _chunk(TERMINATION, 3, "doc-1"),
        _chunk(TERMINATION, 7, "doc-2"),
    ]
    context = builder.build(chunks, query=QUERY)

    dropped = [o for o in context.omitted if o.reason == OmissionReason.REDUNDANT]
    assert len(dropped) == 1
    assert dropped[0].citation["document_id"] == "doc-2"
    assert dropped[0].duplicate_of == context.sources[0].chunk_id


def test_near_duplicates_are_collapsed_too(builder):
    """An OCR'd copy of the same clause is the same clause."""
    variant = TERMINATION.replace("Agreement", "Aqreement").replace(
        "other party", "other Party"
    )
    context = builder.build(
        [_chunk(TERMINATION, 1, "doc-1"), _chunk(variant, 1, "doc-2")],
        query=QUERY,
    )
    assert len(context.sources) == 1


def test_deduplication_can_be_switched_off(builder):
    chunks = [_chunk(TERMINATION, 3, "doc-1"), _chunk(TERMINATION, 7, "doc-2")]
    context = builder.build(chunks, query=QUERY, dedupe=False)
    assert len(context.sources) == 2


def test_distinct_clauses_are_never_treated_as_duplicates(builder):
    context = builder.build(_contract_chunks(), query=QUERY, max_tokens=8000)
    assert context.stats.redundant_removed == 0
    assert len(context.sources) == min(8, builder.settings.context_max_sources)


# =====================================================================
# 3. Context limit
# =====================================================================


def test_the_budget_is_respected(builder):
    context = builder.build(_contract_chunks(), query=QUERY, max_tokens=400)
    assert context.stats.tokens_used <= 400
    assert builder.counter.count(context.text) <= 400


@pytest.mark.parametrize("budget", [200, 400, 800, 1600])
def test_the_budget_is_respected_at_every_size(builder, budget):
    context = builder.build(
        _contract_chunks(), query=QUERY, max_tokens=budget, min_source_tokens=20
    )
    assert builder.counter.count(context.text) <= budget


def test_the_budget_includes_the_header_overhead(builder):
    """Counting only passage text would overflow by ~50 tokens a source."""
    context = builder.build(_contract_chunks()[:3], query=QUERY, max_tokens=4000)
    assert context.stats.overhead_tokens > 0
    assert context.stats.tokens_used > context.stats.text_tokens


def test_passages_that_do_not_fit_are_reported_not_dropped_silently(builder):
    context = builder.build(_contract_chunks(), query=QUERY, max_tokens=300)
    assert context.stats.dropped_for_budget > 0
    budget_omissions = [
        o
        for o in context.omitted
        if o.reason
        in (OmissionReason.BUDGET_EXHAUSTED, OmissionReason.TOO_SMALL_TO_TRUNCATE)
    ]
    assert budget_omissions
    assert all(o.citation.get("chunk_id") for o in budget_omissions)
    assert any("did not fit" in w for w in context.warnings)


def test_the_strongest_evidence_wins_the_budget(builder):
    """A tight budget must keep the best passage, not the first one."""
    chunks = [
        _scored(_chunk("A weak passage about stationery orders.", 0, "doc-1"), 0.1),
        _scored(_chunk(TERMINATION, 1, "doc-1"), 0.99),
    ]
    context = builder.build(
        chunks, query=QUERY, max_tokens=110, min_source_tokens=10
    )
    assert len(context.sources) == 1
    assert "terminate" in context.sources[0].text


def test_the_source_cap_applies_even_when_the_budget_is_ample(builder):
    """Attention is finite even when context is not."""
    context = builder.build(
        _contract_chunks(), query=QUERY, max_tokens=100_000, max_sources=3
    )
    assert len(context.sources) == 3
    assert context.stats.over_max_sources == len(_contract_chunks()) - 3


def test_a_budget_too_small_for_anything_returns_an_empty_context(builder):
    context = builder.build(_contract_chunks(), query=QUERY, max_tokens=64)
    assert context.sources == []
    assert context.text == ""
    assert not context.sufficient
    assert context.omitted


# =====================================================================
# 4. Missing metadata
# =====================================================================


def test_absent_metadata_renders_an_explicit_marker(builder):
    chunk = _chunk("A passage with no provenance at all.", 0, "", "", None, 0)
    context = builder.build([chunk], query=QUERY)

    assert "Section: (not detected)" in context.text
    assert "Page: (unknown)" in context.text
    assert "Document: (not detected)" in context.text


def test_a_source_with_no_section_still_renders_every_field(builder):
    chunk = _chunk("Some clause text here.", 0, "doc-1", "a.pdf", None, 3)
    context = builder.build([chunk], query=QUERY)

    block = context.text
    assert block.count("Document:") == 1
    assert block.count("Page:") == 1
    assert block.count("Section:") == 1
    assert block.count("Chunk:") == 1
    assert "Page: 3" in block


def test_missing_metadata_does_not_break_the_citation(builder):
    chunk = _chunk("A passage.", 0, "doc-1", "", None, 0)
    citation = builder.build([chunk], query=QUERY).citations()[0]

    assert citation["chunk_id"]
    assert citation["source"] == 1
    assert citation["section"] is None


def test_mixed_complete_and_incomplete_metadata_still_orders(builder):
    chunks = [
        _chunk("Complete passage.", 1, "doc-a", "a.pdf", "2. TERM", 4),
        _chunk("Incomplete passage.", 0, "doc-a", "a.pdf", None, 0),
    ]
    context = builder.build(chunks, query=QUERY)
    assert len(context.sources) == 2
    assert [s.number for s in context.sources] == [1, 2]


# =====================================================================
# 5. Long chunks
# =====================================================================


LONG_CLAUSE = (
    "The Vendor shall indemnify the Client against all claims arising out "
    "of the Services. "
) * 60


def test_a_long_passage_is_shortened_rather_than_dropped(builder):
    context = builder.build(
        [_chunk(LONG_CLAUSE, 0, "doc-1")], query=QUERY, max_tokens=400
    )
    assert len(context.sources) == 1
    assert context.sources[0].truncated
    assert builder.counter.count(context.text) <= 400


def test_a_shortened_passage_declares_itself_in_the_block(builder):
    """The model must not read a fragment as a complete clause."""
    context = builder.build(
        [_chunk(LONG_CLAUSE, 0, "doc-1")], query=QUERY, max_tokens=400
    )
    assert "shortened" in context.text
    assert "tokens omitted" in context.text or "were removed" in context.text


def test_a_shortened_passage_is_reported_in_the_stats_and_warnings(builder):
    context = builder.build(
        [_chunk(LONG_CLAUSE, 0, "doc-1")], query=QUERY, max_tokens=400
    )
    assert context.stats.truncated_sources == 1
    assert context.stats.omitted_text_tokens > 0
    assert any("shortened" in w for w in context.warnings)
    assert context.citations()[0]["truncated"] is True


def test_one_long_passage_cannot_starve_the_others(builder):
    """The per-source cap is why a 2000-token schedule is not the context."""
    chunks = [
        _scored(_chunk(LONG_CLAUSE, 0, "doc-1"), 0.99),
        _scored(_chunk(TERMINATION, 1, "doc-1"), 0.90),
        _scored(_chunk("Governing law is India.", 2, "doc-1"), 0.85),
    ]
    context = builder.build(
        chunks, query=QUERY, max_tokens=800, max_source_tokens=200
    )
    assert len(context.sources) == 3
    assert max(s.text_tokens for s in context.sources) <= 200


def test_truncation_lands_on_a_sentence_boundary_where_one_exists(builder):
    context = builder.build(
        [_chunk(LONG_CLAUSE, 0, "doc-1")], query=QUERY, max_tokens=500
    )
    assert context.sources[0].text.rstrip().endswith(".")


# =====================================================================
# 6. Insufficient evidence
# =====================================================================


def test_no_passages_at_all_is_reported_as_insufficient(builder):
    context = builder.build([], query=QUERY)
    assert not context.sufficient
    assert any(w.startswith("Insufficient evidence") for w in context.warnings)


def test_fewer_sources_than_the_minimum_is_reported(builder):
    context = builder.build(
        [_chunk(TERMINATION, 0, "doc-1")], query=QUERY, min_sources=3
    )
    assert len(context.sources) == 1
    assert not context.sufficient
    assert any("thin evidence" in w for w in context.warnings)


def test_thin_evidence_is_reported_but_not_enforced(builder):
    """This stage does not decide a question is unanswerable.

    It builds what it has and says the evidence is thin; whether to
    answer, hedge or decline belongs to the stage that writes the prompt.
    """
    context = builder.build(
        [_chunk(TERMINATION, 0, "doc-1")], query=QUERY, min_sources=5
    )
    assert context.text
    assert context.sources
    assert not context.sufficient


def test_everything_filtered_out_by_the_score_floor_is_insufficient(builder):
    chunks = [_scored(_chunk(TERMINATION, 0, "doc-1"), 0.05)]
    context = builder.build(chunks, query=QUERY, min_score=0.5)
    assert context.sources == []
    assert not context.sufficient
    assert context.omitted[0].reason == OmissionReason.BELOW_SCORE_FLOOR


def test_sufficient_evidence_carries_no_insufficiency_warning(builder):
    context = builder.build(_contract_chunks()[:3], query=QUERY, max_tokens=4000)
    assert context.sufficient
    assert not any(w.startswith("Insufficient evidence") for w in context.warnings)


# =====================================================================
# 7. Source ordering
# =====================================================================


def test_sources_are_numbered_from_one_without_gaps(builder):
    context = builder.build(_contract_chunks()[:4], query=QUERY, max_tokens=4000)
    assert [s.number for s in context.sources] == [1, 2, 3, 4]


def test_the_numbering_matches_the_order_in_the_text(builder):
    """"Source 3" must be the third block, or citing by number is broken."""
    context = builder.build(_contract_chunks()[:4], query=QUERY, max_tokens=4000)
    blocks = context.text.split(SEPARATOR)
    for position, block in enumerate(blocks, start=1):
        assert block.startswith(f"Source {position}:")


def test_a_cited_number_resolves_back_to_its_chunk(builder):
    context = builder.build(_contract_chunks()[:3], query=QUERY, max_tokens=4000)
    source = context.source_by_number(2)
    assert source is not None
    assert source.chunk_id == context.sources[1].chunk_id
    assert context.source_by_number(99) is None


def test_document_order_presents_clauses_in_reading_order(builder):
    """Legal text is sequential; scrambling it makes a model reconstruct it."""
    chunks = _contract_chunks()[:5]
    scrambled = [chunks[3], chunks[0], chunks[4], chunks[1], chunks[2]]
    context = builder.build(scrambled, query=QUERY, max_tokens=6000, max_sources=5)

    indexes = [s.chunk.chunk_index for s in context.sources]
    assert indexes == sorted(indexes)


def test_relevance_order_is_available(builder):
    chunks = [
        _scored(_chunk("Passage about invoices.", 0, "doc-1"), 0.2),
        _scored(_chunk("Passage about notice.", 1, "doc-1"), 0.9),
    ]
    context = builder.build(chunks, query=QUERY, order="relevance")
    assert context.sources[0].score == pytest.approx(0.9)
    assert context.order == "relevance"


def test_selection_stays_relevance_driven_whatever_the_display_order(builder):
    """Ordering is presentation. The budget still buys the best evidence."""
    chunks = [
        _scored(_chunk("A weak passage about parking.", 0, "doc-1"), 0.05),
        _scored(_chunk(TERMINATION, 9, "doc-1"), 0.99),
    ]
    context = builder.build(
        chunks, query=QUERY, order="document", max_sources=1
    )
    assert len(context.sources) == 1
    assert "terminate" in context.sources[0].text


def test_adjacent_chunks_are_marked_as_continuing(builder):
    """A clause split by chunking should read as one passage."""
    chunks = _contract_chunks()[:3]
    context = builder.build(chunks, query=QUERY, max_tokens=4000)
    assert context.sources[1].continues_source == 1
    assert "Continues: Source 1" in context.text


def test_a_gap_between_chunks_is_not_marked_as_continuing(builder):
    """Saying "continues" across missing text would be worse than silence."""
    chunks = [_contract_chunks()[0], _contract_chunks()[4]]
    context = builder.build(chunks, query=QUERY, max_tokens=4000)
    assert context.sources[1].continues_source is None


def test_the_retrieval_rank_is_preserved_alongside_the_display_order(builder):
    """Presentation order is not relevance order, so both are reported."""
    # Clause 1 is the weaker match; clause 5 is the stronger one. In
    # document order the weaker passage is presented first, and the
    # scores travel with the sources so nothing is lost by that.
    chunks = [
        _scored(_chunk("Passage about invoices.", 1, "doc-1"), 0.3),
        _scored(_chunk("Passage about notice.", 5, "doc-1"), 0.9),
    ]
    context = builder.build(chunks, query=QUERY)

    assert [s.number for s in context.sources] == [1, 2]
    assert [s.chunk.chunk_index for s in context.sources] == [1, 5]
    assert context.sources[0].score < context.sources[1].score


# =====================================================================
# Serialisation
# =====================================================================


def test_the_result_serialises_completely(builder):
    data = builder.build(_contract_chunks()[:3], query=QUERY).to_dict()
    assert data["text"]
    assert len(data["sources"]) == len(data["citations"])
    assert data["stats"]["sources_out"] == len(data["sources"])
    assert "sufficient" in data
    assert isinstance(data["omitted"], list)


def test_text_can_be_excluded_from_the_structure(builder):
    data = builder.build(_contract_chunks()[:2], query=QUERY).to_dict(
        include_text=False
    )
    assert data["text"] == ""
    assert all("text" not in s for s in data["sources"])
    assert data["citations"]
