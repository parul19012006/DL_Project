"""Stage 7 — citation validation.

The requirement is that citations correspond to sources that were
actually retrieved. These tests pin that, and the three things that go
with it: metadata comes from the record rather than the reply, a
reference to a source that does not exist is reported loudly, and quoted
spans are checked against the evidence text.
"""

from __future__ import annotations

import pytest

from app.context.base import BuiltContext, ContextSource
from app.generation.citations import (
    CitationProblem,
    validate_citations,
    verify_quotes,
)
from app.generation.parser import ParsedAnswer
from app.models.chunk import Chunk, make_chunk_id
from app.models.document import DocumentType

CLAUSE = (
    "Either party may terminate this Agreement for convenience on one "
    "hundred and twenty (120) days written notice to the other party."
)
LIABILITY = (
    "The aggregate liability of either party shall not exceed the total fees "
    "paid in the twelve (12) months preceding the claim."
)


def _source(
    number: int,
    text: str = CLAUSE,
    document_id: str = "doc-1",
    filename: str = "contract.pdf",
    section: str = "4. TERMINATION",
    page: int = 2,
    chunk_index: int = 3,
) -> ContextSource:
    chunk = Chunk(
        chunk_id=make_chunk_id(document_id, chunk_index, text),
        chunk_index=chunk_index,
        text=text,
        document_id=document_id,
        tenant_id="tenant-a",
        filename=filename,
        page_number=page,
        document_type=DocumentType.CONTRACT,
        section=section,
    )
    return ContextSource(chunk=chunk, number=number, text=text, score=1.0)


def _context(*sources: ContextSource) -> BuiltContext:
    context = BuiltContext()
    context.sources = list(sources)
    return context


def _parsed(answer: str, sources=(), **kwargs) -> ParsedAnswer:
    return ParsedAnswer(
        answer=answer,
        cited_sources=list(sources),
        raw_citations=[{"source": n} for n in sources],
        **kwargs,
    )


# =====================================================================
# Citations must correspond to retrieved sources
# =====================================================================


def test_a_citation_to_a_retrieved_source_is_kept():
    report = validate_citations(
        _parsed("Notice is 120 days.", [1]), _context(_source(1))
    )
    assert len(report.citations) == 1
    assert report.citations[0].source == 1
    assert report.grounded


def test_a_citation_to_a_source_that_was_not_retrieved_is_dropped():
    """The core requirement. Set membership, not inspection."""
    report = validate_citations(
        _parsed("Notice is 120 days.", [1, 9]), _context(_source(1))
    )
    assert report.cited_sources == [1]
    rejected = [r for r in report.rejected if r.reason == CitationProblem.UNKNOWN_SOURCE]
    assert len(rejected) == 1
    assert rejected[0].claimed_source == 9
    assert any("not retrieved" in w for w in report.warnings)


def test_an_answer_citing_only_an_invented_source_is_ungrounded():
    report = validate_citations(_parsed("Notice is 120 days.", [7]), _context(_source(1)))
    assert report.citations == []
    assert not report.grounded


def test_the_rejection_explains_itself():
    report = validate_citations(_parsed("An answer.", [9]), _context(_source(1)))
    assert "Source 9" in report.rejected[0].detail
    assert "1 source(s) were supplied" in report.rejected[0].detail


# =====================================================================
# Metadata comes from the record
# =====================================================================


def test_citation_metadata_is_taken_from_the_retrieved_record():
    report = validate_citations(_parsed("An answer.", [1]), _context(_source(1)))
    citation = report.citations[0]
    assert citation.document == "contract.pdf"
    assert citation.document_id == "doc-1"
    assert citation.page == 2
    assert citation.section == "4. TERMINATION"
    assert citation.chunk_id


def test_the_models_own_metadata_never_overrides_the_record():
    """A wrong page number in a legal citation looks checkable, and isn't."""
    parsed = ParsedAnswer(
        answer="An answer.",
        cited_sources=[1],
        raw_citations=[
            {"source": 1, "page": 17, "document": "some_other.pdf",
             "section": "9. INVENTED"}
        ],
    )
    report = validate_citations(parsed, _context(_source(1)))
    citation = report.citations[0]

    assert citation.page == 2
    assert citation.document == "contract.pdf"
    assert citation.section == "4. TERMINATION"
    # The disagreement is recorded rather than silently corrected.
    assert citation.claimed["page"] == 17
    assert citation.claimed["document"] == "some_other.pdf"
    assert any("disagreed with the retrieved record" in w for w in report.warnings)


def test_matching_metadata_records_no_disagreement():
    parsed = ParsedAnswer(
        answer="An answer.",
        cited_sources=[1],
        raw_citations=[{"source": 1, "page": 2, "document": "contract.pdf"}],
    )
    report = validate_citations(parsed, _context(_source(1)))
    assert report.citations[0].claimed == {}


def test_a_page_number_of_zero_becomes_null_not_a_fake_page():
    report = validate_citations(
        _parsed("An answer.", [1]), _context(_source(1, page=0))
    )
    assert report.citations[0].page is None


def test_a_missing_section_stays_missing():
    report = validate_citations(
        _parsed("An answer.", [1]), _context(_source(1, section=None))
    )
    assert report.citations[0].section is None
    assert report.citations[0].chunk_id


# =====================================================================
# Inline references in the prose
# =====================================================================


def test_a_reference_written_into_the_prose_is_harvested():
    """The model did say which passage it used; adding it is recovery."""
    report = validate_citations(
        _parsed("As set out in Source 2, notice is 120 days.", []),
        _context(_source(1), _source(2)),
    )
    assert report.cited_sources == [2]
    assert report.citations[0].inline


def test_harvesting_can_be_switched_off():
    report = validate_citations(
        _parsed("As set out in Source 2, notice is 120 days.", []),
        _context(_source(1), _source(2)),
        harvest_inline=False,
    )
    assert report.citations == []


def test_an_invented_reference_inside_the_prose_is_reported_loudly():
    """It cannot be removed from the text, so the answer is ungrounded."""
    report = validate_citations(
        _parsed("As set out in Source 8, notice is 120 days.", [1]),
        _context(_source(1)),
    )
    assert not report.grounded
    reasons = [r.reason for r in report.rejected]
    assert CitationProblem.UNKNOWN_SOURCE_IN_ANSWER in reasons


def test_an_inline_reference_already_cited_is_not_duplicated():
    report = validate_citations(
        _parsed("Source 1 says notice is 120 days.", [1]), _context(_source(1))
    )
    assert report.cited_sources == [1]


# =====================================================================
# An answer with nothing to stand on
# =====================================================================


def test_an_uncited_answer_is_ungrounded():
    report = validate_citations(_parsed("Notice is 120 days.", []), _context(_source(1)))
    assert not report.grounded
    assert any(r.reason == CitationProblem.NO_CITATIONS for r in report.rejected)
    assert any("cites no source" in w for w in report.warnings)


def test_requiring_citations_can_be_switched_off():
    report = validate_citations(
        _parsed("Notice is 120 days.", []),
        _context(_source(1)),
        require_citations=False,
    )
    assert report.grounded


def test_an_insufficient_evidence_answer_needs_no_citation():
    """"The passages do not address this" asserts nothing to cite."""
    report = validate_citations(
        _parsed("The passages do not address this.", [], insufficient_evidence=True),
        _context(_source(1)),
    )
    assert report.grounded
    assert report.citations == []


# =====================================================================
# Quote verification
# =====================================================================


def test_an_exact_quote_is_verified():
    answer = 'The clause says "terminate this Agreement for convenience on one hundred and twenty (120) days written notice".'
    report = validate_citations(_parsed(answer, [1]), _context(_source(1)))
    assert report.verified_quotes == 1
    assert report.unverified_quotes == []
    assert report.grounded


def test_a_quote_not_in_the_evidence_is_reported():
    answer = 'The clause says "terminate on thirty (30) days notice at any time".'
    report = validate_citations(_parsed(answer, [1]), _context(_source(1)))
    assert report.unverified_quotes
    assert not report.grounded
    assert any("could not be found" in w for w in report.warnings)


def test_quote_matching_ignores_punctuation_and_case():
    answer = 'It states "TERMINATE THIS AGREEMENT, for convenience" clearly.'
    verified, unverified = verify_quotes(answer, [_source(1)])
    assert verified == 1
    assert unverified == []


def test_short_quoted_phrases_are_not_treated_as_quotations():
    """"the Vendor" in quotes is emphasis, and checking it is noise."""
    verified, unverified = verify_quotes('The "Vendor" must act.', [_source(1)])
    assert verified == 0
    assert unverified == []


def test_quote_checking_can_be_switched_off():
    answer = 'The clause says "something that is definitely not in the evidence".'
    report = validate_citations(
        _parsed(answer, [1]), _context(_source(1)), check_quotes=False
    )
    assert report.unverified_quotes == []
    assert report.grounded


def test_a_quote_is_checked_against_all_sources_not_just_cited_ones():
    answer = 'It says "aggregate liability of either party shall not exceed the total fees".'
    report = validate_citations(
        _parsed(answer, [1]),
        _context(_source(1), _source(2, text=LIABILITY, section="5. LIABILITY")),
    )
    assert report.verified_quotes == 1


# =====================================================================
# Multiple sources and serialisation
# =====================================================================


def test_multiple_citations_are_ordered_by_source_number():
    report = validate_citations(
        _parsed("An answer drawing on several clauses.", [3, 1, 2]),
        _context(
            _source(1),
            _source(2, text=LIABILITY, section="5. LIABILITY"),
            _source(3, text="Governing law is India.", section="7. GOVERNING LAW"),
        ),
    )
    assert report.cited_sources == [1, 2, 3]


def test_citations_across_two_documents_keep_their_own_metadata():
    report = validate_citations(
        _parsed("An answer from both documents.", [1, 2]),
        _context(
            _source(1, filename="contract.pdf", document_id="doc-1", page=2),
            _source(
                2,
                text=LIABILITY,
                filename="nda.docx",
                document_id="doc-2",
                page=5,
                section="3. TERM",
            ),
        ),
    )
    by_source = {c.source: c for c in report.citations}
    assert by_source[1].document == "contract.pdf"
    assert by_source[1].page == 2
    assert by_source[2].document == "nda.docx"
    assert by_source[2].page == 5


def test_the_report_serialises_in_the_required_shape():
    report = validate_citations(_parsed("An answer.", [1]), _context(_source(1)))
    data = report.to_dict()
    citation = data["citations"][0]
    assert set(citation) >= {"document", "page", "section", "chunk_id"}
    assert data["grounded"] is True


def test_an_empty_context_rejects_every_citation():
    report = validate_citations(_parsed("An answer.", [1, 2]), _context())
    assert report.citations == []
    assert not report.grounded
