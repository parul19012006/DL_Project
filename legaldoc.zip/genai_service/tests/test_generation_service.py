"""Stage 7 — the answer pipeline end to end.

The eight scenarios Stage 7 required, each in its own section: a grounded
answer, insufficient evidence, an irrelevant question, multiple
documents, multiple citations, missing citation metadata, an LLM failure,
and a malformed LLM response.

The model is scripted through :class:`tests.fixtures.StubProvider` so
each scenario can be produced exactly — a perfect answer, an invented
citation, a truncated reply, an outage. The real provider code paths are
tested separately against ``httpx.MockTransport``, so nothing is mocked
twice and nothing that matters is mocked away.
"""

from __future__ import annotations

import pytest

from app.generation.base import (
    LLMConfigurationError,
    LLMTimeoutError,
    LLMUnavailableError,
)
from app.generation.service import (
    NO_EVIDENCE_ANSWER,
    AnswerService,
    AnswerStatus,
)
from tests import fixtures
from tests.fixtures import StubProvider, answer_json

TENANT_A = "tenant-a"
TENANT_B = "tenant-b"
QUESTION = "How much notice is required to terminate for convenience?"


@pytest.fixture
def service_factory(settings, indexed_store, embedder):
    """An AnswerService wired to the fixture index and a scripted model."""
    from app.context.builder import ContextBuilder, set_context_builder
    from app.retrieval.pipeline import RetrievalPipeline, set_pipeline
    from app.retrieval.rerank import LexicalReranker

    set_pipeline(
        RetrievalPipeline(
            settings=settings,
            model=embedder,
            store=indexed_store,
            reranker=LexicalReranker(),
        )
    )
    set_context_builder(ContextBuilder(settings))

    def _make(provider) -> AnswerService:
        return AnswerService(settings=settings, provider=provider)

    return _make


# =====================================================================
# 1. Grounded answer
# =====================================================================


def test_a_grounded_answer_is_returned_with_its_citations(service_factory):
    provider = StubProvider(
        answer_json("Either party may terminate on 120 days written notice.", [1])
    )
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    assert result.status == AnswerStatus.OK
    assert result.answer
    assert result.citations.citations
    assert result.grounded
    assert result.succeeded


def test_every_citation_resolves_to_a_retrieved_passage(service_factory):
    provider = StubProvider(answer_json("Notice is 120 days.", [1]))
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    retrieved = {s.chunk_id for s in result.context.sources}
    assert {c.chunk_id for c in result.citations.citations} <= retrieved


def test_the_citation_has_the_required_shape(service_factory):
    provider = StubProvider(answer_json("Notice is 120 days.", [1]))
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    citation = result.citations.citations[0].to_dict()
    assert set(citation) >= {"document", "page", "section", "chunk_id"}
    assert citation["document"]
    assert citation["chunk_id"]


def test_the_prompt_carries_the_evidence_and_the_question(service_factory):
    provider = StubProvider(answer_json("Notice is 120 days.", [1]))
    service_factory(provider).answer(QUESTION, TENANT_A)

    request = provider.calls[0]
    assert "QUESTION:" in request.user
    assert QUESTION in request.user
    assert "EVIDENCE:" in request.user
    assert "Source 1:" in request.user


def test_the_prompt_carries_every_grounding_rule(service_factory):
    provider = StubProvider(answer_json("Notice is 120 days.", [1]))
    service_factory(provider).answer(QUESTION, TENANT_A)

    system = provider.calls[0].system.lower()
    for instruction in (
        "evidence only",
        "do not invent facts",
        "do not invent legal clauses",
        "do not invent dates",
        "do not pretend to knowledge",
        "insufficient",
        "separate evidence from interpretation",
        "cite your sources",
    ):
        assert instruction in system


def test_generation_is_deterministic_by_default(service_factory):
    provider = StubProvider(answer_json("Notice is 120 days.", [1]))
    service_factory(provider).answer(QUESTION, TENANT_A)
    assert provider.calls[0].temperature == 0.0


def test_interpretation_is_kept_out_of_the_answer(service_factory):
    provider = StubProvider(
        answer_json(
            "The contract requires 120 days written notice.",
            [1],
            interpretation="You would need to serve notice by early March.",
        )
    )
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    assert "March" not in result.answer
    assert "March" in result.interpretation


def test_an_answer_citing_nothing_is_flagged_ungrounded(service_factory):
    provider = StubProvider(answer_json("Notice is 120 days.", []))
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    assert result.status == AnswerStatus.OK
    assert not result.grounded
    assert any("cites no source" in w for w in result.warnings)


def test_an_invented_citation_is_dropped_and_reported(service_factory):
    provider = StubProvider(answer_json("Notice is 120 days.", [1, 99]))
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    assert 99 not in result.citations.cited_sources
    assert any(r.claimed_source == 99 for r in result.citations.rejected)


# =====================================================================
# 2. Insufficient evidence
# =====================================================================


def test_no_retrieved_evidence_skips_the_model_entirely(service_factory):
    """Asking a model to say "I don't know" and hoping it complies is
    strictly worse than not asking."""
    provider = StubProvider(answer_json("I know this from memory.", [1]))
    result = service_factory(provider).answer(QUESTION, "tenant-with-nothing")

    assert result.status == AnswerStatus.INSUFFICIENT_EVIDENCE
    assert result.answer == NO_EVIDENCE_ANSWER
    assert result.insufficient_evidence
    assert provider.calls == []


def test_a_model_reporting_insufficient_evidence_is_believed(service_factory):
    provider = StubProvider(
        answer_json(
            "The retrieved passages do not state a notice period.",
            [],
            insufficient=True,
        )
    )
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    assert result.status == AnswerStatus.INSUFFICIENT_EVIDENCE
    assert result.insufficient_evidence
    assert result.grounded  # nothing asserted, so nothing to cite


def test_an_insufficient_answer_still_returns_the_evidence(service_factory):
    provider = StubProvider(answer_json("Not addressed.", [], insufficient=True))
    result = service_factory(provider).answer(QUESTION, TENANT_A)
    assert result.context.sources


def test_an_empty_question_is_handled_without_calling_the_model(service_factory):
    provider = StubProvider(answer_json("Something.", [1]))
    result = service_factory(provider).answer("   ", TENANT_A)

    assert result.status == AnswerStatus.INSUFFICIENT_EVIDENCE
    assert provider.calls == []


# =====================================================================
# 3. Irrelevant question
# =====================================================================


def test_an_irrelevant_question_gets_no_keyword_evidence(service_factory):
    provider = StubProvider(
        answer_json("The passages do not address this.", [], insufficient=True)
    )
    result = service_factory(provider).answer(
        "What is the hydration ratio for a sourdough levain?", TENANT_A
    )
    assert result.retrieval.counts.keyword == 0


def test_an_irrelevant_question_with_a_score_floor_reaches_no_evidence(
    service_factory,
):
    """How a caller turns "nothing relevant" into a refusal to answer."""
    provider = StubProvider(answer_json("Something invented.", [1]))
    result = service_factory(provider).answer(
        "What is the hydration ratio for a sourdough levain?",
        TENANT_A,
        retrieval_options={"min_score": 0.99},
        context_options={"min_score": 0.99},
    )

    assert result.status == AnswerStatus.INSUFFICIENT_EVIDENCE
    assert provider.calls == []


def test_an_answer_quoting_text_not_in_the_evidence_is_flagged(service_factory):
    """The check that catches an invented quotation of a real document."""
    provider = StubProvider(
        answer_json(
            'The clause says "either party may walk away at any time without notice".',
            [1],
        )
    )
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    assert result.citations.unverified_quotes
    assert not result.grounded


# =====================================================================
# 4. Multiple documents
# =====================================================================


def test_evidence_can_span_several_documents(service_factory):
    provider = StubProvider(answer_json("Both agreements address termination.", [1, 2]))
    result = service_factory(provider).answer(
        "What do the agreements say about termination?", TENANT_A
    )

    assert result.context.stats.documents >= 2


def test_citations_across_documents_keep_their_own_provenance(service_factory):
    provider = StubProvider(answer_json("Both agreements address termination.", [1, 2]))
    result = service_factory(provider).answer(
        "What do the agreements say about termination?", TENANT_A
    )

    documents = {c.document_id for c in result.citations.citations}
    assert len(documents) >= 1
    for citation in result.citations.citations:
        source = result.context.source_by_number(citation.source)
        assert citation.document_id == source.chunk.document_id
        assert citation.document == source.chunk.filename


def test_the_answer_never_draws_on_another_tenants_documents(service_factory):
    """Both tenants hold the same contract text; neither sees the other."""
    provider = StubProvider(answer_json("Notice is 120 days.", [1]))
    result = service_factory(provider).answer(QUESTION, TENANT_B)

    assert all(s.chunk.tenant_id == TENANT_B for s in result.context.sources)
    assert all(
        s.chunk.document_id == "doc-rival" for s in result.context.sources
    )


def test_a_document_filter_narrows_the_evidence(service_factory):
    provider = StubProvider(answer_json("The NDA terminates in two years.", [1]))
    result = service_factory(provider).answer(
        QUESTION, TENANT_A, retrieval_options={"document_type": "nda"}
    )
    assert all(s.chunk.document_id == "doc-nda" for s in result.context.sources)


# =====================================================================
# 5. Multiple citations
# =====================================================================


def test_several_citations_are_all_validated(service_factory):
    provider = StubProvider(
        answer_json("Termination and confidentiality both apply.", [1, 2, 3])
    )
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    assert len(result.citations.citations) == 3
    assert result.citations.cited_sources == sorted(result.citations.cited_sources)


def test_a_mix_of_valid_and_invented_citations_keeps_only_the_valid(
    service_factory,
):
    provider = StubProvider(answer_json("An answer.", [1, 42, 2]))
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    assert 42 not in result.citations.cited_sources
    assert len(result.citations.citations) == 2
    assert len(result.citations.rejected) == 1


def test_duplicate_citations_appear_once(service_factory):
    provider = StubProvider(answer_json("An answer.", [1, 1, 1]))
    result = service_factory(provider).answer(QUESTION, TENANT_A)
    assert len(result.citations.citations) == 1


def test_a_citation_written_only_in_the_prose_is_recovered(service_factory):
    provider = StubProvider(
        answer_json("As stated in Source 2, the obligation survives.", [])
    )
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    assert result.citations.cited_sources == [2]
    assert result.citations.citations[0].inline


# =====================================================================
# 6. Missing citation metadata
# =====================================================================


def test_a_source_with_no_section_still_produces_a_usable_citation(
    settings, embedder, memory_store
):
    from app.context.builder import ContextBuilder, set_context_builder
    from app.embeddings.factory import embed_in_batches
    from app.models.chunk import Chunk, make_chunk_id
    from app.models.document import DocumentType
    from app.retrieval.pipeline import RetrievalPipeline, set_pipeline
    from app.retrieval.rerank import LexicalReranker

    text = "Either party may terminate on one hundred and twenty days notice."
    chunk = Chunk(
        chunk_id=make_chunk_id("doc-bare", 0, text),
        chunk_index=0,
        text=text,
        document_id="doc-bare",
        tenant_id="tenant-bare",
        filename="",          # no filename
        page_number=0,        # no pagination
        document_type=DocumentType.UNKNOWN,
        section=None,         # no section detected
    )
    memory_store.upsert([chunk], embed_in_batches(embedder, [chunk.text]))

    set_pipeline(
        RetrievalPipeline(
            settings=settings,
            model=embedder,
            store=memory_store,
            reranker=LexicalReranker(),
        )
    )
    set_context_builder(ContextBuilder(settings))

    provider = StubProvider(answer_json("Notice is 120 days.", [1]))
    result = AnswerService(settings=settings, provider=provider).answer(
        QUESTION, "tenant-bare"
    )

    citation = result.citations.citations[0]
    assert citation.chunk_id == chunk.chunk_id
    assert citation.section is None
    assert citation.page is None       # never a fabricated page number
    assert citation.document == ""
    assert result.grounded


def test_the_context_block_marks_absent_metadata_explicitly(service_factory):
    provider = StubProvider(answer_json("An answer.", [1]))
    result = service_factory(provider).answer(QUESTION, TENANT_A)
    # Sanity: the block the model saw is the labelled format, so an
    # absent field would have read as "(not detected)" rather than blank.
    assert "Section:" in result.context.text


def test_a_models_invented_metadata_is_overridden_by_the_record(service_factory):
    import json

    reply = json.dumps(
        {
            "answer": "Notice is 120 days.",
            "citations": [
                {"source": 1, "page": 99, "document": "invented.pdf",
                 "section": "12. FABRICATED"}
            ],
        }
    )
    result = service_factory(StubProvider(reply)).answer(QUESTION, TENANT_A)

    citation = result.citations.citations[0]
    source = result.context.source_by_number(1)
    assert citation.page == (source.chunk.page_number or None)
    assert citation.document == source.chunk.filename
    assert citation.claimed["document"] == "invented.pdf"


# =====================================================================
# 7. LLM failure
# =====================================================================


def test_an_unreachable_model_does_not_discard_the_retrieval(service_factory):
    provider = StubProvider(raises=LLMUnavailableError("connection refused"))
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    assert result.status == AnswerStatus.LLM_UNAVAILABLE
    assert result.answer is None
    assert result.context.sources          # the evidence survives
    assert result.retrieval.counts.returned > 0
    assert "connection refused" in result.error
    assert any("could not be reached" in w for w in result.warnings)


def test_a_timeout_is_reported_as_unavailable(service_factory):
    provider = StubProvider(raises=LLMTimeoutError("too slow"))
    result = service_factory(provider).answer(QUESTION, TENANT_A)
    assert result.status == AnswerStatus.LLM_UNAVAILABLE
    assert not result.succeeded


def test_a_misconfigured_model_is_a_distinct_status(service_factory):
    """Retrying will not help, so it must not look like an outage."""
    provider = StubProvider(raises=LLMConfigurationError("no API key"))
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    assert result.status == AnswerStatus.LLM_CONFIGURATION_ERROR
    assert result.answer is None


def test_a_failed_generation_is_not_retried(service_factory):
    """An outage is not a formatting problem; retrying wastes the call."""
    provider = StubProvider(raises=LLMUnavailableError("down"))
    result = service_factory(provider).answer(QUESTION, TENANT_A)
    assert result.attempts == 1


def test_a_failed_generation_reports_no_citations_rather_than_stale_ones(
    service_factory,
):
    provider = StubProvider(raises=LLMUnavailableError("down"))
    result = service_factory(provider).answer(QUESTION, TENANT_A)
    assert result.citations.citations == []


# =====================================================================
# 8. Malformed LLM response
# =====================================================================


def test_an_unparseable_reply_is_retried_once_for_format(service_factory):
    provider = StubProvider(
        ["I think the notice period is 120 days.", answer_json("Notice is 120 days.", [1])]
    )
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    assert result.status == AnswerStatus.OK
    assert result.answer
    assert len(provider.calls) == 2
    assert provider.calls[1].repair is not None


def test_the_retry_asks_about_format_not_content(service_factory):
    """Restating the grounding rules would invite a rewritten answer."""
    provider = StubProvider(["not json", answer_json("Notice is 120 days.", [1])])
    service_factory(provider).answer(QUESTION, TENANT_A)

    repair = provider.calls[1].repair.lower()
    assert "json" in repair
    assert "invent" not in repair
    # The original question is untouched.
    assert provider.calls[1].user == provider.calls[0].user


def test_a_persistently_unparseable_reply_is_reported_not_guessed(service_factory):
    provider = StubProvider(["still not json at all"])
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    assert result.status == AnswerStatus.MALFORMED_RESPONSE
    assert result.answer is None
    assert result.raw_excerpt.startswith("still not json")
    assert result.attempts == 2


def test_a_malformed_reply_still_returns_the_evidence(service_factory):
    provider = StubProvider(["garbage"])
    result = service_factory(provider).answer(QUESTION, TENANT_A)
    assert result.context.sources


def test_a_fenced_reply_is_recovered_and_flagged(service_factory):
    provider = StubProvider(
        [f"```json\n{answer_json('Notice is 120 days.', [1])}\n```"]
    )
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    assert result.status == AnswerStatus.OK
    assert any("not clean JSON" in w for w in result.warnings)
    assert len(provider.calls) == 1


def test_retries_can_be_switched_off(make_settings, indexed_store, embedder):
    from app.context.builder import ContextBuilder, set_context_builder
    from app.retrieval.pipeline import RetrievalPipeline, set_pipeline
    from app.retrieval.rerank import LexicalReranker

    settings = make_settings(llm_max_retries=0)
    set_pipeline(
        RetrievalPipeline(
            settings=settings,
            model=embedder,
            store=indexed_store,
            reranker=LexicalReranker(),
        )
    )
    set_context_builder(ContextBuilder(settings))

    provider = StubProvider(["not json"])
    result = AnswerService(settings=settings, provider=provider).answer(
        QUESTION, TENANT_A
    )

    assert result.status == AnswerStatus.MALFORMED_RESPONSE
    assert len(provider.calls) == 1


def test_a_truncated_reply_names_the_setting_that_fixes_it(service_factory):
    from app.generation.base import LLMResponse

    class Truncating(StubProvider):
        def generate(self, request):
            self.calls.append(request)
            return LLMResponse(
                text=answer_json("Notice is 120 days.", [1]),
                model="stub-1",
                finish_reason="length",
            )

    result = service_factory(Truncating()).answer(QUESTION, TENANT_A)
    assert any("LLM_MAX_OUTPUT_TOKENS" in w for w in result.warnings)


# =====================================================================
# Reporting
# =====================================================================


def test_the_result_reports_which_provider_answered(service_factory):
    provider = StubProvider(answer_json("An answer.", [1]))
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    assert result.provider == "stub"
    assert result.model == "stub-1"
    assert result.is_language_model is True
    assert result.usage["total_tokens"] == 150


def test_a_model_free_provider_says_so(settings, indexed_store, embedder):
    """Nothing may present sentence selection as a generated answer."""
    from app.context.builder import ContextBuilder, set_context_builder
    from app.generation.extractive import ExtractiveProvider
    from app.retrieval.pipeline import RetrievalPipeline, set_pipeline
    from app.retrieval.rerank import LexicalReranker

    set_pipeline(
        RetrievalPipeline(
            settings=settings,
            model=embedder,
            store=indexed_store,
            reranker=LexicalReranker(),
        )
    )
    set_context_builder(ContextBuilder(settings))

    result = AnswerService(
        settings=settings, provider=ExtractiveProvider()
    ).answer(QUESTION, TENANT_A)

    assert result.is_language_model is False
    assert result.answer
    assert result.citations.citations


def test_every_stage_is_timed(service_factory):
    provider = StubProvider(answer_json("An answer.", [1]))
    result = service_factory(provider).answer(QUESTION, TENANT_A)

    for stage in ("retrieval", "context", "generation", "validation"):
        assert stage in result.timings_ms
    assert result.duration_ms >= 0


def test_the_result_serialises(service_factory):
    provider = StubProvider(answer_json("An answer.", [1]))
    data = service_factory(provider).answer(QUESTION, TENANT_A).to_dict()

    assert data["status"] == "ok"
    assert data["answer"]
    assert data["citations"]
    assert "grounded" in data
    assert data["is_language_model"] is True
