"""Stage 5 — query preprocessing.

The invariant under test throughout: the *semantic* form of a query must
stay close to what the user typed, while the *keyword* form must be
stripped down to content terms. Breaking either direction quietly
degrades one retriever without failing anything.
"""

from __future__ import annotations

import pytest

from app.retrieval.query import (
    STOPWORDS,
    normalize_term,
    preprocess_query,
    tokenize,
)


# ---------------------------------------------------------------------
# Normalisation
# ---------------------------------------------------------------------


def test_whitespace_and_unicode_are_normalised():
    processed = preprocess_query("  How  much notice\n\nis required? ")
    assert processed.normalized == "How much notice is required?"


def test_empty_query_is_reported_as_empty():
    for value in ("", "   ", "\n\t", None):
        assert preprocess_query(value).is_empty


def test_non_empty_query_is_not_empty():
    assert not preprocess_query("termination notice").is_empty


def test_semantic_form_keeps_the_question_intact():
    """The embedder gets the sentence, not a bag of terms."""
    query = "Under what circumstances may the Client terminate immediately?"
    processed = preprocess_query(query)
    assert processed.normalized == query
    # ...while the keyword form is reduced.
    assert "terminate" in processed.terms
    assert "under" not in processed.terms or len(processed.terms) < len(query.split())


# ---------------------------------------------------------------------
# Filler
# ---------------------------------------------------------------------


@pytest.mark.parametrize(
    "query,expected_term",
    [
        ("Can you tell me about termination", "terminate"),
        ("What does the contract say about confidentiality", "confidential"),
        ("Please explain the governing law", "govern"),
        # "payment" canonicalises to "pay" - the family mapping at work.
        ("I would like to know the payment terms", "pay"),
        ("According to the agreement, what is the notice period", "notice"),
    ],
)
def test_conversational_filler_is_stripped_from_the_keyword_form(
    query, expected_term
):
    processed = preprocess_query(query)
    assert expected_term in processed.terms
    assert "please" not in processed.terms
    assert "tell" not in processed.terms


def test_filler_stripping_never_empties_the_query():
    """A question that is *only* filler keeps its original text.

    Otherwise "can you tell me" would preprocess to nothing and the
    keyword retriever would silently have no terms to work with.
    """
    processed = preprocess_query("Can you tell me")
    assert processed.keyword_text.strip()


# ---------------------------------------------------------------------
# Terms
# ---------------------------------------------------------------------


def test_stopwords_are_dropped_but_legal_modals_survive():
    """"shall", "may" and "not" carry the entire meaning of a clause."""
    processed = preprocess_query("what the vendor shall not disclose")
    assert "shall" in processed.terms
    assert "not" in processed.terms
    assert "the" not in processed.terms
    for modal in ("shall", "may", "must", "not"):
        assert modal not in STOPWORDS


def test_clause_numbers_survive_tokenisation():
    """"4.2" must be one token; split into "4" and "2" it matches nothing."""
    assert "4.2" in tokenize("see clause 4.2 for details")


@pytest.mark.parametrize(
    "variant,canonical",
    [
        ("termination", "terminate"),
        ("terminating", "terminate"),
        ("indemnification", "indemnify"),
        ("confidentiality", "confidential"),
        ("liabilities", "liable"),
        ("payments", "pay"),
        ("parties", "party"),
        ("fees", "fee"),
    ],
)
def test_legal_word_families_map_to_one_canonical_term(variant, canonical):
    assert normalize_term(variant) == canonical


def test_term_mapping_is_symmetric_between_query_and_corpus():
    """The whole point: a question about terminating finds a TERMINATION
    clause, because both sides are normalised the same way."""
    query_terms = set(preprocess_query("how do I terminate the agreement").terms)
    corpus_terms = set(tokenize("4. TERMINATION\n\nEither party may terminate..."))
    assert query_terms & corpus_terms


def test_defined_terms_are_not_mangled():
    """Party names and defined terms must pass through untouched."""
    assert normalize_term("northwind") == "northwind"
    assert normalize_term("bengaluru") == "bengaluru"
    # A short word ending in 's' is left alone rather than guessed at.
    assert normalize_term("gas") == "gas"


def test_a_query_of_only_stopwords_still_produces_terms():
    """BM25 gets something to work with rather than nothing."""
    processed = preprocess_query("what is it about")
    assert processed.terms


# ---------------------------------------------------------------------
# Legal references
# ---------------------------------------------------------------------


@pytest.mark.parametrize(
    "query,kind,number",
    [
        ("What does clause 4.2 say?", "clause", "4.2"),
        ("Summarise section 7", "section", "7"),
        ("See Article IV", "article", "iv"),
        ("Refer to Schedule B", "schedule", "b"),
        ("Check paragraph 3(a)", "paragraph", "3(a)"),
        ("Sec. 12 please", "section", "12"),
    ],
)
def test_clause_references_are_extracted(query, kind, number):
    assert (kind, number) in preprocess_query(query).references


def test_a_bare_clause_number_is_treated_as_a_reference():
    assert ("clause", "12.3") in preprocess_query("what about 12.3?").references


def test_a_plain_amount_is_not_a_clause_reference():
    """"INR 4,50,000" and "1.5%" must not become clause references."""
    references = preprocess_query("the fee is 1,50,000 and interest is 1.5%")
    numbers = [n for _, n in references.references]
    assert "1,50,000" not in numbers


# ---------------------------------------------------------------------
# Phrases
# ---------------------------------------------------------------------


def test_quoted_phrases_are_captured_verbatim():
    processed = preprocess_query('find the "material breach" clause')
    assert "material breach" in processed.phrases


def test_curly_quotes_are_captured_too():
    processed = preprocess_query("find the “material breach” clause")
    assert "material breach" in processed.phrases


def test_no_quotes_means_no_phrases():
    assert preprocess_query("find the material breach clause").phrases == []


def test_to_dict_is_serialisable():
    data = preprocess_query('clause 4.2 "notice period"').to_dict()
    assert data["references"] == ["clause 4.2"]
    assert data["phrases"] == ["notice period"]
    assert isinstance(data["terms"], list)
