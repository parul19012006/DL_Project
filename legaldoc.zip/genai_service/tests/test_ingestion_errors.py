"""Failure modes: empty, corrupted, unsupported, unsafe, oversized.

Each failure must be *distinguishable* — the backend shows a different
message for "this file is damaged" than for "we don't accept .txt".
"""

from __future__ import annotations

import pytest

from app.exceptions import GenAIServiceError
from app.ingestion.errors import (
    CorruptDocumentError,
    EmptyDocumentError,
    FileNotFoundError_,
    FileTooLargeError,
    IngestionError,
    UnsafePathError,
    UnsupportedFileTypeError,
)
from app.ingestion.service import extract_document, extract_many


def _extract(name, settings, **kwargs):
    defaults = dict(document_id="doc-1", tenant_id="tenant-a", file_path=name)
    defaults.update(kwargs)
    return extract_document(settings=settings, **defaults)


# =====================================================================
# Empty documents
# =====================================================================


def test_blank_pdf_raises_empty_document(blank_pdf, settings):
    with pytest.raises(EmptyDocumentError) as excinfo:
        _extract(blank_pdf.name, settings)
    assert excinfo.value.details["page_count"] >= 1


def test_empty_docx_raises_empty_document(empty_docx, settings):
    with pytest.raises(EmptyDocumentError):
        _extract(empty_docx.name, settings)


def test_empty_document_error_explains_the_cause(blank_pdf, settings):
    with pytest.raises(EmptyDocumentError) as excinfo:
        _extract(blank_pdf.name, settings)
    message = excinfo.value.message.lower()
    assert "no extractable text" in message or "blank" in message


def test_empty_document_is_a_422(blank_pdf, settings):
    with pytest.raises(EmptyDocumentError) as excinfo:
        _extract(blank_pdf.name, settings)
    assert excinfo.value.status_code == 422
    assert excinfo.value.error_type == "empty_document"


# =====================================================================
# Corrupted documents
# =====================================================================


def test_corrupt_pdf_raises_corrupt_document(corrupt_pdf, settings):
    with pytest.raises(CorruptDocumentError) as excinfo:
        _extract(corrupt_pdf.name, settings)
    assert excinfo.value.error_type == "corrupt_document"


def test_corrupt_docx_raises_corrupt_document(corrupt_docx, settings):
    with pytest.raises(CorruptDocumentError):
        _extract(corrupt_docx.name, settings)


def test_corrupt_document_is_distinguishable_from_empty(corrupt_pdf, settings):
    """A damaged file and a blank file need different user messages."""
    with pytest.raises(IngestionError) as excinfo:
        _extract(corrupt_pdf.name, settings)
    assert excinfo.value.error_type != "empty_document"


def test_corrupt_pdf_still_passes_magic_bytes(corrupt_pdf, settings):
    """The fixture is valid enough to reach the parser — that's the point."""
    from app.ingestion.validation import validate_magic_bytes

    validate_magic_bytes(corrupt_pdf, ".pdf")  # must not raise


# =====================================================================
# Unsupported file types
# =====================================================================


def test_unsupported_extension_is_rejected(unsupported_file, settings):
    with pytest.raises(UnsupportedFileTypeError) as excinfo:
        _extract(unsupported_file.name, settings)
    assert excinfo.value.status_code == 415
    assert ".txt" in excinfo.value.message


def test_unsupported_error_lists_what_is_allowed(unsupported_file, settings):
    with pytest.raises(UnsupportedFileTypeError) as excinfo:
        _extract(unsupported_file.name, settings)
    assert ".pdf" in excinfo.value.message


def test_extension_spoofing_is_caught_by_magic_bytes(fake_pdf, settings):
    """A .pdf whose bytes are not a PDF must be rejected before parsing."""
    with pytest.raises(UnsupportedFileTypeError) as excinfo:
        _extract(fake_pdf.name, settings)
    assert "does not match" in excinfo.value.message


def test_a_supported_type_can_be_disabled_by_config(contract_pdf, make_settings):
    cfg = make_settings(allowed_extensions=".docx")
    with pytest.raises(UnsupportedFileTypeError):
        _extract(contract_pdf.name, cfg)


# =====================================================================
# Missing files and unsafe paths
# =====================================================================


def test_missing_file_raises_not_found(settings):
    with pytest.raises(FileNotFoundError_) as excinfo:
        _extract("no_such_document.pdf", settings)
    assert excinfo.value.status_code == 404


@pytest.mark.parametrize(
    "path",
    [
        "../../etc/passwd",
        "../../../etc/shadow",
        "/etc/passwd",
        "subdir/../../../etc/hosts",
    ],
)
def test_path_traversal_is_rejected(path, settings):
    with pytest.raises(UnsafePathError):
        _extract(path, settings)


def test_null_byte_in_path_is_rejected(settings):
    with pytest.raises(UnsafePathError):
        _extract("contract\x00.pdf", settings)


def test_empty_path_is_rejected(settings):
    with pytest.raises(UnsafePathError):
        _extract("", settings)


def test_symlink_out_of_the_root_is_rejected(doc_root, settings, tmp_path):
    """resolve() follows the link, so containment still catches it."""
    outside = tmp_path / "outside.pdf"
    outside.write_bytes(b"%PDF-1.4\n")
    link = doc_root / "sneaky_link.pdf"
    link.unlink(missing_ok=True)
    try:
        link.symlink_to(outside)
    except OSError:  # pragma: no cover - platform without symlinks
        pytest.skip("symlinks are unavailable here")
    try:
        with pytest.raises(UnsafePathError):
            _extract("sneaky_link.pdf", settings)
    finally:
        link.unlink(missing_ok=True)


def test_a_directory_is_not_a_document(doc_root, settings):
    target = doc_root / "a_folder.pdf"
    target.mkdir(exist_ok=True)
    try:
        with pytest.raises(UnsafePathError):
            _extract("a_folder.pdf", settings)
    finally:
        target.rmdir()


# =====================================================================
# Identifiers
# =====================================================================


@pytest.mark.parametrize(
    "bad", ["", "a/b", "../x", "x" * 200, "drop table;", "tenant id", "a\x00b"]
)
def test_invalid_identifiers_are_rejected(bad, contract_pdf, settings):
    with pytest.raises(UnsafePathError):
        _extract(contract_pdf.name, settings, tenant_id=bad)


@pytest.mark.parametrize(
    "good",
    ["tenant-a", "665e02b41f9c8d7e6f5a4b3c", "user_42", "a.b:c@d", "A1"],
)
def test_valid_identifiers_are_accepted(good, contract_pdf, settings):
    document = _extract(contract_pdf.name, settings, tenant_id=good)
    assert document.metadata.tenant_id == good


# =====================================================================
# Size limits
# =====================================================================


def test_oversized_file_is_rejected(contract_pdf, make_settings):
    """A 1 MB limit against a real (small) PDF, via the validator."""
    from app.ingestion.validation import validate_size

    cfg = make_settings(max_file_size_mb=1)
    with pytest.raises(FileTooLargeError) as excinfo:
        validate_size(2 * 1024 * 1024, cfg)
    assert excinfo.value.status_code == 413
    assert "1 MB" in excinfo.value.message


def test_zero_byte_file_is_rejected(doc_root, settings):
    target = doc_root / "zero_bytes.pdf"
    target.write_bytes(b"")
    try:
        with pytest.raises(UnsupportedFileTypeError):
            _extract("zero_bytes.pdf", settings)
    finally:
        target.unlink(missing_ok=True)


# =====================================================================
# Error hierarchy
# =====================================================================


def test_every_ingestion_error_is_a_service_error():
    for error in (
        UnsupportedFileTypeError(),
        FileTooLargeError(),
        CorruptDocumentError(),
        EmptyDocumentError(),
        UnsafePathError(),
        FileNotFoundError_(),
    ):
        assert isinstance(error, IngestionError)
        assert isinstance(error, GenAIServiceError)
        assert error.error_type and error.message


def test_error_types_are_distinct():
    types = {
        UnsupportedFileTypeError.error_type,
        FileTooLargeError.error_type,
        CorruptDocumentError.error_type,
        EmptyDocumentError.error_type,
        UnsafePathError.error_type,
        FileNotFoundError_.error_type,
    }
    assert len(types) == 6


# =====================================================================
# Batch isolation
# =====================================================================


def test_one_bad_document_does_not_stop_a_batch(
    contract_pdf, corrupt_pdf, nda_docx, settings
):
    results = extract_many(
        [
            {
                "document_id": "ok-1",
                "tenant_id": "tenant-a",
                "file_path": contract_pdf.name,
            },
            {
                "document_id": "bad-1",
                "tenant_id": "tenant-a",
                "file_path": corrupt_pdf.name,
            },
            {
                "document_id": "ok-2",
                "tenant_id": "tenant-a",
                "file_path": nda_docx.name,
            },
        ],
        settings=settings,
    )

    assert [r["status"] for r in results] == ["success", "failed", "success"]
    assert results[1]["error"].error_type == "corrupt_document"
    assert results[0]["document"].page_count >= 1
    assert results[2]["document"].page_count >= 1


def test_batch_reports_each_failure_reason(
    corrupt_pdf, unsupported_file, settings
):
    results = extract_many(
        [
            {
                "document_id": "bad-1",
                "tenant_id": "tenant-a",
                "file_path": corrupt_pdf.name,
            },
            {
                "document_id": "bad-2",
                "tenant_id": "tenant-a",
                "file_path": unsupported_file.name,
            },
            {
                "document_id": "bad-3",
                "tenant_id": "tenant-a",
                "file_path": "missing.pdf",
            },
        ],
        settings=settings,
    )
    reasons = [r["error"].error_type for r in results]
    assert reasons == [
        "corrupt_document",
        "unsupported_file_type",
        "document_not_found",
    ]
