# LegalDocAI — GenAI Service

**An independent Python AI microservice, consumed by the MERN backend over HTTP.**

> **Build stage: 9 — hardened for ~500 documents.**
> Stages 1–7 (ingestion, chunking, embeddings, vector index, hybrid
> retrieval with reranking, context construction, grounded generation
> with validated citations), exposed as five endpoints a Node/Express
> backend consumes: `POST /ingest`, `POST /ingest/batch`, `POST /query`,
> `DELETE /documents/{document_id}`, `GET /health` — then measured and
> hardened at ~500 documents in a single tenant.
>
> **[§9 is the integration guide](#9-integrating-from-node--express)**, with
> a working `curl` for every endpoint and a minimal Express client.
> **[§1g is the hardening report](#1g-hardening-for-500-documents-stage-9)**
> — what was measured, what changed because of it, and what remains true.
>
> At 500 documents: retrieval **131 ms → 11.8 ms**, re-ingesting an
> unchanged corpus **32.8 s → 1.7 s**, peak RSS unchanged at ~223 MB.
> Ingestion timings are measured with the deterministic encoder and are a
> floor, not a forecast — §1g says why.
>
> Answers are produced **only** from passages retrieved from the caller's
> own documents, and every citation is checked against those passages.
> That reduces ungrounded output and makes each citation verifiable; it
> does not guarantee a model states only what the evidence supports, and
> `grounded: false` on a response means exactly that the answer could not
> be fully checked.

This service does **not** contain — and must not be extended with — React,
Tailwind, Node.js, Express, MongoDB, JWT authentication, the frontend, the
upload dashboard, the PDF viewer or the chat UI. Those belong to the MERN
developer. The boundary is exact:

```
Python AI service  →  FastAPI endpoint  →  JSON response  →  (MERN consumes it)
```

---

## 1. The ingestion pipeline

```
  file path or multipart upload
              │
              ▼
  ┌───────────────────────────┐   path confined to DOCUMENT_ROOT
  │ 1. VALIDATE               │   extension allow-list
  │    validation.py          │   magic bytes must match extension
  │    tempfiles.py           │   size limit (streamed, bounded memory)
  └───────────┬───────────────┘   identifiers validated
              ▼
  ┌───────────────────────────┐   registry lookup by extension
  │ 2. PARSE                  │
  │    ┌──────────────────┐   │   PDF  → PyMuPDF, block-level, per page
  │    │ pdf_parser.py    │   │          page yields < N chars?
  │    │   └─ ocr.py      │───┼──────►   rasterise @ DPI → Tesseract
  │    ├──────────────────┤   │          keep OCR only if it's better
  │    │ docx_parser.py   │   │   DOCX → python-docx, body-XML order,
  │    └──────────────────┘   │          heading styles, tables,
  └───────────┬───────────────┘          synthetic pages
              ▼
  ┌───────────────────────────┐   NFKC · ligatures · smart quotes
  │ 3. CLEAN                  │   control + replacement characters
  │    cleaner.py             │   de-hyphenation · soft-wrap rejoin
  │    (document-level pass)   │   running headers/footers · page numbers
  └───────────┬───────────────┘   OCR speckle
              ▼
  ┌───────────────────────────┐   "4.2 Termination", "ARTICLE V",
  │ 4. SECTIONS               │   "SCHEDULE B", ALL-CAPS headings
  │    sections.py            │   carried forward across blocks & pages
  └───────────┬───────────────┘
              ▼
  ┌───────────────────────────┐   emptiness check (with a reason)
  │ 5. ASSEMBLE               │   metadata + SHA-256 + type inference
  │    service.py             │   statistics
  └───────────┬───────────────┘
              ▼
        ExtractedDocument  ──►  Stage 3 (chunking) consumes iter_blocks()
```

Everything after parsing is **format-independent**: a PDF and a DOCX get the
same cleaning, the same section logic and the same emptiness rule. A new
format only has to produce pages.

---

## 1b. The chunking pipeline

```
   ExtractedDocument  (Stage 2)
              │
              ▼
  ┌───────────────────────────┐  a segment is a run of blocks sharing a
  │ 1. SEGMENT                │  section label. A chunk may never span
  │    (section boundaries)   │  two segments, so one chunk = one clause.
  └───────────┬───────────────┘  No sections detected? One segment; falls
              ▼                  back to paragraph packing. Both normal.
  ┌───────────────────────────┐
  │ 2. SPLIT oversized blocks │  paragraph → enumerated item → sentence
  │    (boundary hierarchy)   │  → word window → character window
  └───────────┬───────────────┘  each level only reached when the one
              ▼                  above still produced something too big
  ┌───────────────────────────┐
  │ 3. PACK greedily          │  fill to body_budget = size − overlap
  │    + attach headings      │  a heading is never a chunk on its own
  └───────────┬───────────────┘
              ▼
  ┌───────────────────────────┐  sentence-aligned tail of the previous
  │ 4. OVERLAP                │  chunk, ≤ overlap tokens, never across
  │                           │  a section boundary
  └───────────┬───────────────┘
              ▼
  ┌───────────────────────────┐  body text merges within a section only;
  │ 5. MERGE small chunks     │  heading-only chunks merge forward across
  │                           │  sections. Never past max_tokens.
  └───────────┬───────────────┘
              ▼
  ┌───────────────────────────┐  index, document metadata, deterministic
  │ 6. FINALISE               │  chunk_id — assigned last, from the final
  └───────────┬───────────────┘  text, so merging can't leave a stale id
              ▼
        Chunk[]  ──►  Stage 4 embeds Chunk.text with Chunk.metadata()
```

### The Chunk

`app/models/chunk.py`. Every required field, plus what retrieval will need:

```
chunk_id  chunk_index  text
document_id  tenant_id  filename  page_number  section  document_type
page_end  block_ids  token_count  char_count  overlap_tokens
ocr  split_mid_sentence  heading_only  extra
```

`Chunk.metadata()` returns a **flat, scalar-only** dict — what a vector
database accepts as filterable metadata. `Chunk.citation()` returns the
minimum a user needs to find the passage in the original.

### Why this strategy suits legal documents

**A clause is the unit of meaning, so it is the unit of retrieval.** A
termination clause answers a termination question; half a termination clause
plus the opening of the liability clause answers neither and actively misleads.
Section-bounded segments mean a chunk is at most one clause, never a blend of
two.

**Headings travel with their text.** "4. TERMINATION" embedded alone matches
every termination query while containing no obligation. Attached to the clause
body it sharpens the embedding *and* gives the eventual citation its label.

**Enumerated items beat sentences as a cut point.** `(a) … (b) … (c)` lists are
everywhere in contracts, and half an item reads as an obligation without its
subject. When a paragraph must be split, item boundaries are preferred.

**Overlap makes boundary-spanning answers retrievable.** A notice period stated
in one sentence and qualified in the next survives a cut between them, because
~50 tokens of the previous chunk open the next one. The overlap is
sentence-aligned so it reads as language, not as a fragment.

**Abbreviations are not sentence ends.** Naive full-stop splitting breaks
`Art. 9`, `Sec. 4`, `Pvt. Ltd.`, `approx. 5000` and every cross-reference in
the document. The splitter knows the common ones.

**Small chunks are prevented, not tolerated.** A 12-token chunk embeds to a
vector close to everything and informative about nothing — it crowds out real
evidence in the top-k. But merging is restricted to a single section, so a
short clause that is complete on its own is kept rather than glued to its
neighbour.

**Determinism makes re-indexing safe.** Same document and settings produce
byte-identical chunks and identical ids, so re-ingestion is idempotent and
existing citations keep resolving. Changed text changes the id, so a stale
vector cannot masquerade as the current passage.

### Limitations of this strategy

- **Token counts are approximate by default.** The heuristic counter runs
  ~±15% against real BPE, so "500 tokens" is a target, not a guarantee. Set
  `TOKENIZER=tiktoken`, or let Stage 4 install the embedding model's own
  tokenizer via `set_token_counter()`, to make it exact.
- **Section detection is inherited from Stage 2 and is heuristic.** A document
  whose headings are not recognised chunks on paragraph boundaries only — still
  correct, but without the clause guarantee. Multi-column layouts and unusual
  numbering are where this shows.
- **A clause longer than the budget is still cut.** The cut lands at the best
  available boundary and the chunk is flagged `split_mid_sentence`, but a
  2000-token indemnity is not retrievable as one passage.
- **Overlap costs storage and can duplicate hits.** At 500/50 the index carries
  roughly 10% redundant text, and two adjacent chunks can both match the same
  sentence — the reranker in Stage 5 is what deduplicates that.
- **Tables lose their structure.** Stage 2 flattens them to pipe-separated
  rows; a table split across chunks loses its header row, so the second half
  has columns with no names.
- **Cross-references are not resolved.** A chunk saying "subject to Clause 8"
  does not contain Clause 8. Retrieval may return one without the other.
- **Definitions are far from their use.** "Services" is defined in clause 1 and
  used in clause 12; the clause-12 chunk carries the term, not its definition.
- **No semantic chunking.** Boundaries are structural, not meaning-based. Two
  paragraphs about different topics under one heading land in one chunk if
  they fit.
- **`heading_only` chunks with nothing after them survive.** A heading at the
  very end of a document has nothing to merge into, and dropping it would lose
  text — so a rare low-value chunk is preferred over silent data loss.

---

## 1c. Embeddings and vector storage

```
   Chunk[]  (Stage 3)
        │
        ▼
  ┌──────────────────────────┐   EmbeddingModel (interface)
  │ EMBED                    │   ├── SentenceTransformerEmbedding  ← production
  │  embeddings/             │   └── DeterministicEmbedding        ← dev/CI
  └───────────┬──────────────┘   dimension READ FROM THE MODEL
              │                  batched, order-preserving
              ▼
  ┌──────────────────────────┐   VectorStore (interface)
  │ STORE                    │   ├── ChromaVectorStore   ← persistent default
  │  vectorstore/            │   └── InMemoryVectorStore ← conformance + tests
  └───────────┬──────────────┘   built at the model's dimension
              │
              ▼
   query ──► embed ──► search(SearchFilter) ──► SearchHit[]
                       tenant scoping mandatory
```

### The dimension is never assumed

A hard-coded 768 is the classic way to break a vector pipeline: it is right
for `all-mpnet-base-v2` and wrong for `all-MiniLM-L6-v2` (384),
`bge-large-en` (1024) and `text-embedding-3-large` (3072). So:

- **there is no `EMBEDDING_DIMENSION` setting** — a configured value could
  only ever be a chance to disagree with the model;
- the wrapper discovers the width from `get_embedding_dimension()`, falls
  back to the pooling module, and **always** confirms it with a probe encode;
- a model whose config and output disagree is **refused**, not indexed;
- the vector collection is created at that discovered width and records it,
  so switching models is reported as a clear "re-index required" error
  rather than a corrupt index;
- the store is constructed *by asking the model*, so it cannot be built at
  any other width.

Verified live against a real Sentence-Transformers model at **96
dimensions** — the collection came up at 96, indexed, searched, and refused
a 768-wide model afterwards.

### The vector store abstraction

The RAG pipeline depends on `VectorStore`, `SearchFilter` and `SearchHit` —
never on a backend client, a backend's filter dialect, or a backend's result
shape. Swapping ChromaDB for Pinecone is one adapter plus one
`register_backend()` call.

Three decisions make that real rather than aspirational:

**Tenant scoping is a constructor argument, not a filter you remember to
add.** `SearchFilter` raises without a `tenant_id`, so an unscoped query is
unrepresentable. In a legal product, one tenant retrieving another's
contracts is the worst possible bug.

**Filters are a portable clause vocabulary.** Chroma wants
`{"$and": [{"k": {"$eq": v}}]}`, Pinecone wants `{"k": {"$eq": v}}`,
pgvector wants SQL. `SearchFilter.to_clauses()` emits
`[{field, op, value}, …]` and each adapter translates. Leaking Chroma's
syntax upward would defeat the whole exercise.

**Scores are normalised to higher-is-better.** Chroma returns cosine
*distance*, Pinecone returns cosine *similarity*, FAISS returns L2. Ranking
code should not have to know which.

`VECTOR_BACKEND` is deliberately a free string rather than a `Literal`:
registering a new backend must not require editing `config.py`. An unknown
name is rejected by the factory with a message listing what is available.

The in-memory backend exists for two reasons, both load-bearing: an
interface with one implementation is an unverified claim, and
`tests/test_vectorstore.py` runs **every** conformance test against **both**
backends. That file is the specification a Pinecone adapter has to satisfy.

### Stable ids and duplicate handling

Chunk ids are deterministic (Stage 3), and the vector id *is* the chunk id.
Consequences:

- re-indexing an unchanged document upserts onto itself — idempotent, no
  duplicates, verified over three consecutive runs;
- an *edited* document produces different chunks, and the old ones would
  linger and keep being retrieved, so indexing deletes the document's
  existing chunks first (`REPLACE_ON_REINDEX`);
- a duplicate id *within one batch* is normalised to last-wins in
  `dedupe_by_chunk_id`, because Chroma raises on it while a dict-backed
  store silently accepts it — the abstraction has to hide that difference.

### Honest limitations

- **The deterministic encoder is not semantic.** It hashes tokens, so
  "terminate the agreement" and "end the contract" are near-orthogonal to
  it. It exists to keep CI hermetic and to prove the interface; `/health`
  reports `degraded` whenever it is standing in for a real model.
- **Search is vector-only.** No keyword matching, no reranking, no fusion —
  exact clause numbers and defined terms will be retrieved unreliably until
  Stage 5.
- **Chroma is single-node.** Embedded and file-backed: fine for one service
  instance with a persistent volume, not for multiple replicas writing
  concurrently. That is the point at which the Pinecone adapter gets written.
- **Indexing is synchronous**, and now includes model inference — a large
  batch will take minutes.
- **Changing the embedding model requires a full re-index.** Vectors from
  model A are meaningless in an index built with model B; the store refuses
  the mismatch rather than accepting poisoned vectors.
- **`torch` is a ~2 GB install.** The first genuinely heavy dependency.

---

## 1d. Hybrid retrieval (Stage 5)

```
   user query
        │
        ▼
  ┌──────────────────────────┐   retrieval/query.py
  │ 1. PREPROCESS            │   normalise · strip filler · extract
  │                          │   clause refs and quoted phrases
  └───────────┬──────────────┘   semantic form ≠ keyword form
              │
      ┌───────┴────────┐
      ▼                ▼
 ┌──────────┐    ┌──────────┐    retrieval/semantic.py  (vectors)
 │2.SEMANTIC│    │3. KEYWORD│    retrieval/keyword.py   (Okapi BM25)
 │ ~18 cand.│    │ ~18 cand.│    both through the SAME SearchFilter
 └────┬─────┘    └─────┬────┘
      └───────┬────────┘
              ▼
  ┌──────────────────────────┐   retrieval/fusion.py
  │ 4. HYBRID MERGE          │   reciprocal rank fusion (default)
  │                          │   or weighted score fusion
  └───────────┬──────────────┘
              ▼
  ┌──────────────────────────┐   retrieval/rank.py
  │ 5. CANDIDATE RANKING     │   clause-reference · phrase · agreement
  │                          │   · heading boosts; named clause PINNED
  └───────────┬──────────────┘
              ▼
  ┌──────────────────────────┐   retrieval/dedup.py
  │ 6. DEDUPLICATE           │   character shingles + Jaccard
  └───────────┬──────────────┘   Stage 3's overlap is exempt
              ▼
  ┌──────────────────────────┐   retrieval/rerank.py
  │ 7. RERANK                │   cross-encoder, lexical fallback
  │  ~5-8 results            │   blended with the retrieval score
  └───────────┬──────────────┘
              ▼
   relevant chunks, full provenance intact
```

Every stage is its own module, so any one of them can be replaced without
touching the others. `retrieval/pipeline.py` contains the ordering and
nothing else.

### Why two retrievers

They fail in opposite directions, and legal documents provoke both failures.

Embeddings are lossy exactly where legal text is precise. A 384-dimension
vector does not reliably encode that a clause is numbered 7.3, that the
cap is "USD 50,000", that the seat of arbitration is Bengaluru, or that the
defined term is "Permitted Recipient". Ask for any of those and vector
search returns passages about the right *topic* while the passage holding
the actual number sits at rank 40.

BM25 finds that passage at rank 1 — and cannot match "how much warning
before the contract ends" to a clause headed TERMINATION, because they
share no words. Neither signal is dropped; fusion is how they are combined
without either one's scale swamping the other.

### Why retrieve ~18 and return ~6

A cross-encoder can only promote a passage retrieval handed it. Retrieve 5
and the reranker's job is reduced to reordering 5 — if the right passage
was 7th, no amount of reranking recovers it. Retrieving ~18 and reranking
down to ~6 puts the cheap, high-recall stage in front of the expensive,
high-precision one, which is the whole point of the two-stage design. The
cost is linear in the pool and small: ~18 cross-encoder pairs is
milliseconds on CPU. Section 7 below has the fuller argument.

### Fusion: rank-based by default

Cosine similarity is bounded and roughly comparable across queries; BM25 is
unbounded and means nothing except relative to the current corpus. Adding
them is meaningless. Reciprocal rank fusion scores `weight / (k + rank)` in
each list and sums, so only *positions* matter and no normalisation
assumption can be wrong. A passage ranked 2nd by vectors and 3rd by BM25
beats one ranked 1st by vectors and absent from BM25 — agreement between
two independent signals is stronger evidence than one signal's confidence.

Weighted score fusion is available (`FUSION_METHOD=weighted`) and is more
controllable once tuned on a real corpus. It is not the default because a
candidate missing from one list contributes 0 for that signal, which
punishes a strong semantic hit merely for falling outside the keyword
cut-off.

### Ranking: signals fusion cannot see

Fusion knows only positions. It does not know that the user asked about
*clause 7.3* and that one candidate's section **is** 7.3. Four additive,
bounded, named boosts are applied — clause reference, exact quoted phrase,
agreement between retrievers, query term in the section heading — and each
one is reported per result, because "why was this passage retrieved?" is a
question a legal product has to be able to answer.

One of them is more than a boost. When the query names a clause and a
candidate's *section* is that clause, the candidate is **pinned**: no later
stage may demote it. This was not theoretical tidiness — the live run of
"what does clause 8 say" returned clause **7** first, because clause 7
contains the literal string "Clause 8" and clause 8's own text does not.
A relevance model is a good judge of whether a passage is about a question;
it is not entitled to overrule an explicit citation.

### Duplicate removal

Duplicates arrive three ways, all of them normal: Stage 3's deliberate
chunk overlap, boilerplate clauses repeated across every contract a firm
holds, and the same agreement uploaded twice. The last two waste the
generation budget — eight passages that are really two.

Character shingles and Jaccard similarity, with a high threshold (0.85) and
an explicit exemption for adjacent chunks of one document, so the overlap
Stage 3 created on purpose is never collapsed. The survivor keeps the
dropped `chunk_id`s in `duplicates`, so the second copy's citation is still
available even though its text is not repeated.

### Reranking, and being honest about the fallback

A bi-encoder compares two vectors computed without knowledge of each other;
the query's vector cannot attend to the passage's words. A cross-encoder
reads query and passage **together** in one forward pass. It cannot search
an index, but scoring ~18 candidates is cheap, and it is markedly better at
the distinction that matters: is this passage *about* the question, or
merely about the same subject matter?

The model is `cross-encoder/ms-marco-MiniLM-L-6-v2` — ~90 MB, 6 layers,
CPU-friendly, deliberately not a large reranker.

When it cannot be loaded — no network on first boot, an air-gapped
deployment, this development sandbox — a `LexicalReranker` takes over:
query-term coverage with a phrase bonus. It is **not** a cross-encoder and
nothing in the system pretends otherwise. `/health` reports the component
as degraded, `/retrieve/config` names the reranker actually in use, and
every `/retrieve` response carries `rerank_is_cross_encoder: false`. Set
`RERANK_STRICT=true` to make a missing model fatal instead, which is the
right choice in production: being down beats silently ranking worse.

The final score is a **blend** (`RERANK_WEIGHT`, default 0.85), not a
replacement. Handing the ordering entirely to the reranker discards the
agreement signal hybrid retrieval just computed — and makes the fallback's
opinion the only one that counts wherever the real model is missing.

### Honest limitations

- **The BM25 index is rebuilt on every query** *(fixed in Stage 9 — see
  [§1g](#1g-hardening-for-500-documents-stage-9), point 9)*. The objection
  written here at Stage 5 was that a cache needs invalidating on every
  index, re-index and delete, per tenant, and that a stale index cites
  documents the user has deleted. That objection was right, and it is why
  the Stage 9 cache is keyed on a **per-tenant write counter** every store
  write path bumps, rather than on a TTL: invalidation is exact and there is
  no window in which a deleted document can be served. Measured at 20,000
  chunks in one tenant, it took a keyword query from 4,372 ms to 122 ms. The
  counter is per-process, so `KEYWORD_CACHE_ENABLED=false` is required for
  multi-writer deployments, and a persisted incrementally-maintained
  inverted index remains the right answer beyond one machine.
- **Duplicate detection is lexical, not semantic.** Two passages that say
  the same thing in different words are not detected.
- **The term-family table is hand-written.** It covers the ~25 word families
  that matter in contracts; a family it does not know is left alone. This is
  a deliberate trade against a stemmer, which maps "arbitrary" and
  "arbitration" together and mangles defined terms.
- **Ranking boosts are hand-tuned, not learned.** They are explainable and
  bounded, which is why they were chosen, but the values are judgement.
- **No query expansion or multi-query retrieval.** A question that needs to
  be split into two searches is answered by one.

---

## 1e. RAG context construction (Stage 6)

```
   retrieved / reranked passages
              │
              ▼
  ┌───────────────────────────┐   context/selection.py
  │ 1. SELECT                 │   score floor · redundancy removal
  │    (relevance order)      │   hard cap on source count
  └───────────┬───────────────┘   every drop recorded with its citation
              ▼
  ┌───────────────────────────┐   context/budget.py
  │ 2. FIT THE BUDGET         │   headers charged to the budget
  │    (relevance order)      │   per-source ceiling · sentence-aligned
  └───────────┬───────────────┘   truncation, always declared
              ▼
  ┌───────────────────────────┐   context/ordering.py
  │ 3. ORDER                  │   document order: strongest document
  │    (document order)       │   first, reading order within it
  └───────────┬───────────────┘
              ▼
  ┌───────────────────────────┐   Source 1..N, continuations marked
  │ 4. NUMBER                 │   after ordering, so "Source 3" is
  └───────────┬───────────────┘   the third block the model sees
              ▼
  ┌───────────────────────────┐   context/formatter.py
  │ 5. RENDER                 │   uniform labelled blocks
  └───────────┬───────────────┘
              ▼
   BuiltContext:  text + sources + omitted + stats + citations
```

The output block:

```
Source 1:
Document: vendor_contract_2024.pdf (id: doc-msa-001)
Page: 2
Section: 4. TERMINATION
Chunk: 3 (id: 2896bf74d708)
Text:
Either party may terminate this Agreement for convenience on one hundred
and twenty (120) days written notice to the other party. …

---

Source 2:
Document: mutual_nda_2024.docx (id: doc-nda-002)
Page: 1
Section: 3. TERMINATION
Chunk: 2 (id: e80864f434af)
Continues: Source 1
Note: Text recovered by OCR from a scanned page; wording may contain
recognition errors.
Text:
This Agreement terminates two (2) years from the date of signature. …
```

`Continues:`, `Also appears in:` and `Note:` lines appear only when they
apply. Each states a **fact**; none states an instruction. Instructions
belong in the prompt template, which is the generation stage's to own —
writing one here would fix it for every future caller.

### Two orderings, deliberately different

Selection and budgeting run in **relevance order**, so the strongest
evidence gets first call on the space. Presentation runs in **document
order**, so the model reads clauses in the sequence the contract states
them.

That second choice matters more than it looks. Legal text is sequential
and self-referential: Clause 4 says "subject to Clause 8", Clause 8
qualifies Clause 4, and a definition in Clause 1 governs everything after
it. Presented in score order those read as a pile, and a model has to
reconstruct the sequence before it can use it — worse, two adjacent
chunks of one clause can end up separated by a passage from a *different*
contract, which is the juxtaposition most likely to produce a confidently
blended answer. Numbering is assigned **after** ordering, so a citation of
"Source 3" resolves to the third block the model actually saw.

### The budget

The header costs about 50 tokens per source. Counting only passage text
under-counts a six-source context by 300 tokens, and an over-full prompt
is truncated by the provider from one end — usually silently, usually
taking the last source with it. So every block is priced by rendering it
and counting the result.

Two rules keep truncation from doing more harm than the overflow would:

- **A passage shortened below `CONTEXT_MIN_SOURCE_TOKENS` is dropped, not
  truncated.** Half a termination clause reads as a complete obligation
  with the wrong conditions attached — worse input than no passage.
- **The cut lands on a sentence boundary when that is affordable.** Legal
  sentences are long and uneven, so "the last whole sentence that fits"
  can land far short of the budget; when it would waste more than a
  quarter of the space, the budget is filled on a word boundary instead.
  Either way the block declares that it was shortened and by how much.

### Nothing is dropped silently

Every passage that does not reach the prompt appears in `omitted` with its
citation and a machine-readable reason — `below_score_floor`, `redundant`,
`max_sources`, `budget_exhausted`, `too_small_to_truncate`, `empty_text`.
"Did you look at clause 9?" has an answer. A passage collapsed as a
duplicate keeps both citations, and the surviving block says
`Also appears in:`.

`BuiltContext.citations()` returns the "Sources" list ready to render, so
the backend never parses the prompt block to find out what was cited — a
regex over a prompt is a bad foundation for a citation feature.

### Honest limitations

- **Header overhead is real: ~40% of a small context.** Four sources in a
  500-token block cost ~215 tokens of provenance. That is the price of
  citable evidence, and it is reported as `overhead_tokens` rather than
  hidden. Larger budgets amortise it.
- **Declaring a truncation costs ~30 tokens.** On a very tight budget the
  honesty about shortening consumes space the passage could have used. It
  is still the right trade — silently truncated evidence is the failure
  this stage exists to prevent — but it is a real cost.
- **Token counts are approximate** unless `TOKENIZER=tiktoken` is set, and
  they are the *embedding* tokenizer's view, not necessarily the LLM's.
  Keep the budget clear of the model's real window.
- **Redundancy detection is lexical.** Two passages that say the same
  thing in different words both reach the prompt.
- **No summarisation or compression.** A passage is included whole,
  shortened from the end, or left out; nothing is rewritten. Rewriting
  evidence before an LLM quotes it is a poor trade in a legal product.
- **Duplicates already collapsed by Stage 5 arrive as bare chunk ids**, so
  their citations are listed as ids in `duplicates` rather than rendered
  as `Also appears in:`. Only duplicates the builder collapses itself
  carry full citations into the block.
- **No conversation history, and no cross-encoder scoring of the assembled
  whole.** Each passage is judged on its own.

---

## 1f. Grounded generation (Stage 7)

```
   question
      │
      ▼
  ┌───────────────────────────┐
  │ RETRIEVE + BUILD CONTEXT  │   Stages 5 and 6, unchanged
  └───────────┬───────────────┘
              │           no evidence? ──► fixed refusal, model NOT called
              ▼
  ┌───────────────────────────┐   generation/prompts.py
  │ PROMPT                    │   10 grounding rules + labelled
  │                           │   QUESTION / EVIDENCE sections
  └───────────┬───────────────┘
              ▼
  ┌───────────────────────────┐   generation/factory.py
  │ LLM PROVIDER              │   openai | anthropic | extractive
  │                           │   keys from the environment only
  └───────────┬───────────────┘
              ▼
  ┌───────────────────────────┐   generation/parser.py
  │ PARSE                     │   lenient on packaging, strict on shape
  └───────────┬───────────────┘   one retry, about format only
              ▼
  ┌───────────────────────────┐   generation/citations.py
  │ VALIDATE CITATIONS        │   every citation must name a source that
  │                           │   was actually retrieved; metadata comes
  └───────────┬───────────────┘   from the record; quotes are checked
              ▼
   {answer, citations[], interpretation, grounded, validation, sources}
```

### The provider abstraction

`LLMProvider` is the seam. The pipeline depends on it and on two
dataclasses — never on an SDK, a vendor's message format, or a vendor's
error classes.

| Provider | What it is |
|---|---|
| `openai` | `/chat/completions`. Also covers Azure OpenAI, Together, Groq, Fireworks, vLLM, Ollama and LM Studio — point `LLM_BASE_URL` at the other server and nothing else changes |
| `anthropic` | The Messages API. System prompt is a top-level field, reply is a list of content blocks |
| `extractive` | **Not a language model.** Deterministic sentence selection from the evidence. The offline default |

Adding a vendor is one module and one `register_provider` call — no edit
to `config.py`, no change to any caller, because no caller names a
provider.

**No vendor SDK.** `openai` and `anthropic` are each a dependency tree and
a release cadence wrapped around one HTTP POST. These use `httpx`, which
was already installed for the test client. Stage 7 adds **no new
dependency at all**.

**Why `extractive` exists.** The same reason the deterministic embedder
and the lexical reranker do: the pipeline has to be runnable and testable
without a network, a key or a bill, and the whole Stage 7 path has to be
exercisable in CI on every commit. It quotes the evidence verbatim and
cites what it quoted. It cannot reason, compare or synthesise, and
nothing presents its output as generated prose — `is_language_model` is
false on the provider, in every response, in `/answer/config` and in
`/health`.

### Secrets

`OPENAI_API_KEY` and `ANTHROPIC_API_KEY` are read from the environment
and nowhere else. There is no request field, no header and no config file
that can supply one. They are held as `SecretStr`, so an accidental
`repr()` of the settings prints a mask; they are never logged, never
included in an error message (an error carries the vendor's message and
the status code, not the request), and `/answer/config` reports only
*whether* a key is present.

### The grounding prompt

Ten rules, in the order they matter: answer from the evidence only; do
not invent facts; do not invent legal clauses; do not invent dates,
parties, amounts or case details; do not pretend to knowledge you do not
have; say so when the evidence is insufficient; keep interpretation
separate from what the documents state; cite your sources; quote exactly;
reply with JSON only.

Three choices in how that is delivered:

- **The question and the evidence are separate labelled sections.** Stage
  6 renders no question and no instructions into the context block; this
  stage assembles them. A model can then never mistake a phrase from the
  question for a phrase from a document.
- **Interpretation gets its own field**, not an inline label. Asking a
  model to mark inferences inside prose produces hedging that is hard to
  parse and easy to lose in rendering. A separate field makes the
  distinction structural.
- **Citations are asked for by source *number* only.** The model does not
  restate a filename, page or chunk id; every other field is filled in
  from the record afterwards. A model asked to reproduce metadata will
  sometimes reproduce it wrongly, and a wrong page number in a legal
  citation is worse than none, because it looks checkable.

### Citation validation

Nothing the model says about a source is trusted.

- **A citation must name a source that was in the context.** Anything
  outside `1..N` is dropped and reported as `unknown_source`. This is
  enforced by set membership, not by inspection.
- **Metadata comes from the record.** Where the model's own values
  disagree, the record wins and the disagreement is recorded in `claimed`
  — a model that is drifting is visible rather than silently corrected.
- **Inline references are harvested.** "see Source 3" in the prose with an
  empty citations list is recovery, not invention. A reference to a source
  that does *not* exist is the opposite: it cannot be removed from the
  text, so the answer is marked ungrounded.
- **Quoted spans are checked against the evidence.** Quotation marks are a
  claim that the words are exact; spans not found in any retrieved passage
  are listed in `unverified_quotes`.

What this does not catch: a model can state something untrue and cite a
real passage that does not support it. No check here would find that. The
honest claim is that every *citation* is verifiable and every
unverifiable one is visible.

### Failure handling

**No evidence means no model call.** When retrieval returns nothing, the
answer is fixed and the provider is never invoked. Asking a model to say
"I don't know" and hoping it complies costs a call, takes longer, and has
a failure mode — answering anyway from its own knowledge — that this
stage exists to prevent.

**A failed generation does not discard the retrieval.** A provider outage
or an unparseable reply returns HTTP 200 with `status` naming the failure,
`answer: null`, and the sources intact, so the backend can render "we
could not generate an answer, here are the relevant clauses". The failure
is logged at error level and `/health` reports the provider, so nothing is
hidden by the choice — only the user's view of it is better. A malformed
*request* is still a 4xx.

**One retry, and only for shape.** An unparseable reply is retried once
with a nudge about formatting, deliberately not a restatement of the
grounding rules, which would invite the model to rewrite the answer rather
than reformat it.

### Honest limitations

- **Grounding is enforced at the citation level, not the sentence level.**
  A claim with a real citation that does not support it passes every check
  here.
- **The `grounded` flag is a validation outcome, not a truth judgement.**
  It means "every citation resolved and every quotation was found".
- **Quote checking is exact-match after normalisation.** A quote the model
  shortened with an ellipsis is reported as unverified. That is the
  intended outcome, but it produces false alarms on legitimate elisions.
- **No streaming**, so a long answer arrives all at once.
- **No conversation history.** Each question is answered alone; follow-ups
  that depend on a previous turn will not resolve.
- **No cost controls beyond the token budget and timeout.** There is no
  per-tenant quota or spend cap.
- **Batch jobs are in-memory and single-process.** A restart loses job
  *status* (never indexed data), and job ids are not visible to a second
  replica. Running more than one instance behind a load balancer needs a
  durable queue; the service functions are framework-free, so that swap
  is contained to `app/services/jobs.py`.
- **Ingestion is still synchronous per document.** `POST /ingest` blocks
  until the document is searchable, which for a 200-page scan is minutes.
  Use `/ingest/batch` — even for one document — when that matters.
- **No authentication beyond the optional shared secret.** `tenant_id` is
  *trusted*: this service believes the value it is given. Authenticating
  the user and deriving the tenant from the session is the Express
  layer's job, and that boundary is the whole of the isolation guarantee
  on your side of it.
- **The default deployment answers without a language model**, and says so
  everywhere, but a deployment that ignores `/health` could run that way
  indefinitely. `LLM_STRICT=true` is the fix.

---

## 1g. Hardening for ~500 documents (Stage 9)

Stage 8 made the pipeline callable. Stage 9 asks a narrower question: what
actually happens when a single tenant pushes ~500 legal documents through
it, and does anything break, leak or quietly rot?

The rule followed throughout was **measure first, then change**. Every
change below exists because a number justified it; the ideas that sounded
good and measured badly were dropped, and the ones that measured well are
reported with the numbers that made the case.

### The measurement harness

`scripts/benchmark.py` is the instrument, and it is part of the repository
rather than a thing that was run once and thrown away:

```bash
python scripts/benchmark.py --documents 500 --output baseline.json
```

It generates a synthetic corpus (55% small / 35% medium / 10% large, a
realistic mix rather than 500 copies of the same contract), runs the **real**
batch worker over it, then measures per-stage cost, retrieval latency
percentiles, peak RSS and `tracemalloc` allocation. Retrieval is warmed
before it is timed, so a five-second cold start is not folded into a latency
distribution and reported as typical.

### Where the time actually goes

| Stage | Mean per document | Share |
|---|---:|---:|
| Extract (PyMuPDF, native text) | 24 ms | **96%** |
| Chunk | 0.4 ms | 2% |
| Embed | 0.6 ms | 2% |

This is the single most important number in the stage, and it is also the
most misleading one, so both halves need saying:

- With the **deterministic** encoder — the lexical hashing fallback the
  benchmark runs on, because no model can be downloaded in this environment
  — embedding is free and extraction dominates completely.
- With a **real** Sentence-Transformers model on CPU, embedding is roughly
  10–40 ms per chunk, which at 7.4 chunks per document inverts the table
  entirely: embedding becomes 70–90% of ingestion and the wall-clock numbers
  below multiply by something like 5–15×.

So the ingestion timings here are a **floor**, not a forecast. What they do
establish soundly is the *shape* of the cost — which parts scale with
document count, where memory goes, and what re-ingestion costs — and every
one of those is independent of how fast the encoder is.

### Before and after, 500 documents, one process

| | Baseline (Stage 8) | Hardened (Stage 9) | |
|---|---:|---:|---|
| Ingest 500 documents | 27.53 s | 30.55 s | +11% |
| Documents per second | 18.2 | 16.4 | |
| Per document, median | 50 ms | 56 ms | |
| Per document, p95 | 111 ms | 120 ms | |
| **Retrieval, median** | 131.0 ms | **11.8 ms** | **11.1×** |
| **Retrieval, p95** | 151.7 ms | **14.1 ms** | |
| **Answer end-to-end, median** | 129.5 ms | **12.5 ms** | |
| **Re-ingest the same 500** | 32.78 s | **1.72 s** | **19.1×** |
| Peak RSS | 222.4 MB | 222.8 MB | +0.4 MB |
| Chunks indexed | 3,700 | 3,700 | identical |

The +11% on ingestion is the honest price of the two new per-document
checks (content digest lookup, duplicate lookup). It buys the 19× on
re-ingestion and is paid once per document version rather than per query.

### 1. Memory

Peak RSS moved by 0.4 MB between ingesting nothing and ingesting 500
documents' worth of extra bookkeeping, and total growth across the whole
batch was 48 MB — the vector store's own buffers, not accumulated document
state. `tracemalloc` shows 3.6 MB of Python objects at peak and 2.6 MB
retained.

Two mechanisms hold that line:

- **The batch request carries references, never contents.** A batch item is
  a `document_id`, a `tenant_id` and a path. There is no field in which 500
  document bodies could arrive, which is a stronger guarantee than promising
  not to hold them.
- **Embedding and upsert now stream in slices.** `_embed_and_store` walks
  the chunk list in `INDEX_BATCH_SIZE` windows, embedding and upserting each
  window and releasing its vectors before the next one is built. Previously
  a whole document's vectors existed at once — fine for a contract, not fine
  for a 2,000-page scan, where 15,000 chunks × 384 floats is ~23 MB of
  live float arrays before a single one is written.

### 2. Batch processing

Unchanged in design from Stage 8 and re-verified here: documents are
processed strictly one at a time, and only a small fixed-size `ItemResult`
is kept per document (ids, counts, status, at most three warnings). A test
asserts the one-at-a-time property by injection rather than by comment.

### 3. Failure isolation

A damaged file in position 200 must not cost the 300 documents behind it.
The worker catches `IngestionError` and bare `Exception` separately, records
either against its own document id, and continues.

Measured, not assumed: a 500-document batch with every fifth file
overwritten by garbage bytes.

```
damaged     : 100
succeeded   : 400
failed      : 100
chunks      : 2,960
status      : completed
error types : {'corrupt_document': 100}
```

Every failure is attributed to its own `document_id` with a stable
`error_type` Express can branch on, and the job still reports `completed`
rather than `failed` — the batch did what it could, and the caller is told
precisely which hundred documents to fix. The bare-`Exception` arm was
exercised accidentally during this run (a harness bug passed an unexpected
keyword argument to every document): all 500 items failed individually as
`internal_error`, the loop never broke, and the job summary was still
accurate. Which is the behaviour that arm exists for.

### 4. Duplicate documents

Two distinct cases, and they want different answers:

- **The same `document_id` submitted again** → re-index onto the same
  deterministic chunk ids. Never duplicates. This was already true.
- **A different `document_id` with byte-identical content** → now detected.
  Ingestion computes a SHA-256 content digest, stores it as
  `document_sha256` on every chunk, and reports
  `duplicate_of: "<the other document id>"` in the result. It still
  indexes — two parties can legitimately hold the same contract under
  different ids, and silently refusing would be wrong — but the caller is
  told, and Express can act on it.

The digest is over the **file's leading bytes** (up to 8 MB) for a file
ingest, and over the **text itself** for an inline-`text` ingest. Hashing
the file rather than the extracted text is what lets the unchanged check
run *before* extraction, where the saving actually is; the 8 MB bound
keeps a 400 MB scan from being read twice, at the cost noted in the
limitations below.

Set `DETECT_DUPLICATE_DOCUMENTS=false` to skip the lookup.

### 5. Partial failures

The dangerous window was in `index_from_document`: it deletes a document's
existing chunks, then writes the new ones. A crash between the two leaves
the document **gone from the index** while the caller's database still says
it is indexed — silent data loss, discoverable only by a user getting no
results for a document they can see.

`index_from_document` now wraps delete-and-store in `try`/`except`, calls
`_rollback` (best-effort, never raises) to clear the half-written state, and
raises `IndexingError` so the caller knows the document needs re-ingesting
rather than believing a lie.

This narrows the window; it does not close it. A `SIGKILL` between the
delete and the upsert still loses the document, and no amount of Python
fixes that — only a transactional store or a durable queue would. It is
listed in the limitations for that reason.

### 6. Large documents

The streaming embed path above is the main fix. Beyond it: `MAX_FILE_SIZE_MB`
is enforced on disk and while streaming (an oversized upload is abandoned
mid-stream, never fully buffered), `INGEST_MAX_TEXT_CHARS` caps inline text,
and the benchmark's large-document bucket runs at 121 ms mean versus 47 ms
for small — linear in size, with no cliff.

### 7. OCR-heavy documents

Measured separately, because folding a 1.2 s/page OCR document into an
average with 20 ms/page native pages produces a number that describes
neither. A 200-page scan is ~4 minutes of Tesseract before chunking starts.
Nothing in Stage 9 makes OCR faster — that is Tesseract's cost, not ours.
What Stage 9 does is make it survivable: such a document goes through
`/ingest/batch`, where it holds up its own job and nothing else, reports
progress, and cannot hit a proxy timeout because the HTTP call returned 202
minutes earlier.

### 8. Repeated ingestion

The 19× number. Re-ingesting an unchanged corpus used to cost full price:
extract, chunk, embed and write all 3,700 chunks again for no change in the
index. Now `index_document` hashes the extracted text and, if a chunk
already carries that `document_sha256` for that `document_id` and tenant,
short-circuits with `status: "unchanged"` before chunking or embedding.

500 unchanged documents: **32.78 s → 1.72 s**. The 1.72 s that remains is
500 × (resolve the path, read up to 8 MB and hash it, one filtered fetch).
Extraction, chunking and embedding are all skipped entirely — which is why
the digest is taken over the file rather than over the extracted text.

`"unchanged"` counts as a success in the job summary: the document is
indexed and current, which is what the caller asked for.
`SKIP_UNCHANGED_DOCUMENTS=false` disables the behaviour entirely, and
`force_ocr: true` bypasses it for one call — re-running OCR is precisely
the case where identical input is expected to produce a different result.

The same check runs on the inline-`text` path, keyed on a digest of the
text. That was missing in the first cut of this stage and was found on the
live server, not by a test — see the defect list in §7.

### 9. Vector-store consistency — and the BM25 cache

Stage 5's §1d listed "the per-query BM25 rebuild" as a known limitation:
every keyword query fetched the tenant's whole corpus out of the store and
built a fresh BM25 index. A cache was considered and rejected then, because
a stale keyword index is worse than a slow one — a document deleted for
legal reasons that keeps appearing in results is a real problem, and a TTL
only shrinks the window.

Stage 9 measured what that decision was costing:

| Corpus | Chroma fetch | BM25 build | Total per query |
|---:|---:|---:|---:|
| 1,000 chunks | 137 ms | 116 ms | ~253 ms |
| 5,000 chunks | 685 ms | 632 ms | ~1,317 ms |
| 20,000 chunks | ~2.0 s | 2,580 ms | **~3.2 s** |

Twenty thousand chunks is roughly 500 legal documents in **one** tenant —
the exact scale this stage is about. Rebuilding a 37 MB structure on every
single keyword query, and throwing it away, is not a defensible cost.

So the cache was added, with the staleness objection answered properly
rather than papered over with a TTL:

- `VectorStore.version(tenant_id)` returns a **per-tenant write counter**.
  Every write path — `upsert`, `delete_document`, `delete_tenant`, `reset`
  — bumps it, in both backends.
- A cached index is keyed on that counter. One write to a tenant and its
  cached index is dropped on the next read. Invalidation is **exact**: there
  is no window in which a deleted document can be served, and no TTL to
  tune.
- The key also includes `KEYWORD_CORPUS_LIMIT`, `BM25_K1` and `BM25_B`,
  because an index built under different parameters is a different index.
  (That was a real bug, caught by the suite: a retriever configured with a
  corpus limit of 3 was being served the full cached index.)
- The cache is bounded by total **chunks**, not entries — measured at 1.9 MB
  per 1,000 chunks, flat — with LRU eviction, and it refuses any single
  index larger than the whole budget.
- Filtered queries (anything narrower than a plain tenant scope) bypass the
  cache entirely rather than caching a combinatorial explosion of filter
  shapes.

Single-tenant retrieval, cache off versus on:

| Tenant corpus | Cache off | Cache on | |
|---:|---:|---:|---|
| 1,000 chunks | 175.8 ms | 11.0 ms | 15.9× |
| 5,000 chunks | 851.6 ms | 35.8 ms | 23.8× |
| 20,000 chunks | 4,372.5 ms | 122.4 ms | **35.7×** |

The benefit grows with corpus size, which is the right shape: the cost being
avoided is the one that was growing.

`KEYWORD_CACHE_ENABLED=false` turns it off. **It must be set to `false` for
any deployment running more than one writer process against a shared store**
— the counter is per-process, so a second process's writes are invisible to
this one's cache. That is the honest limitation of the design and it is
stated in §10 as well as here.

### 10. Tenant isolation

Re-verified at every new surface rather than assumed:

- `SearchFilter` still raises `TenantScopeError` if constructed without a
  `tenant_id` — isolation by construction, not by remembering to pass a
  filter.
- The BM25 cache is **keyed by tenant**, and a test asserts that two tenants
  with identical corpora receive different indexes.
- The version counter is per-tenant, so tenant A's writes do not invalidate
  tenant B's cache (correctness would survive it; performance would not).
- Duplicate detection and the unchanged-document check are both tenant-
  scoped: an identical document in another tenant is invisible.

### Also in Stage 9

- **Stale temp-file sweep at startup.** Every temp file is removed in a
  `finally`, so under normal operation there is nothing to sweep. A
  `SIGKILL`, an OOM kill or a container eviction skips that `finally` and the
  file stays — on a shared volume, for ever. A few hundred ingests of 50 MB
  PDFs later, that is a disk-full incident with no obvious cause.
  `sweep_stale_temp_files` runs once at startup, by age
  (`TEMP_FILE_MAX_AGE_HOURS=6`), confined to `TEMP_DIR`, and never raises —
  a service that will not start because it could not tidy up is worse than
  the untidiness. The age bound is what makes it safe to run while another
  instance is live.
- **No Celery, no RQ, no Redis.** They were considered and deliberately not
  added: at 500 documents in a single process, the in-memory job registry
  does the job, and a Redis dependency for a service that does not need one
  is a second thing to deploy, monitor and lose. The *shape* of the code is
  queue-ready — the service functions are framework-free and nothing outside
  `app/services/jobs.py` knows how a batch is scheduled — so the swap, when
  a second replica makes it necessary, is contained to that one module.

### Honest limitations

- **The BM25 cache's write counter is per-process.** Two API processes
  against one Chroma directory will each hold a cache the other's writes
  cannot invalidate. Set `KEYWORD_CACHE_ENABLED=false` for multi-writer
  deployments; a shared counter in Redis is the fix, and is exactly the
  point at which Redis stops being architecture for its own sake.
- **Ingestion timings use the deterministic encoder** and are a floor, not a
  forecast. See the caveat under "Where the time actually goes".
- **The delete-then-upsert window is narrowed, not closed.** A process kill
  between the two still loses the document from the index.
- **Job status is still in-memory and single-process.** A restart loses
  status, never indexed data.
- **The unchanged check hashes at most the first 8 MB of a file.** Two
  files identical in their leading 8 MB but differing later are treated as
  unchanged, and the edit is not indexed. Files that large are unusual under
  the 50 MB default cap, but the failure mode is silent, so `force_ocr` or
  `SKIP_UNCHANGED_DOCUMENTS=false` is the escape hatch when it matters.
- **`count(tenant)` is too slow to use as a per-query safety net** — 82.7 ms
  at 20,000 chunks. So the corpus-limit truncation flag is derived from the
  fetch itself rather than from a separate count.
- **The corpus is synthetic.** 500 generated contracts with invented
  parties, amounts and clauses. Real corpora are messier — more OCR, more
  layout variety, wider size spread — and the extraction share of time will
  rise with them.
- **One process, one machine, no concurrency test.** These numbers are a
  single worker's. Nothing here measures what happens when ten Express
  requests arrive at once.

---

## 2. The internal document representation

`app/models/document.py` is the contract between ingestion and every later
stage. Plain dataclasses, not Pydantic — these are built and walked in hot
loops, never parsed from untrusted JSON.

```
ExtractedDocument
├── DocumentMetadata      document_id, tenant_id, filename, document_type,
│                         title, content_sha256, size_bytes, ingested_at, extra
├── ExtractionStats       parser, method, page_count, empty_page_count,
│                         ocr_page_count, block_count, char_count,
│                         duration_ms, running_headers_removed
├── warnings[]            non-fatal problems worth surfacing
└── Page[]                page_number, text, raw_text, method, synthetic
    └── TextBlock[]       text, page_number, block_index, kind, section, ocr, bbox
```

Four guarantees later stages are built on:

1. **Every block can produce a full citation on its own.** `block.provenance()`
   returns `document_id`, `tenant_id`, `filename`, `document_type`,
   `page_number`, `section`, `kind`, `ocr` and `block_id` — no need to carry
   the document around. Stage 3 copies this dict onto each chunk and adds
   `chunk_id`; Stage 6 turns it into a citation.
2. **Pages are never merged or reordered.** 1-based, contiguous; a blank page
   stays in the list so page *n* out is page *n* in the file.
3. **The original is recoverable.** Cleaning never edits in place —
   `Page.raw_text` holds the pre-cleaning text.
4. **Block ids are deterministic** (`document_id:p{page}:b{index}:{sha}`), so
   re-ingesting the same file yields the same ids and Stage 3 chunk ids and
   Stage 6 citations stay stable across re-indexing. The text digest is part
   of the id, so an edited document cannot silently reuse an id that now
   points at different words.

Handing Stage 3 `document.iter_blocks()` is all the integration required.

---

## 3. Important design decisions

**Blocks, not page strings.** PyMuPDF's block output preserves the layout
grouping legal documents depend on: a clause heading arrives separate from the
clause body. Blocks are sorted by rounded `(y, x)`, which recovers reading
order for the single-column layouts contracts overwhelmingly use. Extracting
one flat string per page would throw away the structure section detection
needs.

**Cleaning never changes what the document says.** In this domain a false
positive is far worse than a missed cleanup — dropping a line that looked like
a footer could delete a liability cap. So the cleaner only removes artefacts of
*extraction*, and a test asserts that `INR 4,50,000`, `1 March 2024`,
`thirty-six (36)`, `1.5%` and `Schedule A` all survive a full pass.

**Running-header detection needs real evidence.** A line is only furniture if
it repeats near the top or bottom of ≥ 60% of pages, *and* the document has at
least 3 pages. On a two-page contract nothing is ever stripped. Only the
outermost 3 lines of each page are candidates, so a repeated line mid-page is
never touched.

**Digits are masked only where that is safe.** "Page 3 of 20" and "Page 4 of
20" must collapse to one fingerprint, but masking digits everywhere makes "The
Vendor shall deliver 3 units" and "…deliver 4 units" look like the same
repeated line. So each line gets two fingerprints: exact, and digit-masked
*only* when the line is short (≤ 6 words) or explicitly says "page". This was
caught by a test, not by inspection.

**OCR decides per page, not per document.** A scanned signature page appended
to a typed contract gets OCR'd while the other 30 pages take the fast native
path. Two guards keep OCR from making things worse: it runs only when a page
yields under `OCR_MIN_CHARS_PER_PAGE` characters, and its output replaces the
native text only if it is ≥ `OCR_MIN_GAIN_RATIO` times longer — so OCR noise
can never displace a short but real text layer.

**OCR absence is degraded, not fatal.** Tesseract and `pytesseract` are both
optional. Without them, text PDFs and DOCX ingest normally, scanned pages come
back empty with an explicit warning, and `/health` reports `ocr: degraded`. A
missing enhancement should never take the service down.

**"Empty" is an error, with a reason.** Silently indexing nothing surfaces
months later as "the AI can't find anything in my contract", with no trace
anywhere. `EmptyDocumentError` says *why*: no text layer and OCR unavailable,
OCR disabled, or genuinely blank.

**A damaged PDF is reported as damaged.** PyMuPDF is deliberately lenient — it
repairs what it can and may report zero pages rather than raising. A PDF with
no pages is not a valid PDF, so that is surfaced as `corrupt_document`, not as
`empty_document`. (Found by a test; see §7.)

**DOCX pages are synthetic and say so.** Word stores no page boundaries — it
paginates at render time from printer and font metrics. Rather than pretend,
pages are synthesised at explicit page breaks and at a 3000-character budget,
and every one is flagged `synthetic=True` so a citation can be honest. The
alternative — one giant page 1 — would make every citation in a 60-page
agreement read "page 1".

**Body XML order for DOCX.** `document.paragraphs` and `document.tables` are
separate sequences that lose the interleaving between them, so the body XML is
walked directly. A table between clauses 4 and 5 stays between clauses 4 and 5.

**Extension *and* magic bytes.** Either alone is trivially bypassed: an `.exe`
renamed to `.pdf` fails the magic-byte check, a real PDF renamed to `.txt`
fails the extension check. Both are required.

**A parser registry, not imports.** The service looks parsers up by extension
and never imports a format module directly, so adding RTF later is one new
module plus one `register()` call — no change to the service, the API, or the
tests for existing formats.

**No FastAPI types in the service layer.** `extract_document()` is a plain
function. Stage 3 will call it directly from the chunking pipeline, and a
Celery/RQ worker can call it with no HTTP layer at all.

**Per-item failure isolation.** One damaged file in a batch of 500 fails only
itself, and the batch returns HTTP 200 with per-document status — an HTTP error
would tell the backend nothing about the other 499.

---

## 4. Endpoints

### The integration contract — what Express calls

Five endpoints. Everything below them (extraction, chunking, embeddings,
hybrid retrieval, reranking, context construction, generation, citation
validation) is reached through these.

| Method | Path | Purpose |
|---|---|---|
| POST | `/ingest` | Ingest one document — by path or by inline text |
| POST | `/ingest/batch` | Up to ~500 documents, in the background → **202** |
| GET | `/ingest/batch/{job_id}` | Progress and per-document results |
| POST | `/query` | Question → grounded answer with validated citations |
| DELETE | `/documents/{document_id}?tenant_id=` | Remove a document's vector data |
| GET | `/health` | Per-component status |

**Section 10 below is the integration guide**, with a working `curl` for
every one of them.

The per-stage endpoints in the table that follows stay mounted and are
genuinely useful for diagnosing one stage in isolation — "is retrieval
finding it?" is answered by `POST /retrieve`, not by reading an answer —
but they are **not** the contract, and Express should not build on them.

### Diagnostic endpoints, by stage

| Method | Path | Purpose |
|---|---|---|
| POST | `/documents/extract` | Extract one document by path |
| POST | `/documents/extract/batch` | Extract many, isolating failures |
| POST | `/documents/extract/upload` | Extract a streamed multipart upload |
| POST | `/documents/chunk` | Extract **and chunk**; returns chunks without indexing |
| POST | `/index` | Extract, chunk, embed and **store** one document |
| POST | `/index/batch` | Index many, isolating failures |
| POST | `/index/upload` | Index a streamed multipart upload |
| POST | `/search` | Similarity search with metadata filters (passages, not an answer) |
| GET | `/index/stats` | Backend, collection, dimension, chunk counts |
| DELETE | `/documents/{document_id}/index?tenant_id=` | Delete a document's chunks |
| DELETE | `/tenants/{tenant_id}/index` | Delete everything for a tenant |
| GET | `/documents/formats` | Supported types, size limit, OCR status |
| GET | `/health` | Status incl. `ingestion` and `ocr` components |
| GET | `/health/live` · `/health/ready` | Container probes |
| GET | `/` · `/docs` · `/openapi.json` | Service info, Swagger UI, contract |

### `POST /documents/extract`

```jsonc
// request
{
  "document_id": "665f1c9e2ab4d1f0a1b2c3d4",   // required
  "tenant_id":   "665e02b41f9c8d7e6f5a4b3c",   // required, trusted
  "file_path":   "tenant-a/vendor_contract_2024.pdf",  // rel. to DOCUMENT_ROOT
  "filename":    "vendor_contract_2024.pdf",   // optional
  "document_type": "contract",                 // optional, inferred if absent
  "force_ocr": false,                          // optional
  "include_blocks": false,                     // optional, per-block detail
  "include_text": true,                        // optional, false = stats only
  "metadata": { "matter_id": "M-77" }          // optional, scalars only
}
```

```jsonc
// 200 — real output from a live server
{
  "status": "success",
  "metadata": {
    "document_id": "doc-contract-1", "tenant_id": "tenant-alpha",
    "filename": "vendor_contract_2024.pdf", "document_type": "contract",
    "content_sha256": "48e24ca73904dd980b115a5c…", "size_bytes": 5121,
    "ingested_at": "2026-09-12T10:23:12.004913+00:00"
  },
  "stats": {
    "parser": "pymupdf", "method": "native", "page_count": 4,
    "empty_page_count": 0, "ocr_page_count": 0, "block_count": 17,
    "char_count": 2220, "duration_ms": 78, "cleaning_applied": true,
    "running_headers_removed": 2
  },
  "sections": ["1. DEFINITIONS", "2. TERM", "3. FEES AND PAYMENT",
               "4. TERMINATION", "5. LIMITATION OF LIABILITY", "…"],
  "pages": [
    { "page_number": 2, "text": "3. FEES AND PAYMENT\n\nThe Client shall pay…",
      "method": "native", "char_count": 654, "synthetic": false,
      "sections": ["3. FEES AND PAYMENT", "4. TERMINATION"], "blocks": null }
  ],
  "warnings": []
}
```

`method` is `native`, `ocr`, `mixed` or `none`. `synthetic` is `true` for DOCX.
`blocks` is `null` unless `include_blocks` is set.

### Errors

Every failure uses the Stage 1 envelope. Branch on `error.type`, not the message:

| `error.type` | HTTP | Meaning |
|---|---|---|
| `unsupported_file_type` | 415 | Extension not allowed, or bytes don't match it |
| `file_too_large` | 413 | Over `MAX_FILE_SIZE_MB` |
| `document_not_found` | 404 | No such file under `DOCUMENT_ROOT` |
| `unsafe_path` | 400 | Path escapes the root, or a bad identifier |
| `corrupt_document` | 422 | Damaged or unreadable file |
| `encrypted_document` | 422 | Password-protected PDF |
| `empty_document` | 422 | No extractable text (message says why) |
| `parser_unavailable` | 503 | A required library is missing |
| `validation_error` | 422 | Malformed request body |

```json
{"error": {"type": "corrupt_document",
           "message": "The PDF is damaged: no pages could be read (the file structure had to be repaired)",
           "details": {"repaired": true}},
 "request_id": "c3a35530b5714211"}
```

### `POST /documents/extract/batch`

```jsonc
{ "total": 3, "succeeded": 2, "failed": 1, "duration_ms": 21,
  "results": [
    {"document_id": "b1", "status": "success", "stats": {…}, "error": null},
    {"document_id": "b2", "status": "failed",  "stats": null,
     "error": {"type": "corrupt_document", "message": "…"}},
    {"document_id": "b3", "status": "success", "stats": {…}, "error": null}
  ]}
```

HTTP 200 even with failures. Order matches the request.

### `POST /documents/extract/upload`

Multipart: `file` plus `document_id`, `tenant_id`, and optional
`document_type`, `title`, `force_ocr`, `include_blocks`. Streamed to a private
temp file, extracted, deleted. Only the basename of the client filename is
trusted. Returns the same `ExtractResponse`.

### `POST /retrieve` — the endpoint to build the chat feature on

Runs the whole Stage 5 pipeline and returns the passages most relevant to a
query. **Passages, not an answer.**

```json
{
  "query": "How much notice is required to terminate for convenience?",
  "tenant_id": "665e02b41f9c8d7e6f5a4b3c",
  "top_k": 6,
  "document_type": "contract",
  "explain": true
}
```

Optional: `document_ids`, `section`, `page_range`, `metadata_equals`,
`candidate_pool`, `mode` (`hybrid` | `semantic` | `keyword`), `rerank`,
`dedupe`, `min_score`, `include_text`, `explain`.

```json
{
  "results": [
    {
      "rank": 1,
      "score": 1.0,
      "chunk_id": "…", "chunk_index": 3,
      "document_id": "doc-msa-001",
      "filename": "vendor_contract_2024.pdf",
      "page_number": 2, "page_end": 2, "page_range": "2",
      "section": "4. TERMINATION",
      "document_type": "contract",
      "text": "4. TERMINATION\n\nEither party may terminate…",
      "duplicates": ["…"],
      "scores": {
        "semantic": 0.143, "semantic_rank": 2,
        "keyword": 1.0, "keyword_rank": 1,
        "fused": 1.0, "ranked": 1.1, "rerank": 0.59, "final": 1.0,
        "sources": ["keyword", "semantic"],
        "boosts": {"agreement": 0.05, "heading": 0.05},
        "pinned": false
      }
    }
  ],
  "counts": {"semantic": 13, "keyword": 5, "fused": 13,
             "after_dedupe": 13, "returned": 4,
             "duplicates_removed": 0, "corpus_size": 13},
  "mode": "hybrid", "top_k": 4, "candidate_pool": 18,
  "agreement": 0.38, "references": [],
  "reranker": "lexical:lexical-coverage (fallback, not a cross-encoder)",
  "reranked": true, "rerank_is_cross_encoder": false,
  "warnings": [],
  "duration_ms": 12,
  "timings_ms": {"preprocess": 0, "semantic": 5, "keyword": 4,
                 "fusion": 0, "rank": 0, "dedupe": 2, "rerank": 0}
}
```

`explain` is what makes a result defensible: every stage's score, the named
boosts, which retrievers found the passage, and whether it was pinned.

An invalid `mode` is a `422` naming the field, not a `500` — a typo in the
backend's payload is a client error and must not read as a service fault.

### `GET /retrieve/config`

The live pipeline configuration, including `reranker_active` and
`rerank_is_cross_encoder`. This is how an operator establishes that a
deployment is running the fallback reranker rather than the real model.

### `POST /context` — what a grounded-answer feature calls

Retrieves, then builds the evidence block. Takes every `/retrieve` option
plus `context_max_tokens`, `context_max_sources`, `context_min_sources`,
`context_min_score`, `context_max_source_tokens`, `context_order`,
`context_dedupe`, `context_truncate`, `include_context_text`.

```json
{
  "context": "Source 1:\nDocument: vendor_contract_2024.pdf (id: doc-msa-001)\n…",
  "sources": [
    {"source": 1, "chunk_id": "…", "document_id": "doc-msa-001",
     "filename": "vendor_contract_2024.pdf", "page_number": 2,
     "page_range": "2", "section": "4. TERMINATION", "chunk_index": 3,
     "text": "Either party may terminate…", "score": 1.0,
     "retrieval_rank": 1, "tokens": 84, "total_tokens": 139,
     "truncated": false, "omitted_tokens": 0, "duplicates": [],
     "continues_source": null}
  ],
  "citations": [
    {"source": 1, "document_id": "doc-msa-001",
     "filename": "vendor_contract_2024.pdf", "page": "2",
     "section": "4. TERMINATION", "chunk_id": "…", "truncated": false}
  ],
  "omitted": [
    {"chunk_id": "…", "reason": "max_sources", "score": 0.61,
     "citation": {"section": "2. TERM", "…": "…"}}
  ],
  "stats": {"candidates_in": 6, "sources_out": 4, "documents": 2,
            "redundant_removed": 0, "dropped_for_budget": 0,
            "truncated_sources": 0, "tokens_used": 497,
            "tokens_budget": 900, "tokens_remaining": 403,
            "text_tokens": 283, "overhead_tokens": 214},
  "sufficient": true, "order": "document", "tokenizer": "heuristic",
  "warnings": [],
  "duration_ms": 14,
  "timings_ms": {"retrieval": 12, "context": 1}
}
```

`sufficient: false` means too little evidence reached the block for a
confident answer. It is **reported, not enforced** — this stage does not
decide that a question is unanswerable; whether to answer, hedge or
decline belongs to the stage that writes the prompt.

### `GET /context/config`

The live context-builder configuration, including which token counter is
pricing the budget.

### `POST /answer` — the end of the pipeline

Takes every `/retrieve` and `/context` option, plus `temperature`,
`max_output_tokens`, `include_context`, `include_sources`.

```json
{
  "status": "ok",
  "answer": "Either party may terminate for convenience on 120 days written notice (Source 2).",
  "citations": [
    {"document": "vendor_contract_2024.pdf", "page": 2,
     "section": "4. TERMINATION", "chunk_id": "2896bf74…",
     "source": 2, "document_id": "doc-msa-001", "page_range": "2"}
  ],
  "interpretation": "In practice, notice should be served well before renewal.",
  "insufficient_evidence": false,
  "grounded": false,
  "validation": {
    "grounded": false, "valid_citations": 1,
    "rejected": [
      {"reason": "unknown_source", "claimed_source": 99,
       "detail": "The answer cited Source 99, which was not in the context…"}
    ],
    "verified_quotes": 0,
    "unverified_quotes": ["notice may be given by telephone at any time"]
  },
  "sources": [ … ],
  "provider": "openai", "model": "gpt-4o-mini", "is_language_model": true,
  "usage": {"prompt_tokens": 900, "completion_tokens": 60, "total_tokens": 960},
  "warnings": ["1 quoted passage(s) … could not be found in the retrieved evidence…"],
  "timings_ms": {"retrieval": 41, "context": 2, "generation": 780, "validation": 0}
}
```

That example is a real response from the live run below: the model cited
a source that did not exist and quoted words that were not in any
passage. The invented citation was dropped, the quotation was flagged, and
`grounded` came back false.

**Branch on `status`**: `ok` · `insufficient_evidence` · `llm_unavailable`
· `llm_configuration_error` · `malformed_response`. The last three return
200 with `answer: null` and the sources intact.

### `GET /answer/config`

The live generation configuration, including whether a real language model
is answering and whether a key is present. Never returns a credential.

### `POST /search` (Stage 4) is unchanged

A single vector query with metadata filtering. Still useful for judging
retrieval quality in isolation and for callers that want raw similarity —
but `/retrieve` is the one to integrate against.

---

## 5. Configuration

Stage 1 settings are unchanged. Stage 2 adds:

| Variable | Default | Meaning |
|---|---|---|
| `DOCUMENT_ROOT` | `./data/documents` | The only directory documents may be read from |
| `TEMP_DIR` | `./data/tmp` | Scratch space; never holds a file after a request |
| `ALLOWED_EXTENSIONS` | `.pdf,.docx` | Allow-list |
| `MAX_FILE_SIZE_MB` | `50` | Enforced on disk and while streaming |
| `OCR_ENABLED` | `true` | Master switch for the OCR fallback |
| `OCR_LANGUAGE` | `eng` | Tesseract language pack |
| `OCR_DPI` | `200` | Rasterisation DPI |
| `OCR_MIN_CHARS_PER_PAGE` | `100` | Below this a page is treated as scanned |
| `OCR_MIN_GAIN_RATIO` | `1.2` | OCR must beat native text by this factor |
| `TESSERACT_CMD` | *(auto)* | Explicit binary path |
| `CLEAN_TEXT` | `true` | Master switch for cleaning |
| `STRIP_RUNNING_HEADERS` | `true` | Remove repeated headers/footers |
| `HEADER_FOOTER_MIN_RATIO` | `0.6` | Fraction of pages a line must repeat on |
| `HEADER_FOOTER_MIN_PAGES` | `3` | Below this, nothing is ever stripped |
| `STRIP_PAGE_NUMBERS` | `true` | Remove standalone page-number lines |
| `KEEP_RAW_TEXT` | `true` | Keep pre-cleaning text for recovery |
| `DETECT_SECTIONS` | `true` | Heading/section detection |

Stage 5 adds (Stage 3 and 4 variables are listed in `.env.example`):

| Variable | Default | Meaning |
|---|---|---|
| `RETRIEVAL_MODE` | `hybrid` | `hybrid` \| `semantic` \| `keyword` |
| `RETRIEVAL_CANDIDATES` | `18` | Candidates retrieved **before** reranking |
| `RETRIEVAL_TOP_K` | `6` | Passages returned **after** reranking |
| `RETRIEVAL_MIN_SCORE` | `0.0` | Final score floor; `0` disables it |
| `FUSION_METHOD` | `rrf` | `rrf` (rank-based) \| `weighted` (score-based) |
| `RRF_K` | `60` | RRF damping constant |
| `SEMANTIC_WEIGHT` / `KEYWORD_WEIGHT` | `0.6` / `0.4` | Relative trust in each signal |
| `KEYWORD_CORPUS_LIMIT` | `5000` | Chunks BM25 will score per query |
| `BM25_K1` / `BM25_B` | `1.5` / `0.75` | Term saturation / length normalisation |
| `REFERENCE_BOOST` | `0.25` | The query named this clause |
| `PHRASE_BOOST` | `0.15` | A quoted phrase occurs verbatim |
| `AGREEMENT_BOOST` | `0.05` | Both retrievers found this passage |
| `HEADING_BOOST` | `0.05` | A query term is in the section heading |
| `DEDUPE_ENABLED` | `true` | Near-duplicate removal |
| `DEDUPE_THRESHOLD` | `0.85` | Jaccard above which two passages are one |
| `DEDUPE_SHINGLE_SIZE` | `5` | Character n-gram width |
| `DEDUPE_ACROSS_DOCUMENTS` | `true` | Collapse the same clause in two documents |
| `RERANK_ENABLED` | `true` | Master switch for reranking |
| `RERANKER_PROVIDER` | `cross_encoder` | `cross_encoder` \| `lexical` (fallback only) |
| `RERANKER_MODEL` | `cross-encoder/ms-marco-MiniLM-L-6-v2` | ~90 MB |
| `RERANKER_BATCH_SIZE` | `16` | Pairs per forward pass |
| `RERANK_MAX_CHARS` | `1200` | Passage characters fed to the model |
| `RERANK_WEIGHT` | `0.85` | Reranker's share of the final blended score |
| `RERANK_STRICT` | `false` | `true`: a model that will not load is fatal |

Stage 6 adds:

| Variable | Default | Meaning |
|---|---|---|
| `CONTEXT_MAX_TOKENS` | `3000` | Ceiling for the whole block, headers included. **Not** the model's window |
| `CONTEXT_MAX_SOURCES` | `6` | Hard cap on source count, independent of the budget |
| `CONTEXT_MIN_SOURCES` | `1` | Below this the context is flagged as thin evidence |
| `CONTEXT_MIN_SCORE` | `0.0` | Drop passages below this; `0` disables it |
| `CONTEXT_MAX_SOURCE_TOKENS` | `700` | Per-source ceiling; `0` disables it |
| `CONTEXT_MIN_SOURCE_TOKENS` | `60` | Shortened below this, a passage is dropped instead |
| `CONTEXT_TRUNCATE_LONG_SOURCES` | `true` | Shorten rather than drop an oversized passage |
| `CONTEXT_ORDER` | `document` | `document` (reading order) \| `relevance` |
| `CONTEXT_DEDUPE_ENABLED` | `true` | Redundancy removal inside the builder |
| `CONTEXT_REDUNDANCY_THRESHOLD` | `0.85` | Jaccard above which two passages are one |
| `CONTEXT_STRIP_REPEATED_HEADING` | `true` | Drop a heading the header line already states |

Stage 7 adds:

| Variable | Default | Meaning |
|---|---|---|
| `LLM_PROVIDER` | `extractive` | `openai` \| `anthropic` \| `extractive` (no model) |
| `LLM_MODEL` | *(provider default)* | e.g. `gpt-4o-mini`, `claude-3-5-haiku-latest` |
| `LLM_BASE_URL` | *(provider default)* | Point `openai` at vLLM, Ollama, Groq, Azure … |
| `OPENAI_API_KEY` | *(empty)* | **Environment only.** Never logged or returned |
| `ANTHROPIC_API_KEY` | *(empty)* | **Environment only.** Never logged or returned |
| `LLM_TEMPERATURE` | `0.0` | 0 keeps answers reproducible |
| `LLM_MAX_OUTPUT_TOKENS` | `800` | Too low truncates the JSON and fails the parse |
| `LLM_TIMEOUT_SECONDS` | `30` | Per request |
| `LLM_MAX_RETRIES` | `1` | Extra attempts after an **unparseable** reply only |
| `LLM_STRICT` | `false` | `true`: a provider that will not build is fatal |
| `LLM_EXTRA_INSTRUCTIONS` | *(empty)* | House rules appended to the grounding prompt |
| `GENERATION_REQUIRE_CITATIONS` | `true` | An uncited answer is marked ungrounded |
| `GENERATION_HARVEST_INLINE_CITATIONS` | `true` | Recover "see Source 3" from the prose |
| `GENERATION_VERIFY_QUOTES` | `true` | Check quoted spans against the evidence |

Stage 8 adds:

| Variable | Default | Meaning |
|---|---|---|
| `INGEST_BATCH_MAX_DOCUMENTS` | `500` | Larger batches are rejected with 413 |
| `INGEST_MAX_CONCURRENT_JOBS` | `1` | Further submissions get 429; embedding is CPU-bound |
| `INGEST_JOB_HISTORY` | `100` | Finished jobs kept for polling (in-memory) |
| `INGEST_MAX_TEXT_CHARS` | `2000000` | Inline `text` ceiling on `POST /ingest` |

Stage 9 adds (each of these was added because a measurement in §1g
justified it, and each can be switched off):

| Variable | Default | Meaning |
|---|---|---|
| `SKIP_UNCHANGED_DOCUMENTS` | `true` | Re-ingesting identical content short-circuits to `status: "unchanged"`. Measured: 500 documents, 32.8 s → 1.7 s |
| `DETECT_DUPLICATE_DOCUMENTS` | `true` | Report `duplicate_of` when another id in the same tenant holds identical content. Never refuses the write |
| `KEYWORD_CACHE_ENABLED` | `true` | Cache the per-tenant BM25 index. Measured at 20,000 chunks: 4,372 ms → 122 ms. **Set `false` for multi-writer deployments** — the invalidation counter is per-process |
| `KEYWORD_CACHE_MAX_CHUNKS` | `50000` | Cache budget in chunks (~1.9 MB per 1,000), LRU eviction |
| `TEMP_FILE_MAX_AGE_HOURS` | `6.0` | Startup sweep of temp files orphaned by a killed process. `0` disables it |

`INDEX_BATCH_SIZE` (Stage 4) now also bounds live memory during ingestion:
embedding and upsert stream in slices of this size rather than materialising
a whole document's vectors at once.

---

## 6. Security

Stage 1's posture plus, for ingestion:

- **Path confinement.** Every referenced path is resolved and must land inside
  `DOCUMENT_ROOT`. `../../etc/passwd`, absolute paths elsewhere, symlinks out
  of the root (`resolve()` follows them, so containment still catches it),
  directories and null bytes are all rejected.
- **Type validation.** Extension allow-list *and* magic bytes.
- **Size limits** on disk and while streaming — an oversized upload is
  abandoned mid-stream, never fully buffered.
- **Temp files** live under `TEMP_DIR` (not the shared system temp directory),
  are created `0600` via `mkstemp`, have random names that never derive from
  the uploaded filename, and are removed in `finally` — on success, on
  exception and on early return. A cleanup failure is logged, never raised, so
  it cannot mask the real error.
- **Identifier validation** on `document_id` / `tenant_id` at the boundary,
  before they reach metadata or (from Stage 4) vector-store filters.
- Uploaded files are parsed as data, never executed. Filenames and document
  content stay out of error messages returned to callers.

Authentication is still the MERN backend's job; this service only verifies the
optional `X-Service-Token` shared secret.

---

## 7. Testing

```bash
pytest -q            # 1232 tests
pytest -q tests/test_pipeline_api.py
pytest -q tests/test_hardening.py
```

| File | Tests | Covers |
|---|---:|---|
| `test_health.py` | 13 | Stage 1 health, probes, degraded states |
| `test_config.py` | 16 | Defaults, env overrides, validation |
| `test_schemas.py` | 13 | Contract shapes, OpenAPI presence |
| `test_app.py` | 21 | Wiring, error handling, auth, logging |
| `test_ingestion_extraction.py` | 34 | Normal PDF, multi-page PDF, DOCX, scanned PDF, metadata |
| `test_ingestion_errors.py` | 39 | Empty, corrupt, unsupported, unsafe, oversized, batch isolation |
| `test_ingestion_cleaning.py` | 72 | Unicode, line breaks, noise, headers, sections, temp files |
| `test_ingestion_api.py` | 31 | Every endpoint, every error status, upload cleanup |
| `test_chunking_core.py` | 49 | Short/long documents, paragraph and section boundaries, overlap, metadata, determinism, small-chunk merging |
| `test_chunking_edge_cases.py` | 88 | Empty text, unusual formatting, tokenizer, splitters, budget invariants |
| `test_chunking_pipeline.py` | 26 | Stage 2 → Stage 3 on real files, plus the HTTP contract |
| `test_embeddings.py` | 55 | Dimension discovery at nine widths, a real 96-dim model, batching, factory fallback |
| `test_vectorstore.py` | 110 | Conformance run against **both** backends: insertion, search, filtering, deletion, tenant isolation, duplicates |
| `test_indexing.py` | 42 | End-to-end index and search, re-indexing, batch isolation, every endpoint |
| `test_retrieval_query.py` | 35 | Preprocessing, filler stripping, term families, clause references, phrases |
| `test_retrieval_keyword.py` | 24 | BM25 arithmetic, the clauses it should find, corpus scoping, truncation reporting |
| `test_retrieval_fusion.py` | 27 | RRF, weighted fusion, degenerate inputs, every ranking boost, pinning |
| `test_retrieval_dedup.py` | 20 | Exact and near duplicates, and the Stage 3 overlap that must survive |
| `test_retrieval_rerank.py` | 28 | Fallback behaviour, blending, **a real CrossEncoder**, strict mode |
| `test_retrieval_pipeline.py` | 53 | The nine required areas end to end, plus degradation and observability |
| `test_retrieval_api.py` | 33 | Every option over HTTP, filters, isolation, validation, health |
| `test_context_units.py` | 43 | Selection, ordering, budgeting and rendering, each on its own |
| `test_context_builder.py` | 49 | The seven required areas end to end, from bare chunks |
| `test_context_api.py` | 29 | The HTTP contract, omission reporting, isolation, health |
| `test_generation_providers.py` | 36 | The abstraction, both HTTP providers against a mock transport, secret hygiene, the registry |
| `test_generation_parser.py` | 29 | Every packaging deviation recovered from, every bad shape reported |
| `test_generation_citations.py` | 26 | Invented citations, metadata from the record, inline references, quote checking |
| `test_generation_service.py` | 43 | The eight required areas end to end, with a scripted model |
| `test_generation_api.py` | 30 | The HTTP contract, failure statuses, isolation, config secrecy |
| `test_ingest_jobs.py` | 22 | The batch worker holds **one document at a time**; failure isolation; the bounded job store |
| `test_pipeline_api.py` | 62 | All five integration endpoints, a 500-document batch, every error status, request ids, isolation, no leaked credentials |
| `test_hardening.py` | 34 | One labelled section per Stage 9 evaluation point: sliced embedding, rollback on partial write, failure isolation, duplicate detection, skip-unchanged, exact cache invalidation, cache keying and eviction, the temp-file sweep, tenant isolation with the cache in play |

Every document is **synthetic**, generated at test time in `tests/fixtures.py`
from invented parties, amounts and clauses. No real or confidential legal
material appears anywhere in this repository. The required scenarios are all
covered: normal PDF, multi-page PDF, DOCX, scanned/low-text PDF, empty
document (blank PDF *and* empty DOCX), corrupted document (PDF *and* DOCX), and
unsupported file type.

The scanned-PDF fixture is a real image-only PDF. Tests that assert on OCR
*output* skip when Tesseract is absent; the test that asserts a scanned page is
*routed* to OCR runs either way.

The nine scenarios Stage 5 required are each covered: semantic retrieval,
keyword retrieval, hybrid merging, ranking, duplicate removal, metadata
filtering, empty results, an irrelevant query, and tenant isolation.

Two notes on what these tests can and cannot claim:

- The suite runs on the **deterministic** encoder (a lexical hashing
  function, not a semantic model), because the real one cannot be downloaded
  here. So no test asserts that retrieval understands a paraphrase — that is
  a property of the embedding model, not of this pipeline. What is asserted
  is everything the pipeline itself owns.
- The cross-encoder is exercised **for real**, not mocked: a genuine
  `CrossEncoder`-compatible model is built on disk from `transformers` and
  loaded through the same class production uses, so a breaking change in the
  library's constructor or `predict` signature fails in CI rather than in a
  deployment. Its weights are random, so the tests assert that the
  integration works and that the outputs are well-formed probabilities —
  never on the order it produces.

The seven scenarios Stage 6 required are each covered in
`test_context_builder.py`, in their own labelled sections: multiple
documents, duplicate chunks, the context limit, missing metadata, long
chunks, insufficient evidence, and source ordering.

Every one of those tests builds from plain `Chunk` objects rather than
from a retrieval run. That is requirement 10 made real: if checking a
token budget needed a vector store, an embedding model and a reranker
first, the builder would not be independently testable and every failure
would be ambiguous about its cause.

The eight scenarios Stage 7 required are each covered in
`test_generation_service.py`, in their own labelled sections: a grounded
answer, insufficient evidence, an irrelevant question, multiple documents,
multiple citations, missing citation metadata, an LLM failure, and a
malformed LLM response.

Two notes on what is and is not mocked:

- The **model** is scripted, so each scenario can be produced exactly — a
  perfect answer, an invented citation, a truncated reply, an outage.
- The **providers** are not. `OpenAIProvider` and `AnthropicProvider` run
  against `httpx.MockTransport`, so the request body, the auth header,
  the response shape and the error mapping are all real code against a
  fake socket. A mocked provider object would assert nothing about the
  part that breaks when a vendor renames a field.

The ten areas Stage 9 required evaluating are each covered in
`test_hardening.py`, in their own labelled sections, and each is reported
with its measurement in [§1g](#1g-hardening-for-500-documents-stage-9).
`scripts/benchmark.py` is committed alongside them, so the numbers in §1g
can be reproduced rather than taken on trust.

### Defects found and fixed in Stage 9

1. **The BM25 cache key ignored the settings that shape the index.** Caught
   by the suite, not by inspection: a retriever configured with
   `KEYWORD_CORPUS_LIMIT=3` was handed the full cached index built under the
   default limit of 5,000. A cache that returns a *different object than the
   one you asked for* is worse than no cache, because the difference is
   invisible. The key now includes the corpus limit and both BM25
   parameters.
2. **The cached path re-derived `truncated` as `size >= limit`**, which is
   wrong at exactly the boundary — a corpus of precisely 5,000 chunks is
   complete but would have been reported as truncated. `truncated` is now
   carried on `BM25Index` itself, so a cached index reports what was
   actually true when it was built.
3. **Two idempotency tests asserted the old mechanism** rather than the
   intent — `second.replaced is True`, and `chunks_replaced ==
   chunks_indexed` over HTTP — so the skip-unchanged path broke both even
   though the behaviour was strictly better. Rewritten to assert what
   actually matters (no duplicate chunks, same count), with companion tests
   for the skip path, the forced-rebuild path and an edit that must *not* be
   skipped.
4. **The `sweep_stale_temp_files` insertion landed between `@contextmanager`
   and `managed_upload`**, stealing the decorator and breaking three upload
   tests. A mechanical error, caught mechanically, which is the argument for
   running the suite after every edit rather than after every stage.
5. **`TEMP_FILE_MAX_AGE_HOURS` silently failed to land in `app/config.py`** —
   the patch anchor did not match, the edit reported success, and the
   setting simply was not there. Caught by a test asserting the sweep never
   raises. The sweep is now also tolerant of a missing temp directory.
6. **The delete-then-upsert window in `index_from_document`** was found by
   reading rather than by a failure: a crash between clearing a document's
   old chunks and writing its new ones left the document absent from the
   index while the caller's database still recorded it as indexed. Now
   wrapped, rolled back and reported as `IndexingError` — see §1g, point 5,
   including what this still does not fix.
7. **The skip-unchanged check never ran on the inline-`text` path**, found
   on a **live server** rather than in a test. `POST /ingest` with a `text`
   body goes through `index_from_document` directly, and the check lived
   only in `index_document`, which the file path uses. So the headline
   Stage 9 improvement silently did not apply to one of the two documented
   ways of calling the endpoint: re-posting identical text re-chunked and
   re-embedded it and reported `status: "success"` as though it had done
   fresh work. The check now lives in `index_from_document` too, with a
   `force` flag that `index_document` passes because it has already run the
   cheaper pre-extraction version. Four `POST /ingest` calls now report
   `success`, `duplicate_of`, `unchanged` and `success` (replacing 4 chunks
   with 5) respectively — verified against a running server, then pinned by
   tests.

### Defects found and fixed in Stage 8

1. **A Stage 7 test asserted the service's stage number**, which Stage 8
   changed. Same class of brittleness as the two before it: the stage
   number belongs to whichever stage is current, so the test now asserts
   Stage 7's durable claim — that generation and citation validation are
   named on the root document — and the number is asserted by the stage
   that owns it. Three occurrences of this pattern have now been fixed;
   the rule is written down above.
2. **Three pieces of nonsense in the first draft of the pipeline
   router**, caught by reading it back before running anything: a `raise`
   of a boolean expression (`raise IngestionError.__subclasshook__ and
   ...`), a no-op fallback (`(result.chunking and "" or "") or ...`), and
   two exception classes defined *inside* request handlers, so every call
   built a new class object and no caller could catch them by name. The
   413 and 429 errors are now proper members of the exception hierarchy,
   and `document_type` is carried on `IndexResult` rather than read back
   out of the vector store on every ingest.

### Defects found and fixed in Stage 7

1. **An unknown page number was being turned into "page 1".**
   `chunk_from_metadata` coerced a missing or zero `page_number` to 1,
   which was harmless while pages were only displayed and became a
   fabricated reference the moment citations existed: a user told "page 1"
   for a passage whose pagination was never established has a citation
   that looks checkable and is not. Zero now stays zero, the formatter
   renders `(unknown)`, and the citation emits `null`.
2. **A Stage 6 test asserted the service's stage number**, which Stage 7
   changed — and its companion assertion (`"answer" in scope`) would have
   started passing for the opposite reason, since the scope now says the
   service *does* answer. Both were rewritten to assert Stage 6's durable
   claim instead.

### Defects found and fixed in Stage 6

1. **Sentence-aligned truncation discarded the most relevant clause.**
   Found on the live server. Stopping at the last whole sentence that fits
   is right in principle, but legal sentences are long and uneven: the
   fixture contract's termination clause sentence-aligned to 38 tokens of
   a 60-token allowance — a 37% loss — which then fell below
   `CONTEXT_MIN_SOURCE_TOKENS` and was dropped entirely. The single best
   passage in the corpus was being thrown away by the mechanism meant to
   fit it. Now the sentence boundary is kept only while it costs a quarter
   of the budget or less, and otherwise the budget is filled on a word
   boundary; the block declares the truncation either way.
2. **An invalid `context_order` would have been a 500.** Validated in the
   request schema instead, as with `mode` in Stage 5 — a typo in the
   backend's payload is a client error, not a service fault.
3. **A Stage 5 test asserted the service's stage number**, which Stage 6
   then changed. Its real intent was that the root document names
   retrieval and keeps the "no generation" disclaimer; it now asserts
   that, and the stage number is asserted by the stage that owns it.

### Defects found and fixed in Stage 5

1. **Min-max normalisation made every ranking boost powerless.** Fused
   scores were stretched to fill `[0, 1]` regardless of how close the raw
   values were, so two candidates separated in the fourth decimal came out a
   full point apart and a 0.25 clause-reference boost could never move them.
   Four ranking tests failed at once. Fixed by scaling by the maximum
   instead, which preserves the ratios — near-ties stay near-ties. The same
   bug was latent in the rerank blend, where it would have let a
   cross-encoder's 0.94-vs-0.93 become decisive over the retrieval signal.
2. **A clause reference never matched a section heading.** `"4. TERMINATION"`
   *is* clause 4, but the reference pattern required the number not to be
   followed by a full stop — which is exactly how section headings are
   written. The guard had to reject `14.25` and `USD 4.20` while accepting
   `4.`; it was rejecting all three.
3. **A relevance model outranked an explicit citation.** Found on the live
   server, not in a test: asked "what does clause 8 say", the service
   returned clause **7** first, because clause 7 contains the literal string
   "Clause 8" and clause 8's own text does not. Fixed by *pinning* a
   candidate whose section is the named clause, so no later stage can demote
   it. A relevance model judges whether a passage is about a question; it is
   not entitled to overrule a citation the user gave.
4. **An invalid `mode` returned 500 with a traceback.** A typo in the
   backend's payload was being reported as a service fault. `mode` is now
   validated in the request schema and comes back as a `422` naming the
   field.

### Defects found and fixed in Stage 4

- **`VECTOR_BACKEND` was a closed `Literal`.** Registering a Pinecone
  adapter would have required editing `config.py` — defeating the registry
  that exists precisely so backends are pluggable. Now a free string,
  validated against the registry at build time.
- **Backends disagreed on duplicate ids within one batch.** Chroma raises;
  a dict-backed store takes last-wins. Code that worked on one would fail on
  the other, which is exactly what an abstraction must prevent. Normalised
  in `dedupe_by_chunk_id`, applied by both adapters.
- **Sentence-Transformers 6.x renamed the dimension accessor.** The wrapper
  called only the old name, which still works but emits a deprecation
  warning; it now tries both, newest first.

### Defects found and fixed in Stage 3

A property check over 525 (configuration × document-shape) combinations
found three that no hand-written test had:

- **Overlap was added on top of a full-size body**, so every chunk after the
  first ran up to 1.5× over budget at the maximum overlap setting — straight
  past the embedding model's window. Overlap is now carved *out of* the chunk
  budget (`body_budget = size − overlap`).
- **Overlap compounded across chunks.** `_tail` always took at least one whole
  sentence, and the tail was measured from the previous chunk *including its
  overlap*. With a long sentence, chunk sizes grew monotonically (85 → 181 →
  265 → …). The budget is now a hard limit with a word-level fallback.
- **The word window used a fixed words-per-token ratio.** Identifier-heavy
  text costs several tokens per "word", so pieces came out far over budget.
  Words are now accumulated against measured costs.

Two splitter bugs, found by unit tests:

- **Every abbreviation lookbehind was dead code.** The split point is the
  position *after* the full stop, so `(?<!\bArt)` tested the three characters
  before that position — `"rt."` — and never matched. `Art. 9`, `Sec. 4`,
  `Pvt. Ltd.`, `approx. 5000` and `Jan. 2024` were all being split.
- **Multi-level clause numbers needed trailing punctuation.** `4.2 Termination`
  was not recognised as an item start; only `4.2.` or `4.2)` were.

One design defect, found by inspecting real output:

- **An orphan document title survived as its own 7-token chunk.** Merging was
  restricted to a single section, and a title forms its own section.
  Heading-only chunks now merge forward across sections; body text still
  cannot.

### Defects found and fixed in earlier stages

- **The parser registry stored classes, not instances.** `@register` on a class
  put the class in the registry, so `parser.parse(path, …)` bound `path` to
  `self`. 32 tests failed at once. `register()` now instantiates.
- **A damaged PDF was reported as empty.** PyMuPDF repairs what it can and
  returned 0 pages for a truncated file, which fell through to the emptiness
  check. Now a zero-page PDF raises `corrupt_document`, and a file that only
  parsed after repair carries a warning.
- **Digit-masking was too aggressive in header detection.** Masking digits in
  every line made body text differing only by a number ("deliver 3 units" /
  "deliver 4 units") look like a repeated footer — i.e. real clause text could
  be deleted. Masking is now restricted to short or explicitly page-labelled
  lines, with a regression test.
- **The Dockerfile chowned after dropping privileges.** `mkdir`/`chown` for the
  data directories landed after `USER genai` and would have failed at build
  time.

### Verified on a live server

Not just under the test client — `uvicorn` on a real port:

- 4-page contract: 4 pages, 17 blocks, 9 sections, 2 running headers removed,
  the termination clause correctly on **page 2** (not collapsed onto page 1),
  and the repeated footer gone from the output.
- Scanned PDF: `parser: pymupdf+ocr`, `method: ocr`, text recovered
  ("ARBITRAL AWARD… USD 250,000"), every block flagged `ocr: true`.
- DOCX: heading styles produced 6 sections, table content preserved
  ("Wilmington"), pages flagged synthetic, type inferred as `nda`.
- Failures: `corrupt_document` 422, `unsupported_file_type` 415, `unsafe_path`
  400, `document_not_found` 404 — each with a distinct message.
- Batch of 3 with one corrupt file: 200 OK, 2 succeeded, 1 failed, 21 ms.
- Upload: extracted correctly; temp directory empty afterwards (`0700`).
- 3 MB upload against a 1 MB limit: 413 `file_too_large`, zero temp files left.

Stage 5 was verified the same way, against ChromaDB with three documents
indexed (a contract and an NDA for one tenant, the same contract for a
second tenant):

- `/health` reported the reranker as **degraded** with the reason, because
  the cross-encoder could not be downloaded in this environment — exactly
  the behaviour a deployment missing the model should show.
- "How much notice is required to terminate for convenience?" returned
  `4. TERMINATION` at rank 1 in 12 ms, with per-stage timings and the full
  score breakdown for every result.
- "what does clause 8 say" returned `8. DISPUTE RESOLUTION` first and
  `7. GOVERNING LAW` (which cites clause 8) second — this is the query that
  exposed defect 3 above, and the run afterwards is what confirmed the fix.
- The same query as the second tenant returned only that tenant's documents.
- `document_type=nda` restricted results to the NDA on both retrieval paths.
- An unrelated query ("sourdough levain autolyse hydration") produced **zero**
  keyword candidates, and returned nothing at all once a score floor was set.
- Re-uploading the contract under a second `document_id` collapsed 6 of 18
  candidates as duplicates, with the dropped `chunk_id`s kept on the
  survivors so no citation was lost.

Stage 6 was verified against the same running service:

- A 900-token context over two documents produced four numbered sources —
  the contract's clauses first (strongest document), in reading order,
  then the NDA's — using 497 tokens, of which 214 were source headers.
  The two passages that did not make the source cap were reported in
  `omitted` with their sections.
- With retrieval deduplication switched off so the builder saw the
  re-uploaded contract itself, it collapsed the duplicates and rendered
  `Also appears in: vendor_contract_2024.pdf p.2` on the survivors.
- A 220-token budget with a 60-token per-source cap kept the termination
  clause, shortened it, and said so in the block and in the warnings —
  this is the run that exposed defect 1 above, and the run afterwards is
  what confirmed the fix.

Stage 7 was verified twice: once on the offline default, and once through
the **real** `OpenAIProvider` pointed at a local stand-in server, so the
HTTP path, the auth header and the key-from-environment flow all ran for
real:

- `/answer/config` reported `openai:gpt-4o-mini`, `is_language_model:
  true`, `api_key_configured: true` — and no credential anywhere in the
  response. The stand-in server confirmed it received an `Authorization`
  header, `temperature: 0.0`, and a 2600-character system prompt.
- The stand-in model was scripted to cite Source 2 (real) **and Source 99**
  (invented), and to quote words that appear in no passage. The response
  kept the valid citation, dropped 99 with
  `unknown_source` and an explanation, listed the fabricated quotation in
  `unverified_quotes`, and returned `grounded: false` with both warnings.
- With no evidence retrieved (unknown tenant, and an irrelevant question
  under a score floor), the answer was the fixed refusal and the provider
  was **never called**.
- A model reply of plain prose was retried once — the stand-in server
  logged exactly two requests — then reported as `malformed_response`
  with `answer: null`, an excerpt of the reply, and all six retrieved
  passages still in the response.
- With the stand-in server stopped, the request returned **HTTP 200**,
  `status: llm_unavailable`, `answer: null`, and the six passages intact.
- Tenant isolation held through generation: the same question as the
  second tenant cited only that tenant's documents.

Stage 8 was verified by running the service on a real port and calling
**every endpoint** with `curl`. The examples in §9 are that session's
actual output:

- `POST /ingest` indexed a 3-page PDF into 8 chunks in 100 ms, and
  separately indexed inline text — reporting in `warnings` that pasted
  text has no pagination rather than inventing a page number.
- Re-ingesting the same `document_id` reported `chunks_replaced: 8`,
  confirming replacement rather than duplication.
- `POST /ingest/batch` returned **202** immediately for 13 documents; the
  job completed in 186 ms with 12 succeeded, 1 failed
  (`document_not_found` against its own id), 48 chunks indexed. Polling
  with `?include_results=false` returned the counters alone.
- `POST /query` answered with validated citations in 15 ms and echoed the
  caller's `X-Request-ID: express-req-042`; a `document_ids` filter
  narrowed the evidence to one document; the same question as a second
  tenant returned `insufficient_evidence` and no citations.
- `DELETE /documents/{id}?tenant_id=` removed 8 chunks (also reported in
  an `X-Chunks-Deleted` header), after which the document was no longer
  retrievable. Repeating the call returned 200 with `deleted: false`, and
  deleting under the wrong tenant removed nothing.
- Nine error cases each returned the right status and a stable
  `error.type`: 422 for validation, 400 for `unsafe_path` and a duplicated
  id in one batch, 404 for a missing file and an unknown job id.
- `/health`, `/answer/config` and `/openapi.json` were grepped for `sk-`:
  clean.

(That `chunks_replaced: 8` line is Stage 8's behaviour. Stage 9's
skip-unchanged check means an identical re-ingest now reports
`status: "unchanged"` instead — the newer run below is the current one.)

Stage 9 was verified on a running server as well, and that is where its
last defect was found rather than in the suite. Four `POST /ingest` calls,
in order:

| Call | `status` | `chunks_indexed` | `chunks_replaced` | `duplicate_of` |
|---|---|---:|---:|---|
| The document, first time | `success` | 4 | 0 | — |
| Identical content, second id | `success` | 4 | 0 | `msa-1` |
| Identical content, same id | `unchanged` | 4 | 0 | — |
| Edited content, same id | `success` | 5 | 4 | — |

The third row is the one that was wrong on the first attempt — it reported
`success` with 4 chunks replaced, because the skip lived only on the file
path. The fourth row is the check that the skip never swallows a real
edit. `POST /query` then answered from the edited document with three
validated citations including the newly added clause, and the same question
as a second tenant returned `insufficient_evidence` with no citations.

---

## 8. Local setup

```bash
cd genai_service
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# OCR engine — a system package, not pip
sudo apt-get install -y tesseract-ocr tesseract-ocr-eng   # Debian/Ubuntu
# brew install tesseract                                   # macOS

cp .env.example .env
mkdir -p data/documents data/tmp
uvicorn app.main:app --reload --port 8000
```

```bash
curl http://localhost:8000/health
curl http://localhost:8000/documents/formats
curl -X POST http://localhost:8000/documents/extract \
  -H 'content-type: application/json' \
  -d '{"document_id":"d1","tenant_id":"t1","file_path":"contract.pdf"}'
```

Without Tesseract everything still runs; `/health` reports `ocr: degraded` and
scanned pages are skipped with a warning.

### Docker

```bash
docker build -t legaldocai-genai:stage2 .
docker run -p 8000:8000 \
  -v /path/to/shared/uploads:/srv/genai/data/documents:ro \
  legaldocai-genai:stage2
```

The image installs Tesseract plus the English pack, creates the data
directories, and runs as UID 10001. Mount the same volume the Node.js backend
writes uploads to. **Python AI service only** — React, Node.js and MongoDB
images are out of scope.

---

## 9. Integrating from Node / Express

Every example below was run against the service on `localhost:8077` and
the output is what it actually returned. Set `BASE` to wherever the
service is reachable from your backend:

```bash
BASE=http://localhost:8000
# If SERVICE_TOKEN is set, add to every call:
#   -H "X-Service-Token: $SERVICE_TOKEN"
```

### Four things that hold on every endpoint

**One error envelope.** Every non-2xx response is the same shape, and
`error.type` is a stable string to branch on — never parse a message:

```json
{
  "error": {
    "type": "document_not_found",
    "message": "File not found: nope.pdf",
    "details": {}
  },
  "request_id": "aee63318bd0b4fc7"
}
```

| `error.type` | Status | What Express should do |
|---|---|---|
| `validation_error` | 400 / 422 | Fix the payload; `details.fields` says which field |
| `unsafe_path` | 400 | The path escapes `DOCUMENT_ROOT` — a bug or an attack |
| `authentication_error` | 401 | `X-Service-Token` missing or wrong |
| `document_not_found` | 404 | The file is not on the shared volume |
| `not_found` | 404 | Unknown job id |
| `payload_too_large` · `file_too_large` | 413 | Split the batch, or the file is over `MAX_FILE_SIZE_MB` |
| `unsupported_file_type` | 415 | Not a `.pdf` or `.docx` |
| `corrupt_document` · `empty_document` | 422 | The file is damaged, or has no extractable text |
| `too_many_requests` | 429 | A batch is already running; retry later |
| `internal_error` | 500 | Log the `request_id` and report it |
| `service_unavailable` | 503 | A dependency is down; retry |

**Request ids.** Send `X-Request-ID` and the service uses it — echoed in
the response header, in the body, and stamped on every log line it writes
while handling the call. One id ties an Express log to the retrieval that
produced a citation. Omit it and one is generated.

**Tenant isolation.** Every endpoint that touches stored data takes an
explicit `tenant_id`. There is no default tenant and no way to ask for
everything.

**No credentials in responses.** API keys are read from the environment
and never appear in a response, a log line, an error or `/openapi.json`.

---

### `POST /ingest` — one document

Send **either** `file_path` (a path under `DOCUMENT_ROOT`, the volume
your backend writes uploads to) **or** `text` (content you already hold).

```bash
curl -X POST $BASE/ingest \
  -H 'Content-Type: application/json' \
  -H 'X-Request-ID: express-req-001' \
  -d '{
    "document_id": "doc-msa-001",
    "tenant_id": "harbour-legal",
    "file_path": "tenant-a/vendor_contract_2024.pdf",
    "document_type": "contract",
    "metadata": {"matter": "acme-2024"}
  }'
```

```json
{
  "status": "success",
  "document_id": "doc-msa-001",
  "tenant_id": "harbour-legal",
  "filename": "vendor_contract_2024.pdf",
  "document_type": "contract",
  "duplicate_of": null,
  "chunks_indexed": 8,
  "chunks_replaced": 0,
  "pages": 3,
  "ocr_pages": 0,
  "embedding_model": "all-MiniLM-L6-v2",
  "embedding_dimension": 384,
  "warnings": [],
  "duration_ms": 100,
  "request_id": "express-req-001"
}
```

Re-ingesting the same `document_id` is always safe — a retry after a
timeout never duplicates, and an edited document leaves no orphans. Two
outcomes are possible, and `status` tells you which:

- **Content changed** → `status: "success"`, and `chunks_replaced` says how
  many of the old chunks went.
- **Content identical** → `status: "unchanged"`, and nothing was
  re-extracted, re-chunked or re-embedded. On 500 documents this is the
  difference between 33 seconds and 1.7 (§1g). Treat it as a success:
  the document is indexed and current.

`duplicate_of` is non-null when a **different** `document_id` in the same
tenant already holds identical content. The document is still indexed —
two matters can legitimately hold the same contract — but your backend can
warn, link them, or refuse the upload, which is a decision for Express
rather than for this service.

Anything in `metadata` becomes filterable at query time — `matter`,
`client_id`, `year`, whatever your schema needs. Scalars only.

**Inline text**, when the backend already has the content and a round
trip through a shared disk buys nothing:

```bash
curl -X POST $BASE/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "document_id": "doc-memo-002",
    "tenant_id": "harbour-legal",
    "filename": "notices_memo.txt",
    "text": "9. NOTICES\n\nAny notice under this Agreement must be in writing..."
  }'
```

Pasted text has no pagination, so citations from it report no page
number — the response says so in `warnings` rather than inventing
"page 1".

For a file your backend has **not** written to the shared volume, stream
it instead: `POST /index/upload` (multipart: `file`, `document_id`,
`tenant_id`).

---

### `POST /ingest/batch` — up to ~500 documents

```bash
curl -X POST $BASE/ingest/batch \
  -H 'Content-Type: application/json' \
  -d '{
    "documents": [
      {"document_id": "doc-bulk-001", "tenant_id": "harbour-legal",
       "file_path": "tenant-a/contract_001.pdf", "document_type": "contract"},
      {"document_id": "doc-bulk-002", "tenant_id": "harbour-legal",
       "file_path": "tenant-a/contract_002.pdf"}
    ]
  }'
```

**HTTP 202** — accepted, not finished:

```json
{
  "job_id": "bd94de3fa31340a9ae6cd26b1883fd75",
  "status": "queued",
  "total": 13,
  "poll_url": "/ingest/batch/bd94de3fa31340a9ae6cd26b1883fd75",
  "accepted_at": "2026-09-13T05:26:40.605534+00:00",
  "request_id": "03b5d4eb7319473f"
}
```

*Why not synchronous.* 500 documents take minutes to hours to extract,
chunk and embed. Every proxy between Express and this service would time
out first, and a 504 after forty minutes of real work — with no way to
learn what got indexed — is the worst available outcome.

*Why it cannot exhaust memory.* Batch items are **references, never
contents**: `BatchIngestItem` has a `file_path` and no `text` field, so
there is no field in which 500 documents could arrive. The worker then
processes them strictly one at a time, so peak memory is one document
whatever the batch size. A test asserts that by instrumenting the
indexing call and checking the peak never exceeds one.

### `GET /ingest/batch/{job_id}`

```bash
curl $BASE/ingest/batch/bd94de3fa31340a9ae6cd26b1883fd75
```

```json
{
  "job_id": "bd94de3fa31340a9ae6cd26b1883fd75",
  "status": "completed",
  "total": 13, "processed": 13, "succeeded": 12, "failed": 1,
  "chunks_indexed": 48, "progress": 1.0, "duration_ms": 186,
  "results": [
    {"document_id": "doc-bulk-001", "status": "success", "chunks_indexed": 4,
     "pages": 2, "error_type": null, "warnings": [], "duration_ms": 14},
    {"document_id": "doc-bulk-missing", "status": "failed", "chunks_indexed": 0,
     "error_type": "document_not_found",
     "error": "File not found: does_not_exist.pdf"}
  ]
}
```

`status` moves `queued` → `running` → `completed` | `failed`. One bad
document never stops the batch — it is recorded against its own id and
the rest continue.

Polling a progress bar every second? Pass `?include_results=false` to get
the counters without the per-document array.

Job records are in-memory and per-process: a restart loses job *status*,
never indexed data. Documents are committed as they complete and indexing
is idempotent, so re-submitting after a restart re-indexes onto the same
chunk ids rather than duplicating.

---

### `POST /query` — question in, cited answer out

```bash
curl -X POST $BASE/query \
  -H 'Content-Type: application/json' \
  -H 'X-Request-ID: express-req-042' \
  -d '{
    "query": "How much notice is required to terminate for convenience?",
    "tenant_id": "harbour-legal",
    "top_k": 4
  }'
```

```json
{
  "status": "ok",
  "answer": "Either party may terminate this Agreement for convenience on one hundred and twenty (120) days written notice to the other party...",
  "citations": [
    {"document": "vendor_contract_2024.pdf", "page": 2,
     "section": "4. TERMINATION", "chunk_id": "2896bf74d708...",
     "source": 1, "document_id": "doc-msa-001", "page_range": "2"}
  ],
  "interpretation": "",
  "insufficient_evidence": false,
  "grounded": true,
  "validation": {"grounded": true, "valid_citations": 2, "rejected": [],
                 "verified_quotes": 0, "unverified_quotes": []},
  "sources": [],
  "provider": "openai", "model": "gpt-4o-mini", "is_language_model": true,
  "warnings": [],
  "duration_ms": 15,
  "timings_ms": {"retrieval": 14, "context": 1, "generation": 0, "validation": 0},
  "request_id": "express-req-042"
}
```

**Optional document filters**, all of them independent:

```bash
curl -X POST $BASE/query \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "What are the confidentiality obligations?",
    "tenant_id": "harbour-legal",
    "document_ids": ["doc-msa-001"],
    "document_type": "contract",
    "page_range": [1, 10],
    "metadata": {"matter": "acme-2024"},
    "top_k": 2,
    "include_sources": true
  }'
```

`include_sources: true` returns the passages behind the answer — for a
"show sources" panel, or for debugging why an answer came out the way it
did:

```json
"sources": [
  {"source": 1, "chunk_id": "8400f921...", "document_id": "doc-msa-001",
   "filename": "vendor_contract_2024.pdf", "page": 2, "page_range": "2",
   "section": "6. CONFIDENTIALITY", "document_type": "contract",
   "text": "Each party shall keep confidential...",
   "score": 1.0, "retrieval_rank": 1, "truncated": false}
]
```

`include_context: true` additionally returns the exact prompt block sent
to the model. That is a debugging tool, not something to show a user.

**Three fields worth rendering in the UI:**

- `status` — branch on it. `insufficient_evidence` means the documents do
  not answer the question, and the `answer` says so plainly.
- `grounded` — `false` means the answer could not be fully checked
  against the evidence (a citation naming a source that was not
  retrieved, or a quotation not found in any passage). Worth surfacing.
- `citations[].chunk_id` — the exact passage. Pair it with
  `include_sources` to build a click-through to the source text.

**A model failure returns 200, not 5xx**, with `answer: null` and the
retrieved sources intact:

```json
{"status": "llm_unavailable", "answer": null, "sources": [ ... ],
 "error": "openai:gpt-4o-mini could not be reached: ConnectError"}
```

Retrieval succeeded; discarding it because the model call failed serves
the user worse than showing them the relevant clauses. Render "we
couldn't generate an answer — here are the relevant passages".

---

### `DELETE /documents/{document_id}` — remove vector data

```bash
curl -X DELETE "$BASE/documents/doc-msa-001?tenant_id=harbour-legal"
```

```json
{
  "deleted": true,
  "document_id": "doc-msa-001",
  "tenant_id": "harbour-legal",
  "chunks_deleted": 8,
  "request_id": "aee63318bd0b4fc7"
}
```

`tenant_id` is **required**; deleting another tenant's `document_id`
removes nothing. Call this whenever your backend deletes a document, so
the index cannot keep citing something the user has removed.

**A document with nothing indexed returns 200 with `deleted: false`, not
404.** Delete is idempotent, and the no-match case is legitimate — an
empty or scanned PDF that produced no chunks, or a retry of a delete that
already succeeded. A 404 would make Express treat a correct outcome as a
failure.

To remove an entire tenant (account deletion, erasure request):
`DELETE /tenants/{tenant_id}/index`.

---

### `GET /health`

```bash
curl $BASE/health
```

```json
{
  "status": "degraded",
  "service": "LegalDocAI GenAI Service",
  "version": "0.1.0",
  "uptime_seconds": 41.2,
  "components": [
    {"name": "configuration",   "status": "ok"},
    {"name": "ingestion",       "status": "ok"},
    {"name": "ocr",             "status": "ok"},
    {"name": "chunking",        "status": "ok"},
    {"name": "embedding_model", "status": "ok"},
    {"name": "vector_store",    "status": "ok"},
    {"name": "retrieval",       "status": "ok"},
    {"name": "reranker",        "status": "degraded"},
    {"name": "context",         "status": "ok"},
    {"name": "llm",             "status": "ok"}
  ]
}
```

`200` while the service can serve, `503` when the aggregate status is
`unavailable`. **`degraded` is worth an alert, not an outage page**: it
means something is answering in a lesser mode — the reranker fell back,
or no language model is configured — and each component's `detail` says
exactly what and how to fix it.

For container probes use the cheap ones: `/health/live` (is the process
up) and `/health/ready` (should traffic be routed here).

---

### A minimal Express client

```js
const BASE = process.env.GENAI_URL || "http://localhost:8000";

async function callGenAI(path, { method = "POST", body, requestId } = {}) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(requestId && { "X-Request-ID": requestId }),
      ...(process.env.SERVICE_TOKEN && {
        "X-Service-Token": process.env.SERVICE_TOKEN,
      }),
    },
    ...(body && { body: JSON.stringify(body) }),
  });

  const data = await res.json();
  if (!res.ok) {
    // One envelope, every time. Branch on the stable type, not the message.
    const err = new Error(data.error.message);
    err.type = data.error.type;
    err.status = res.status;
    err.requestId = data.request_id;
    throw err;
  }
  return data;
}

// Ingest on upload
await callGenAI("/ingest", {
  body: {
    document_id: doc._id.toString(),
    tenant_id: req.user.orgId,
    file_path: path.relative(SHARED_ROOT, doc.storagePath),
    document_type: doc.kind,
  },
  requestId: req.id,
});

// Answer a question
const { answer, citations, grounded, status } = await callGenAI("/query", {
  body: { query: req.body.question, tenant_id: req.user.orgId, top_k: 6 },
  requestId: req.id,
});

// Keep the index in step with Mongo
await callGenAI(
  `/documents/${doc._id}?tenant_id=${req.user.orgId}`,
  { method: "DELETE" }
);
```

`tenant_id` comes from the **authenticated session**, never from the
request body the browser sent. This service trusts the value it is given;
authentication is the Express layer's job, and that boundary is the whole
of the tenant isolation guarantee on your side of it.

---

## 10. Limitations

Scope boundaries and honest caveats:

- **Grounding is not a guarantee.** The prompt constrains the model to the
  supplied evidence and every citation is checked against the passages
  actually retrieved, which makes each citation verifiable and each
  unverifiable one visible. It does not make a wrong statement impossible:
  a model can assert something the evidence does not support and cite a
  real passage alongside it, and no check here would find that. Answers
  are drafting aid and a route into the source documents, not legal
  advice, and the citations exist so a person can check them.
- **Generation limitations** are listed separately in §1f — the ones that
  matter most are sentence-level grounding not being enforced, exact-match
  quote checking, and no conversation history.
- **Context limitations** are listed separately in §1e — the ones that
  matter most are header overhead on small budgets, approximate token
  counts, and lexical-only redundancy detection.
- **Retrieval quality depends on the embedding model actually loading.**
  With `EMBEDDING_STRICT=false` a failed load silently falls back to a
  lexical hashing encoder that is *not* semantic; `/health` reports it, and
  production should set `EMBEDDING_STRICT=true`. The same applies to the
  reranker and `RERANK_STRICT`.
- **Retrieval limitations** are listed separately in §1d — the ones that
  matter most are lexical-only duplicate detection and hand-tuned ranking
  boosts. The per-query BM25 rebuild listed there was fixed in Stage 9.
- **Scale and hardening limitations** are listed separately in §1g — the
  ones that matter most are the BM25 cache's **per-process** invalidation
  counter (set `KEYWORD_CACHE_ENABLED=false` if more than one process
  writes to the store), ingestion timings measured with the deterministic
  encoder and therefore a floor rather than a forecast, and the narrowed
  but not closed crash window between deleting a document's old chunks and
  writing its new ones.
- **Chunking strategy limitations** are listed separately in §1b — the ones
  that matter most are approximate token counts, unresolved cross-references,
  and definitions living far from their use.
- **DOCX page numbers are synthetic** and will not match what a user sees in
  Word. They are stable and flagged, but they are our pagination, not Word's.
- **Tables are flattened** to pipe-separated rows. Nested tables and merged
  cells lose their structure; PDF tables come through as plain text blocks with
  no table awareness at all.
- **Section detection is heuristic** and best-effort — `section` is optional
  everywhere and nothing depends on it. It handles common contract numbering
  well; multi-column layouts, unusual numbering and heavily formatted schedules
  can yield wrong or missing labels.
- **Reading order assumes single-column.** Blocks are sorted top-to-bottom then
  left-to-right, which is wrong for genuinely two-column documents.
- **OCR quality varies.** No deskew, denoise or rotation correction, and no
  handwriting recognition. Poor scans, stamps and signatures produce noisy
  text. `OCR_DPI=200` is a speed/accuracy compromise.
- **OCR is slow** — roughly 1.2 s per page in local testing, versus ~20 ms for
  a native page. A 200-page scan will take minutes. Send such documents
  through `/ingest/batch`, where they hold up only their own job.
- **Batch jobs are in-memory and single-process.** `POST /ingest/batch`
  returns 202 immediately and reports progress, so proxy timeouts are no
  longer the problem they were; but a restart loses job *status* (never
  indexed data, which is committed per document and re-indexes
  idempotently), and job ids are invisible to a second replica. Celery, RQ
  or Arq is the answer for multiple replicas, and was deliberately **not**
  added at this scale — the swap is contained to `app/services/jobs.py`.
- **One document is held in memory at a time**, and since Stage 9 its
  vectors are embedded and written in `INDEX_BATCH_SIZE` slices rather than
  all at once. Fine for contracts; a 2,000-page scan is still a heavy
  single document, because extraction itself holds the whole thing.
- **English-focused.** OCR defaults to `eng`, and the cleaning, heading and
  page-furniture heuristics assume English legal drafting conventions.
- **Encrypted PDFs are rejected**, not decrypted, even with a known password.
- **Only `.pdf` and `.docx`.** No `.doc`, `.rtf`, `.txt`, images or email
  formats.

---

*Stage 9 of the GenAI component of LegalDocAI — not the complete LegalDocAI
application. The React frontend, Express API, MongoDB persistence,
authentication and MERN deployment are owned by the MERN developer and are
deliberately absent.*
